#pragma once


namespace zsibot::cli
{
    static constexpr auto black     = "\033[30m";
    static constexpr auto red       = "\033[31m";
    static constexpr auto green     = "\033[32m";
    static constexpr auto yellow    = "\033[33m";
    static constexpr auto blue      = "\033[34m";
    static constexpr auto purple    = "\033[35m";
    static constexpr auto cyan      = "\033[36m";
    static constexpr auto white     = "\033[37m";
    static constexpr auto bold      = "\033[1m";
    static constexpr auto underline = "\033[4m";
    static constexpr auto clear     = "\033[H\033[2J";
    static constexpr auto reset     = "\033[0m";
}  // namespace zsibot::cli
