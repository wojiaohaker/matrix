#pragma once

#include <zsibot/chrono.hpp>
#include <zsibot/thread/thread_utils/condition.hpp>
#include <zsibot/thread_lock.hpp>

namespace zsibot::container
{
    template <class T>
    class Timeliness final : public zsibot::thread_lock::RecursiveLock
    {
    public:
        /**
         * @brief 写入新内容，标记上时间戳，并更新已读标志为 false
         */
        void write(const T& content, std::chrono::time_point<std::chrono::system_clock> timestamp = zsibot::chrono::now())
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                content_   = content;
                timestamp_ = timestamp;
                is_read_   = false;

                if (not isOutOfDate())
                    is_valid_.satisfy();
            }
        }

        void write(T&& content, std::chrono::time_point<std::chrono::system_clock> timestamp = zsibot::chrono::now())
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                content_   = std::move(content);
                timestamp_ = timestamp;
                is_read_   = false;

                if (not isOutOfDate())
                    is_valid_.satisfy();
            }
        }

        /**
         * @brief 将内容标记为已读
         */
        void ignore()
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                is_read_ = true;
                is_valid_.init();
            }
        }

        /**
         * @brief 查看内容，将本内容标记为已读
         */
        T read()
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                is_read_ = true;
                is_valid_.init();
                return content_;
            }
        }

        /**
         * @brief 偷看内容，不修改内容的已读属性
         */
        T peek() const
        {
            ZSIBOT_SYNCHRONIZED(this) return content_;
        }

        /**
         * @brief 取走内容，将本内容标记为已读
         */
        T take()
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                is_read_ = true;
                is_valid_.init();
                return std::move(content_);
            }
        }

        /**
         * @brief 返回内容的引用，并锁定本信件，其他访问被阻塞
         */
        T& lockRef()
        {
            lock();
            return content_;
        }

        /**
         * @brief 返回内容的常引用，并锁定本信件，其他访问被阻塞
         */
        const T& lockRefConst() const
        {
            lock();
            return content_;
        }

        /**
         * @brief 释放引用时加的锁
         */
        void releaseRef() const
        {
            unLock();
        }

        /**
         * @return 信件内容是否过期或者已读，也即，是否存在新的内容。
         */
        bool isFresh() const
        {
            ZSIBOT_SYNCHRONIZED(this) return not isOutOfDate() and not is_read_;
        }

        /**
         * @return 信件内容是否过期
         */
        bool isOutOfDate() const
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                return validity_ != std::chrono::microseconds(0) and zsibot::chrono::now() - timestamp_ >= validity_;
            }
        }

        /**
         * @brief 设置信件内容的保质期
         */
        void setValidity(const zsibot::unit::Time& time)
        {
            ZSIBOT_SYNCHRONIZED(this) validity_ = std::chrono::microseconds(static_cast<int64_t>(time.get<zsibotu::us>()));
        }

        /**
         * @brief 忽略保质期的判断
         */
        void setNeverOutOfDate()
        {
            ZSIBOT_SYNCHRONIZED(this) validity_ = std::chrono::microseconds(0);
        }

        /**
         * @return 信件内容的保质期
         */
        [[nodiscard]] zsibot::unit::Time getValidity() const
        {
            ZSIBOT_SYNCHRONIZED(this) return zsibotu::us(validity_.count());
        }

        /**
         * @brief 等待新的有效信息的到来
         */
        bool wait() const
        {
            return is_valid_.wait();
        }

        /**
         * @brief 在指定的时间范围内，等待新的有效信息到来。
         */
        bool wait(const zsibot::unit::Time& time) const
        {
            return is_valid_.wait(time);
        }

        /**
         * @brief 初始化本类的等待状态
         */
        void init()
        {
            ignore();
        }

        /**
         * @brief 使等待本消息的 wait() 函数全部失效
         */
        void fail()
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                is_read_ = true;
                is_valid_.fail();
            }
        }

        ~Timeliness() override
        {
            fail();
        }

    private:
        // 有效期
        std::chrono::microseconds validity_ = std::chrono::seconds(1);

        // 数据
        T content_;

        // 时间戳
        std::chrono::time_point<std::chrono::system_clock> timestamp_;

        // 是否已读
        bool is_read_ = true;

        // 新的有效内容接收通知
        zsibot::thread_utils::Condition is_valid_ = false;
    };
}  // namespace zsibot::container

namespace zsibotc
{
    template <class T>
    using timeliness = zsibot::container::Timeliness<T>;
}
