#pragma once

#include <functional>
#include <zsibot/container/pointer/stack_pointer.hpp>

#include "zsibot/container/iterator/adapter_iterator.hpp"
#include "zsibot/container/iterator/iterator_core.hpp"
#include "zsibot/container/iterator/random_iterator.hpp"
#include "zsibot/container/iterator/view_iterator.hpp"
#include "zsibot/container/iterator/wrapper_iterator.hpp"


namespace zsibot::container
{
    /**
     * @brief 迭代器类，所有操作可以通过操作子的设置来完成，接口仅取决于被迭代的类型
     * @tparam T
     */
    template <class T, std::size_t STACK_SIZE = 1024>
    class Iterator : public std::iterator<std::random_access_iterator_tag, T>
    {
        using CorePtr = StackPointer<iterator::ICore<T>, STACK_SIZE>;

    public:
        /**
         * @brief 构造拥有特定操作核的迭代器
         * @note 当操作核的 size 足够小时，将使用栈内存，此时可提高程序性能；
         * @note 当操作核的 size 比较大时，将使用堆内存。
         * @param args 创建操作核的构造参数
         */
        template <class TCore, class... TArgs>
        static Iterator create(TArgs&&... args)
        {
            static_assert(std::is_base_of_v<iterator::ICore<T>, TCore>);

            Iterator r;
            r.core_ptr_.template constructAs<TCore>(std::forward<TArgs>(args)...);
            return r;
        }

        /**
         * @brief 构造拥有特定操作核的迭代器
         */
        template <class TCore>
        static Iterator create(TCore&& core)
        {
            static_assert(std::is_base_of_v<iterator::ICore<T>, TCore>);

            Iterator r;
            r.core_ptr_.template constructAs<TCore>(std::forward<TCore>(core));
            return r;
        }

        /**
         * @brief 使用适配器核，构造迭代器，可用于转换迭代类型
         */
        template <class TIterator>
        static Iterator createAdapter(TIterator it, typename iterator::AdapterCore<T, TIterator>::Func func = nullptr)
        {
            return create(iterator::AdapterCore<T, TIterator>(std::move(it), std::move(func)));
        }

        /**
         * @brief 使用封装核，构造迭代器，可用于封装任意的迭代器
         */
        template <class TIterator>
        static Iterator createWrapper(TIterator it)
        {
            return create(iterator::WrapperCore<T, TIterator>(std::move(it)));
        }

    public:
        /**
         * @brief 使用特地操作核，构造迭代器，但总是适配核大小，使之构造的结果总是使用栈内存，
         * 若当前迭代器使用的栈内存大小足够使用，则按当前迭代器的大小构建。
         */
        template <class TCore, class... TArgs>
        static auto fitCreate(TArgs&&... args)
        {
            static_assert(std::is_base_of_v<iterator::ICore<T>, TCore>);

            Iterator<T, std::max(sizeof(TCore), STACK_SIZE)> r;
            r.core_ptr_.template constructAs<TCore>(std::forward<TArgs>(args)...);
            return r;
        }

        /**
         * @brief 使用特定操作核，构建自适应栈内存大小的迭代器
         */
        template <class TCore>
        static auto fitCreate(TCore&& core)
        {
            static_assert(std::is_base_of_v<iterator::ICore<T>, TCore>);

            Iterator<T, std::max(sizeof(TCore), STACK_SIZE)> r;
            r.core_ptr_.template constructAs<TCore>(std::forward<TCore>(core));
            return r;
        }

        /**
         * @brief 使用适配器核，构造自适应栈内存大小的迭代器
         */
        template <class TIterator>
        static auto fitCreateAdapter(TIterator it, typename iterator::AdapterCore<T, TIterator>::Func func = nullptr)
        {
            return fitCreate(iterator::AdapterCore<T, TIterator>(std::move(it), std::move(func)));
        }

        /**
         * @brief 使用封装器核，构造自适应栈内存大小的迭代器
         */
        template <class TIterator>
        static auto fitCreateWrapper(TIterator it)
        {
            return fitCreate(iterator::WrapperCore<T, TIterator>(std::move(it)));
        }

    public:
        template <class TCore>
        TCore* core()
        {
            return dynamic_cast<TCore*>(core_ptr_.get());
        }

        template <class TCore>
        const TCore* core() const
        {
            return dynamic_cast<const TCore*>(core_ptr_.get());
        }

    public:
        Iterator& operator++()
        {
            core_ptr_->move(1);
            return *this;
        }

        Iterator operator++(int)
        {
            Iterator result(*this);
            ++(*this);
            return result;
        }

        Iterator& operator--()
        {
            core_ptr_->move(-1);
            return *this;
        }

        const Iterator operator--(int)
        {
            Iterator result(*this);
            --(*this);
            return result;
        }

        Iterator& operator+=(long step)
        {
            core_ptr_->move(step);
            return *this;
        }

        Iterator& operator-=(long step)
        {
            core_ptr_->move(-step);
            return *this;
        }

        Iterator operator+(long step) const
        {
            return Iterator(*this) += step;
        }

        Iterator operator-(long step) const
        {
            return Iterator(*this) -= step;
        }

        T& operator*()
        {
            return core_ptr_->deref();
        }

        const T& operator*() const
        {
            return core_ptr_->deref();
        }

        T* operator->()
        {
            return &(core_ptr_->deref());
        }

        const T* operator->() const
        {
            return &(core_ptr_->deref());
        }

        long operator-(const Iterator& other) const
        {
            if (core_ptr_ == nullptr or other.core_ptr_ == nullptr)
                return 0;
            else
                return other.core_ptr_->stepCountTo(core_ptr_.get());
        }

        bool operator==(const Iterator& other) const
        {
            if (core_ptr_ == nullptr)
                return other.core_ptr_ == nullptr;
            else if (other.core_ptr_ == nullptr)
                return false;
            else
                return core_ptr_->equal(other.core_ptr_.get());
        }

        bool operator!=(const Iterator& other) const
        {
            return not operator==(other);
        }

        auto operator<(const Iterator& other) const
        {
            return operator-(other) < 0;
        }

        auto operator<=(const Iterator& other) const
        {
            return operator-(other) <= 0;
        }

        auto operator>(const Iterator& other) const
        {
            return operator-(other) > 0;
        }

        auto operator>=(const Iterator& other) const
        {
            return operator-(other) >= 0;
        }

    private:
        // 迭代操作器的数据指针
        CorePtr core_ptr_;

        // 让 Iterator 能访问它自己的变种
        template <class E, std::size_t OTHER_STACK_SIZE>
        friend class Iterator;
    };
}  // namespace zsibot::container

namespace zsibot
{
    template <class T, std::size_t STACK_SIZE = 1024>
    using iterator = zsibot::container::Iterator<T, STACK_SIZE>;
}
