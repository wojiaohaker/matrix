#pragma once

#include <zsibot/utils.hpp>


namespace zsibot::container::iterator
{
    template <class T>
    class ICore
    {
    public:
        /**
         * @brief 迭代指定步长，若用户重载该函数，则无需重载 last() 函数和 next() 函数。
         * @param step
         */
        virtual void move(long step)
        {
            if (step > 0)
            {
                while (step--)
                    next();
            }
            else
            {
                while (step++)
                    last();
            }
        }

        /**
         * @brief 向前迭代一步（用户重载该函数的同时，也需要重载 last() 函数）
         */
        virtual void next()
        {
            move(1);
        }

        /**
         * @brief 向后迭代一步（用户重载该函数的同时，也需要重载 next() 函数）
         */
        virtual void last()
        {
            move(-1);
        }

        /**
         * @return 解引用（non const 版本，与 const 版本两者仅需实现其中一个）
         */
        virtual T& deref()
        {
            return zsibot::utils::remove_const(zsibot::utils::add_const(this)->deref());
        }

        /**
         * @return 解引用（const 版本，与 non const 版本两者仅需实现其中一个）
         */
        virtual const T& deref() const
        {
            return zsibot::utils::add_const(zsibot::utils::remove_const(this)->deref());
        }

        /**
         * @brief 判断是否与另外一个操作子相等
         * @param other 可保证该参数绝对不等于 nullptr
         */
        virtual bool equal(const ICore* other) const = 0;

        /**
         * @brief 计算到另外一个迭代器的步长
         * @param other 可保证该参数绝对不等于 nullptr
         */
        virtual long stepCountTo(const ICore* other) const = 0;

        virtual ~ICore() = default;
    };
}  // namespace eon::container::iterator
