#pragma once

#include "zsibot/container/iterator/iterator_core.hpp"

namespace zsibot::binding::details
{
    template <class TView, class TMemIt>
    class SequenceViewIteratorCore : public zsibot::container::iterator::ICore<TView>
    {
        using Base = zsibot::container::iterator::ICore<TView>;
        using This = SequenceViewIteratorCore<TView, TMemIt>;

    public:
        SequenceViewIteratorCore(TMemIt it, TMemIt end_it)
            : it_(std::move(it)),
              end_it_(std::move(end_it))
        {
            setData();
        }

        void move(long step) final
        {
            it_ += step;
            setData();
        }

        void next() final
        {
            ++it_;
            setData();
        }

        void last() final
        {
            --it_;
            setData();
        }

        [[nodiscard]] const TView& deref() const final
        {
            return data_;
        }

        bool equal(const Base* other_base) const final
        {
            auto other = dynamic_cast<const This*>(other_base);
            return it_ == other->it_;
        }

        long stepCountTo(const Base* other_base) const final
        {
            auto other = dynamic_cast<const This*>(other_base);
            return std::distance(it_, other->it_);
        }

        const TMemIt& raw() const
        {
            return it_;
        }

    private:
        void setData()
        {
            if (it_ != end_it_)
                data_ = TView(*it_);
            else
                data_ = {};
        }

    private:
        // 内存布局迭代器
        TMemIt it_, end_it_;

        // 当前新建的视图对象
        TView data_;
    };

    template <class TKey, class TView, class TMemIt>
    class MapViewIteratorCore : public zsibot::container::iterator::ICore<std::pair<TKey, TView>>
    {
        using Pair = std::pair<TKey, TView>;
        using Base = zsibot::container::iterator::ICore<Pair>;
        using This = MapViewIteratorCore<TKey, TView, TMemIt>;

    public:
        MapViewIteratorCore(TMemIt it, TMemIt end_it)
            : it_(std::move(it)),
              end_it_(std::move(end_it))
        {
            setData();
        }

        void next() final
        {
            ++it_;
            setData();
        }

        void last() final
        {
            --it_;
            setData();
        }

        [[nodiscard]] const Pair& deref() const final
        {
            return data_;
        }

        bool equal(const Base* other_base) const final
        {
            auto other = dynamic_cast<const This*>(other_base);
            return it_ == other->it_;
        }

        long stepCountTo(const Base* other_base) const final
        {
            auto other = dynamic_cast<const This*>(other_base);
            return std::distance(it_, other->it_);
        }

        const TMemIt& raw() const
        {
            return it_;
        }

    private:
        void setData()
        {
            if (it_ != end_it_)
            {
                data_.first  = it_->first;
                data_.second = TView(it_->second);
            }
            else
                data_ = {};
        }

    private:
        // 内存布局迭代器
        TMemIt it_, end_it_;

        // 当前新建的键值及其视图对象
        Pair data_;
    };

    /**
     * @brief 提取原始迭代器
     */
    template <class TCore, class TIterator>
    static auto& rawIterator(const TIterator& it, const char* error_msg)
    {
        auto* core_ptr = it.template core<TCore>();

        if (core_ptr == nullptr)
            throw std::logic_error(error_msg);

        return core_ptr->raw();
    }
}  // namespace jszr::binding::details
