#pragma once

#include <functional>
#include <optional>

#include "zsibot/container/iterator/iterator_core.hpp"


namespace zsibot::container::iterator
{
    /**
     * @brief 类型适配迭代器，用于将对一个类型的迭代，转换为另外一个类型的迭代
     * @tparam T 最终需要被迭代的类型
     * @tparam TIterator 原类型的迭代器类型
     */
    template <class T, class TIterator>
    class AdapterCore : public ICore<T>
    {
        using Base = ICore<T>;
        using This = AdapterCore<T, TIterator>;

    public:
        using Func = std::function<T(const utils::iterator_type<TIterator>&)>;

    public:
        explicit AdapterCore(TIterator it, Func func = nullptr)
            : curr_(std::move(it)),
              func_(std::move(func))
        {
        }

    public:
        void next() override
        {
            ++curr_;
            data_.reset();
        }

        void last() override
        {
            --curr_;
            data_.reset();
        }

        T& deref() override
        {
            // 延迟计算
            if (not data_.has_value() and func_ != nullptr)
                data_.template emplace(func_(*curr_));

            return data_.value();
        }

        bool equal(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return curr_ == other->curr_;
        }

        long stepCountTo(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return std::distance(other->curr_, curr_);
        }

    private:
        TIterator curr_;
        Func      func_;

        std::optional<T> data_;
    };

    template <class T, class TIterator>
    class AdapterCore<T&, TIterator> : public ICore<T&>
    {
        using Base = ICore<T&>;
        using This = AdapterCore<T&, TIterator>;

    public:
        using Func = std::function<T&(const utils::iterator_type<TIterator>&)>;

    public:
        explicit AdapterCore(TIterator it, Func func = nullptr)
            : curr_(std::move(it)),
              func_(std::move(func))
        {
        }

    public:
        void next() override
        {
            ++curr_;
        }

        void last() override
        {
            --curr_;
        }

        T& deref() override
        {
            return func_(*curr_);
        }

        bool equal(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return curr_ == other->curr_;
        }

        long stepCountTo(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return std::distance(other->curr_, curr_);
        }

    private:
        TIterator curr_;
        Func      func_;
    };
}  // namespace zsibot::container::iterator
