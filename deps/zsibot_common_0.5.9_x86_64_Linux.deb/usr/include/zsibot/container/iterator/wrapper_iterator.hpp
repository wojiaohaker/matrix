#pragma once

#include "zsibot/container/iterator/iterator_core.hpp"


namespace zsibot::container::iterator
{
    /**
     * @brief 对另外一个迭代器的封装，
     * 可用于那些不继承于 iterator::ICore<T> 的迭代器，如 stl 中的迭代器。
     * @note 随机访问通过逐步迭代来实现。
     */
    template <class T, class TIterator>
    class WrapperCore : public ICore<T>
    {
        using Base = ICore<T>;
        using This = WrapperCore<T, TIterator>;

    public:
        explicit WrapperCore(TIterator it)
            : curr_(std::move(it))
        {
        }

    public:
        void next() override
        {
            ++curr_;
        }

        void last() override
        {
            --curr_;
        }

        T& deref() override
        {
            return *curr_;
        }

        const T& deref() const override
        {
            return *curr_;
        }

        bool equal(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return curr_ == other->curr_;
        }

        long stepCountTo(const Base* base) const override
        {
            auto other = dynamic_cast<const This*>(base);
            return std::distance(other->curr_, curr_);
        }

        /**
         * @return 原始迭代器数据
         */
        const TIterator& raw() const
        {
            return curr_;
        }

    private:
        TIterator curr_;
    };
}  // namespace jszr::container::iterator
