#pragma once

#include "zsibot/container/iterator/random_iterator.hpp"


namespace zsibot::container::iterator
{
    /**
     * @brief 封装了一个任意类型的、支持随机访问的迭代器，
     * 可用于不继承于 iterator::ICore<T> 的迭代器，如 stl 的迭代器。
     */
    template <class T, class TIterator>
    class RandomCore : public ICore<T>
    {
        using Base = ICore<T>;
        using This = RandomCore<T, TIterator>;

    public:
        explicit RandomCore(TIterator it)
            : iterator_(std::move(it))
        {
        }

        void move(long step) override
        {
            iterator_ += step;
        }

        const T& deref() const override
        {
            return *iterator_;
        }

        bool equal(const Base* other_base) const override
        {
            auto other = dynamic_cast<const This*>(other_base);

            return other != nullptr and iterator_ == other->iterator_;
        }

        long stepCountTo(const ICore<T>* other_base) const override
        {
            auto other = dynamic_cast<const This*>(other_base);

            return other == nullptr ? 0 : other->iterator_ - this->iterator_;
        }

    private:
        TIterator iterator_;
    };
}  // namespace jszr::container::iterator
