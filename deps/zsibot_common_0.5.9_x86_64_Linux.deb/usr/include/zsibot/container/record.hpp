#pragma once

#include <map>
#include <unordered_map>
#include <zsibot/thread_lock.hpp>

namespace zsibot::container
{
    /**
     * @brief 一个可锁的智能指针，用于 Record 类
     * @tparam T 不支持基础类型
     */
    template <class T>
    using RecordPtr = std::shared_ptr<zsibot::thread_lock::SharedLockable<T>>;

    namespace details
    {
        template <class TKey, class TValue>
        using map = std::map<TKey, TValue>;
    }

    /**
     * @brief 线程安全的索引型容器，增删查改接口都是线程安全的，
     * 每一个元素都是独立可锁的。
     * @tparam TKey 索引类型
     * @tparam TValue 数据类型
     * @tparam TContainer 底层容器类型
     */
    template <class TKey, class TValue, template <class EKey, class EValue> class TContainer = details::map>
    class Record
    {
    public:
        /**
         * @brief 本容器的元素类型
         */
        using Ptr = RecordPtr<TValue>;

    private:
        using PtrData   = zsibot::thread_lock::SharedLockable<TValue>;
        using Container = TContainer<TKey, Ptr>;

    public:
        /**
         * @brief 添加新的元素，返回是否添加成功
         * @param key 新元素的键值
         * @param args 创建该元素需要的构造参数
         * @return 是否添加成功；若指定键值的元素已经存在，将返回 false
         */
        template <class... TArgs>
        bool add(const TKey& key, TArgs&&... args)
        {
            ZSIBOT_WRITER_SYNCHRONIZED(data_)
            {
                auto [it, is_new] = addWithoutLock(key, std::forward<TArgs>(args)...);
                return is_new;
            }
        }

        /**
         * @brief 删除指定键值的元素
         */
        void remove(const TKey& key)
        {
            ZSIBOT_WRITER_SYNCHRONIZED(data_)
            {
                data_.erase(key);
            }
        }

        /**
         * @brief 清除所有的元素
         */
        void clear()
        {
            ZSIBOT_WRITER_SYNCHRONIZED(data_)
            {
                data_.clear();
            }
        }

        /**
         * @brief 获取指定的元素
         */
        Ptr get(const TKey& key) const
        {
            ZSIBOT_READER_SYNCHRONIZED(data_)
            {
                if (auto it = data_.find(key); it != data_.end())
                    return it->second;
                else
                    return {};
            }
        }

        /**
         * @brief 获取指定键值的元素，若这样的元素还不存在时，则进行创建
         */
        template <class... TArgs>
        Ptr getOrAdd(const TKey& key, TArgs&&... args)
        {
            // 先以读者锁的状态，查找当前容器里是否有指定键值的元素
            ZSIBOT_READER_SYNCHRONIZED(data_)
            {
                if (auto it = data_.find(key); it != data_.end())
                    return it->second;
            }

            // 当前容器没有指定键值的容器时，再以写者锁的状态进行创建
            ZSIBOT_WRITER_SYNCHRONIZED(data_)
            {
                auto [it, is_new] = addWithoutLock(key, std::forward<TArgs>(args)...);
                return it->second;
            }
        }

        /**
         * @brief 拷贝取出指定键值的元素
         * @throw std::out_of_range 若指定键值不存在时，将抛出异常
         */
        TValue copy(const TKey& key) const
        {
            ZSIBOT_READER_SYNCHRONIZED(data_)
            {
                if (auto it = data_.find(key); it != data_.end())
                    return static_cast<const TValue&>(*(it->second));
            }

            throw std::out_of_range("element with given key is not existed.");
        }

        /**
         * @brief 拷贝取出指定键值的元素；若该元素不存在时，返回回退值
         */
        TValue copyOr(const TKey& key, TValue fallback) const
        {
            ZSIBOT_READER_SYNCHRONIZED(data_)
            {
                if (auto it = data_.find(key); it != data_.end())
                    return static_cast<const TValue&>(*(it->second));
            }

            return fallback;
        }

    private:
        /**
         * @brief 无锁访问或创建新元素的统一接口
         */
        template <class... TArgs>
        std::pair<typename Container::iterator, bool> addWithoutLock(const TKey& key, TArgs&&... args)
        {
            auto [it, is_new] = data_.try_emplace(key);

            if (is_new)
            {
                it->second = std::make_shared<PtrData>(std::forward<TArgs>(args)...);
            }

            return { it, is_new };
        }

        zsibot::thread_lock::SharedLockable<Container> data_;
    };
}  // namespace zsibot::container

namespace zsibotc
{
    /**
     * @brief 可锁的智能数据指针，用于 jszrc::record 容器
     */
    template <class T>
    using record_ptr = zsibot::container::RecordPtr<T>;

    /**
     * @brief 线程安全的索引型数据，每一个元素也都是可锁的
     */
    template <class TKey, class TValue, template <class EKey, class EValue> class TContainer = zsibot::container::details::map>
    using record = zsibot::container::Record<TKey, TValue, TContainer>;
}  // namespace zsibotc
