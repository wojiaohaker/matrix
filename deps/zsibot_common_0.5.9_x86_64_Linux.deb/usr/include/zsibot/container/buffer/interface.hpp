#pragma once

namespace zsibot::container::buffer
{
    template <class T>
    class Interface
    {
    public:
        virtual ~Interface()             = default;
        virtual T&       at(int i)       = 0;
        virtual const T& at(int i) const = 0;
    };
}  // namespace zsibot::container::buffer
