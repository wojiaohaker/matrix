#pragma once

#include "zsibot/container/buffer/interface.hpp"
#include "zsibot/container/iterator.hpp"


namespace zsibot::container::buffer
{
    template <class T>
    class IteratorCore : public iterator::ICore<T>
    {
        using This = IteratorCore<T>;
        using Base = iterator::ICore<T>;
        using Core = Interface<typename std::remove_const<T>::type>;

    public:
        IteratorCore(const Core* core, int data_index)
            : core_(core),
              data_index_(data_index)
        {
        }

        void move(long step) override
        {
            data_index_ += step;
        }

        const T& deref() const override
        {
            return core_->at(data_index_);
        }

        bool equal(const Base* other_base) const override
        {
            auto other = dynamic_cast<const This*>(other_base);

            return other != nullptr and core_ == other->core_ and data_index_ == other->data_index_;
        }

        long stepCountTo(const Base* other_base) const override
        {
            auto other = dynamic_cast<const This*>(other_base);

            return other == nullptr ? 0 : other->data_index_ - this->data_index_;
        }

    private:
        const Core* core_       = nullptr;
        int         data_index_ = 0;
    };
}  // namespace zsibot::container::buffer
