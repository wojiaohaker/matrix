#pragma once

#include <cstring>
#include <functional>
#include <memory>

#include "zsibot/container/pointer/pointer_base.hpp"

namespace zsibot::container
{
    /**
     * @brief stack pointer，根据需要实例化的类型的占用内存大小，自动在
     * 受限制的栈内存与堆内存中进行选择。
     * @tparam T 对外的类型（可以是实例化的父类型）
     * @tparam MAX_STACK_SIZE 最大能接受的栈内存
     */
    template <class T, std::size_t MAX_STACK_SIZE>
    class StackPointer final : public details::PointerBase<T>
    {
        using Base = details::PointerBase<T>;

        // 确保本类对象 8 字节内存对齐（少了一个字节存放了额外的信息）
        static constexpr std::size_t MAX_STACK_CAPACITY = (MAX_STACK_SIZE / 8 + 1) * 8 - 1;

    public:
        StackPointer() = default;

        explicit StackPointer(std::nullptr_t) {}

        StackPointer(const StackPointer& other)
        {
            operator=(other);
        }

        StackPointer(StackPointer&& other) noexcept
        {
            operator=(std::move(other));
        }

        ~StackPointer() override
        {
            reset();
        }

        StackPointer& operator=(const StackPointer& other)
        {
            if (this == &other)
                return *this;

            reset();

            size_    = other.size_;
            state_   = other.state_;
            copy_op_ = other.copy_op_;

            if (state_ == State::Heap)
            {
                heap_ptr_ = (T*)(std::malloc(size_));
                copy_op_(heap_ptr_, other.heap_ptr_);
            }
            else if (state_ == State::Stack)
            {
                move_op_ = other.move_op_;
                copy_op_(stack_mem_, other.stack_mem_);
            }

            return *this;
        }

        StackPointer& operator=(StackPointer&& other) noexcept
        {
            if (this == &other)
                return *this;

            reset();

            size_    = other.size_;
            state_   = other.state_;
            copy_op_ = std::move(other.copy_op_);

            if (state_ == State::Heap)
            {
                heap_ptr_ = other.heap_ptr_;
                other.resetNoFree();
            }
            else if (state_ == State::Stack)
            {
                move_op_ = std::move(other.move_op_);
                move_op_(stack_mem_, other.stack_mem_);
                other.reset();
            }

            return *this;
        }

        StackPointer& operator=(std::nullptr_t)
        {
            reset();
            return *this;
        }

    public:
        template <class... Args>
        void construct(Args&&... args)
        {
            constructAs<T>(std::forward<Args>(args)...);
        }

        template <class E, class... Args>
        void constructAs(Args&&... args)
        {
            // 要求类型 E 为 T 的子类
            static_assert(std::is_base_of_v<T, E>);

            // 重置本对象已有的内容
            reset();

            // 记录被创建类型的大小
            size_ = sizeof(E);

            // 记录新创建的数据所在内存的首地址，
            // 该地址将根据这种类型的对象大小，以及可用的栈内存大小，
            // 自动在堆或栈中选择。
            // 将用于构造对象
            void* mem_ptr = nullptr;

            if constexpr (sizeof(E) <= MAX_STACK_CAPACITY)
            {
                // 该类型的对象的大小在可用的栈内存大小内，则使用该栈内存来创建对象
                heap_ptr_ = nullptr;
                state_    = State::Stack;
                mem_ptr   = stack_mem_;

                // 栈内存的对象 move 过程
                move_op_ = [](void* dst, void* src)
                {
                    new (dst) E(std::move(*(E*)(src)));
                };
            }
            else
            {
                // 该类型的对象大小过大，则使用堆内存
                heap_ptr_ = (T*)(std::malloc(size_));
                state_    = State::Heap;
                mem_ptr   = heap_ptr_;

                // 堆内存的对象 move 直接交换堆指针即可
            }

            // 该对象的拷贝过程
            copy_op_ = [](void* dst, const void* src)
            {
                new (dst) E(*(const E*)(src));
            };

            // 在给定的内存空间内构建对象
            new (mem_ptr) E(std::forward<Args>(args)...);
        }

        void reset() override
        {
            // 若指针没有初始化，则无事发生
            if (state_ == State::Undefined)
                return;

            // 析构已有的对象
            getRawPointer()->~T();

            // 若对象的内存来自堆，则析构它
            if (state_ == State::Heap)
                std::free(heap_ptr_);

            // 重置一些变量
            resetNoFree();
        }

    protected:
        T* getRawPointer() override
        {
            switch (state_)
            {
                case State::Stack:
                    return (T*)stack_mem_;
                case State::Heap:
                    return heap_ptr_;
                default:
                    return nullptr;
            }
        }

    private:
        void resetNoFree()
        {
            heap_ptr_ = nullptr;
            size_     = 0;
            state_    = State::Undefined;
            copy_op_  = nullptr;
            move_op_  = nullptr;
        }

    private:
        enum class State : char
        {
            Undefined,
            Stack,
            Heap
        };

    private:
        // 指向堆内存上的数据首地址
        T* heap_ptr_ = nullptr;

        // 数据的大小
        std::size_t size_ = 0;

        // 可用的栈内存
        char stack_mem_[MAX_STACK_CAPACITY]{};

        // 当前数据的状态
        State state_ = State::Undefined;

        // 被创建的类型的拷贝、移动函数
        std::function<void(void* dst, const void* src)> copy_op_;
        std::function<void(void* dst, void* src)>       move_op_;
    };
}  // namespace jszr::container

namespace zsibot
{
    template <class T, std::size_t MAX_STACK_SIZE>
    using stack_ptr = zsibot::container::StackPointer<T, MAX_STACK_SIZE>;
}
