#pragma once

#include <zsibot/utils.hpp>


namespace zsibot::container::details
{
    template <class T>
    class PointerBase
    {
    public:
        T* get()
        {
            return getRawPointer();
        }

        const T* get() const
        {
            return zsibot::utils::remove_const(this)->getRawPointer();
        }

        T* operator->()
        {
            return get();
        }

        const T* operator->() const
        {
            return get();
        }

        T& operator*()
        {
            return *get();
        }

        const T& operator*() const
        {
            return *get();
        }

        template <class E>
        E* get()
        {
            return dynamic_cast<E*>(get());
        }

        template <class E>
        const E* get() const
        {
            return dynamic_cast<const E*>(get());
        }

        T& deref()
        {
            return *get();
        }

        const T& deref() const
        {
            return *get();
        }

        template <class E>
        E& as()
        {
            return *get<E>();
        }

        template <class E>
        const E& as() const
        {
            return *get<E>();
        }

    public:
        explicit operator bool() const
        {
            return get() != nullptr;
        }

        bool operator==(const std::nullptr_t&) const
        {
            return get() == nullptr;
        }

        bool operator!=(const std::nullptr_t&) const
        {
            return get() != nullptr;
        }

        virtual void reset() = 0;

        virtual ~PointerBase() = default;

    protected:
        virtual T* getRawPointer() = 0;
    };
}  // namespace jszr::container::details
