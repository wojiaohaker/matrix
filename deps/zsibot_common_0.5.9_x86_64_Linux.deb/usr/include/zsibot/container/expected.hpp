#pragma once

#include <utility>
#include <variant>

#include <zsibot/macro.hpp>

namespace zsibot::container
{
    namespace expected
    {
        template <class T>
        class DataHolder
        {
        public:
            DataHolder(T&& data)
                : data_(std::move(data))
            {
            }

            DataHolder(const T& data)
                : data_(data)
            {
            }

            template <class... Args>
            DataHolder(Args&&... args)
                : data_(std::forward<Args>(args)...)
            {
            }

            ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(DataHolder);

            T& ref()
            {
                return data_;
            }

            const T& ref() const
            {
                return data_;
            }

            T copy() const
            {
                return data_;
            }

            T&& take()
            {
                return std::move(data_);
            }

        private:
            T data_;
        };

        template <>
        class DataHolder<void>
        {
        };

        template <class T>
        class DataHolder<T&>
        {
        public:
            DataHolder(T& data)
                : data_(data)
            {
            }

            T& ref()
            {
                return data_;
            }

            const T& ref() const
            {
                return data_;
            }

        private:
            T& data_;
        };

        template <class T>
        class DataHolder<T*>
        {
        public:
            DataHolder(T* data)
                : data_(data)
            {
            }

            ZSIBOT_DECLARE_DEFAULT_COPY(DataHolder);

            DataHolder(DataHolder&& other) noexcept
                : data_(other.data_)
            {
                other.data_ = nullptr;
            }

            DataHolder& operator=(DataHolder&& other) noexcept
            {
                if (this == &other)
                    return *this;

                data_       = other.data_;
                other.data_ = nullptr;

                return *this;
            }

            T* ptr()
            {
                return data_;
            }

            const T* ptr() const
            {
                return data_;
            }

            T* operator->()
            {
                return data_;
            }

            const T* operator->() const
            {
                return data_;
            }

        private:
            T* data_;
        };

        template <class T, class... Args>
        using VoidOrConstructible = ZSIBOT_CONCEPT((std::is_same_v<T, void> or std::is_constructible_v<T, Args...>));
    }  // namespace expected

    template <class T = void>
    class ExpectedValue : public expected::DataHolder<T>
    {
        using Base = expected::DataHolder<T>;

    public:
        ExpectedValue(T&& data)
            : Base(std::move(data))
        {
        }

        ExpectedValue(const T& data)
            : Base(data)
        {
        }

        template <class... Args, ZSIBOT_REQUIRES(zsibot::is<expected::VoidOrConstructible, T, Args...>)>
        ExpectedValue(Args&&... args)
            : Base(std::forward<Args>(args)...)
        {
        }

        ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(ExpectedValue);
    };

    template <class T>
    class ExpectedValue<T&> : public expected::DataHolder<T&>
    {
        using Base = expected::DataHolder<T&>;

    public:
        ExpectedValue(T& data)
            : Base(data)
        {
        }
    };

    template <class T>
    class ExpectedValue<T*> : public expected::DataHolder<T*>
    {
        using Base = expected::DataHolder<T*>;

    public:
        ExpectedValue(T* data)
            : Base(data)
        {
        }

        ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(ExpectedValue);
    };

    template <>
    class ExpectedValue<void>
    {
    };

    template <class T = void>
    class ExpectedError : public expected::DataHolder<T>
    {
        using Base = expected::DataHolder<T>;

    public:
        ExpectedError(T&& data)
            : Base(std::move(data))
        {
        }

        ExpectedError(const T& data)
            : Base(data)
        {
        }

        template <class... Args, ZSIBOT_REQUIRES(zsibot::is<expected::VoidOrConstructible, T, Args...>)>
        ExpectedError(Args&&... args)
            : Base(std::forward<Args>(args)...)
        {
        }

        ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(ExpectedError);
    };

    template <class T>
    class ExpectedError<T&> : public expected::DataHolder<T&>
    {
        using Base = expected::DataHolder<T&>;

    public:
        ExpectedError(T& data)
            : Base(data)
        {
        }
    };

    template <class T>
    class ExpectedError<T*> : public expected::DataHolder<T*>
    {
        using Base = expected::DataHolder<T*>;

    public:
        ExpectedError(T* data)
            : Base(data)
        {
        }

        ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(ExpectedError);
    };

    template <>
    class ExpectedError<void>
    {
    };

    /**
     *
     * @example记录了一个期望的值，或一个设计中的错误。支持普通类型、引用类型和指针类型。
     *
     * @code{.cpp}
     * struct Result
     * {
     * };
     *
     * struct Error
     * {
     * };
     *
     * zsibot::container::Expected<Result, Error> Calculate(int x)
     * {
     *     if (x == 0)
     *         return zsibot::container::ExpectedError(Error());
     *     else
     *         return zsibot::container::ExpectedValue(Result());
     * }
     *
     * auto opt = Calculate(3);
     *
     * if (opt.hasValue())
     *     Result result = opt.value().take(); // 使用移动语义取出
     *
     * if (opt.hasError())
     *     Error & error = opt.value().ref(); // 使用引用取出
     *
     * @example
     * zsibot::container::Expected<Result> Calculate(int x)
     * {
     *     return zsibot::container::ExpectedError(); // 使用空错误
     * }
     *
     * auto opt = Calculate(3);
     * opt.error().take(); // 将产生错误！
     * opt.value().copy(); // 使用拷贝取出
     * @endcode
     */

    /**
     * @brief 记录了一个期望的值，或一个设计中的错误。支持普通类型、引用类型和指针类型。
     */
    template <class TValue, class TError = void>
    class Expected
    {
    public:
        using ValueType = ExpectedValue<TValue>;
        using ErrorType = ExpectedError<TError>;
        using value_t   = ValueType;
        using error_t   = ErrorType;

    public:
        Expected(ValueType data)
            : data_(std::move(data))
        {
        }

        Expected(ErrorType error)
            : data_(std::move(error))
        {
        }

        ValueType& value()
        {
            return std::get<ValueType>(data_);
        }

        const ValueType& value() const
        {
            return std::get<ValueType>(data_);
        }

        ErrorType& error()
        {
            return std::get<ErrorType>(data_);
        }

        const ErrorType& error() const
        {
            return std::get<ErrorType>(data_);
        }

        [[nodiscard]] bool isSuccess() const
        {
            return data_.index() == 0;
        }

        [[nodiscard]] bool isError() const
        {
            return data_.index() == 1;
        }

        [[nodiscard]] bool hasValue() const
        {
            return isSuccess();
        }

        [[nodiscard]] bool hasError() const
        {
            return isError();
        }

        explicit operator bool() const
        {
            return isSuccess();
        }

        void neverFail() const
        {
            if (hasError())
                ZSIBOT_NEVER("fail for this expectation !");
        }

    private:
        std::variant<ValueType, ErrorType> data_;
    };
}  // namespace zsibot::container

namespace zsibotc
{
    template <class T = void>
    using expected_value = zsibot::container::ExpectedValue<T>;

    template <class T = void>
    using expected_error = zsibot::container::ExpectedError<T>;

    template <class TValue, class TError = void>
    using expected = zsibot::container::Expected<TValue, TError>;
}  // namespace zsibotc
