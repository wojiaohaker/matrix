#pragma once

#include <stdexcept>
#include <vector>

#include "zsibot/container/buffer/interface.hpp"
#include "zsibot/container/buffer/iterator_buf.hpp"


namespace zsibot::container
{
    /**
     * @brief Buffer 缓存类
     */
    template <class T>
    class Buffer final : public buffer::Interface<T>
    {
    public:
        Buffer()
            : Buffer(0)
        {
        }

        explicit Buffer(int size)
        {
            resize(size);
        }

        Buffer(int size, const T& value)
        {
            resize(size, value);
        }

        Buffer(const Buffer& other)
        {
            operator=(other);
        }

        Buffer(Buffer&& other) noexcept
        {
            operator=(std::move(other));
        }

        Buffer& operator=(const Buffer& other)
        {
            if (this == &other)
                return *this;

            data_        = other.data_;
            first_index_ = other.first_index_;
            end_index_   = other.end_index_;
            data_count_  = other.data_count_;
            buffer_size_ = other.buffer_size_;

            return *this;
        }

        Buffer& operator=(Buffer&& other) noexcept
        {
            if (this == &other)
                return *this;

            data_        = std::move(other.data_);
            first_index_ = other.first_index_;
            end_index_   = other.end_index_;
            data_count_  = other.data_count_;
            buffer_size_ = other.buffer_size_;

            other.first_index_ = 0;
            other.end_index_   = 0;
            other.data_count_  = 0;
            other.buffer_size_ = 0;

            return *this;
        }

    public:
        /**
         * @brief 根据索引获取数据，若传入负的索引，则将以倒序进行索引。
         */
        T& operator[](int i)
        {
            return at(i);
        }

        const T& operator[](int i) const
        {
            return at(i);
        }

        T& at(int i) override
        {
            return data_[getRealIndexWithCheck(i)];
        }

        const T& at(int i) const override
        {
            return data_[getRealIndexWithCheck(i)];
        }

        T& front()
        {
            return at(0);
        }

        const T& front() const
        {
            return at(0);
        }

        T& back()
        {
            return at(-1);
        }

        const T& back() const
        {
            return at(-1);
        }

        Iterator<T> begin()
        {
            return Iterator<T>::template create<buffer::IteratorCore<T>>(this, 0);
        }

        Iterator<T> end()
        {
            return Iterator<T>::template create<buffer::IteratorCore<T>>(this, data_count_);
        }

        Iterator<const T> begin() const
        {
            return Iterator<const T>::template create<buffer::IteratorCore<const T>>(this, 0);
        }

        Iterator<const T> end() const
        {
            return Iterator<const T>::template create<buffer::IteratorCore<const T>>(this, data_count_);
        }

    public:
        /**
         * @brief 追加一个元素到末尾
         */
        void push(T value)
        {
            // 容器无大小限制，则直接追加到末尾即可
            if (buffer_size_ < 0)
            {
                data_.push_back(std::move(value));
                ++data_count_;
                end_index_ = data_count_;
                return;
            }

            // 将新值写到尾部索引处
            data_[end_index_] = std::move(value);

            if (first_index_ == end_index_)
            {
                // 处理收尾相接的情况，指向头部的索引也需要往后移动；
                // 当没有数据的时候，也是收尾相接，这种情况需要排除。
                if (data_count_ != 0)
                {
                    ++first_index_;

                    if (first_index_ >= buffer_size_)
                        first_index_ = 0;
                }
            }

            if (data_count_ < buffer_size_)
                ++data_count_;

            if (++end_index_ >= buffer_size_)
                end_index_ = 0;
        }

        /**
         * @brief 调整 buffer 的大小，将产生数据拷贝
         * @param size 若小于零，则认为不限制 buffer 的大小。
         */
        void resize(int size)
        {
            if (buffer_size_ == size)
                return;

            // 新容器大小；若给定的 size 为负数，则保留当前全部的数据即可
            const int new_real_size = size < 0 ? data_count_ : size;

            // 新容器的数据量，取决于现有的数据数量以及新容器的大小；若新容器大小为无穷，则可以保留
            // 全部的已有数据。
            const int new_data_count = size < 0 ? data_count_ : std::min(size, data_count_);

            // 若原来的元素首索引为零，说明无需再挪动数据，简单重设容器大小即可；
            // 否则，需要新建容器，将数据挪动到容器开头
            if (first_index_ == 0)
                data_.resize(new_real_size);
            else
            {
                // 临时的新容器
                std::vector<T> temp;

                // 设置新容器的大小
                temp.resize(new_real_size);

                // 从更新的数据向旧的数据迭代，拷贝至新容器中
                for (int i = new_data_count - 1; i >= 0; --i)
                {
                    temp[i] = data_[getRealIndex(i)];
                }

                // 交换新旧容器数据
                std::swap(data_, temp);
            }

            // 更新状态数据，此时所有保留下的数据，都已经对齐到索引零
            first_index_ = 0;
            end_index_   = new_data_count == size ? 0 : new_data_count;
            data_count_  = new_data_count;
            buffer_size_ = size;
        }

        /**
         * @brief 调整 buffer 大小，并填充空出来的位置
         * @param size
         * @param value
         */
        void resize(int size, const T& value)
        {
            resize(size);
            fill(value);
        }

        /**
         * @brief 预分配内存
         */
        void reserve(std::size_t capacity)
        {
            data_.reserve(std::max(data_.size(), capacity));
        }

        /**
         * @brief 填充 buffer 所有的空位（往后填充）
         * @param value
         */
        void fill(const T& value)
        {
            if (buffer_size_ < 0)
                return;

            for (int i = data_count_; i < buffer_size_; ++i)
                data_[getRealIndex(i)] = value;

            end_index_  = first_index_;
            data_count_ = buffer_size_;
        }

        /**
         * @brief 将现有的元素填充为指定的值
         * @param value
         */
        void assign(const T& value)
        {
            for (int i = 0; i < data_count_; ++i)
                data_[getRealIndex(i)] = value;
        }

        void clear()
        {
            first_index_ = 0;
            end_index_   = 0;
            data_count_  = 0;
        }

        T pop()
        {
            if (data_count_ == 0)
                throw std::out_of_range("pop an empty buffer");

            // 若缓存大小没有限制，则直接删除容器内的第一个元素
            if (buffer_size_ < 0)
            {
                T result = std::move(data_.front());
                data_.erase(data_.begin());

                // 数量计数减一
                --data_count_;
                return result;
            }

            // 取出当前最旧的数据
            T result = std::move(data_[getRealIndex(0)]);

            // 数量计数减一
            --data_count_;

            // 首元素索引往前递增，若超出容器限制，则归零
            if (++first_index_ >= buffer_size_)
                first_index_ = 0;

            return result;
        }

        /**
         * @brief 删除指定序号的元素
         */
        void erase(int data_index)
        {
            // 若当前缓存大小无限制，则直接删除即可
            if (buffer_size_ < 0)
            {
                data_.erase(data_.begin() + data_index);
                --data_count_;
                return;
            }

            // 取出真实的数据索引
            int real_index = getRealIndexWithCheck(data_index);

            // 如果是第一个元素，则直接删除
            if (real_index == first_index_)
            {
                pop();
                return;
            }

            // 如果是最后一个元素，则直接删除
            if (real_index == end_index_)
            {
                --data_count_;

                // 更新尾部元素索引值
                if (end_index_ == 0)
                    end_index_ = buffer_size_ - 1;
                else
                    --end_index_;

                return;
            }

            // 如果是中间的元素，则需要移动后面的元素
            if (real_index < end_index_)
            {
                for (int i = real_index; i < end_index_ - 1; ++i)
                    data_[i] = std::move(data_[i + 1]);
            }
            else
            {
                for (int i = real_index; i > first_index_; --i)
                    data_[i] = std::move(data_[i - 1]);
            }

            // 数据计数减一
            --data_count_;

            // 首元素索引往前递增，若超出容器限制，则归零
            if (++first_index_ >= buffer_size_)
                first_index_ = 0;
        }

        void erase(Iterator<T> it)
        {
            erase(it - begin());
        }

    public:
        [[nodiscard]] int size() const
        {
            return buffer_size_;
        }

        [[nodiscard]] int count() const
        {
            return data_count_;
        }

        [[nodiscard]] bool empty() const
        {
            return data_count_ == 0;
        }

    private:
        [[nodiscard]] int getRealIndexWithCheck(int data_index) const
        {
            if (data_index >= data_count_ or data_index < -data_count_)
                throw std::runtime_error("buffer index out of range");

            return getRealIndex(data_index);
        }

        /**
         * @brief 获取指定序列的元素，在 data_ 中的索引值
         * @param data_index
         * @return
         */
        [[nodiscard]] int getRealIndex(int data_index) const
        {
            // 若容器范围无限制，则给定索引即为真实索引
            if (buffer_size_ < 0)
            {
                if (data_index >= 0)
                    return data_index;
                else
                    return data_count_ + data_index;
            }

            if (data_index >= 0)
            {
                // 处理正序索引
                data_index += first_index_;
                if (data_index >= buffer_size_)
                    data_index -= buffer_size_;
            }
            else
            {
                // 处理倒序索引
                data_index += end_index_;
                if (data_index < 0)
                    data_index += buffer_size_;
            }

            return data_index;
        }

    private:
        std::vector<T> data_;

        int first_index_ = 0;  // 首个元素的索引值
        int end_index_   = 0;  // 最后一个元素的索引值 + 1
        int data_count_  = 0;  // 元素总数
        int buffer_size_ = 0;  // 缓冲区大小
    };
}  // namespace zsibot::container

namespace zsibotc
{
    template <class T>
    using buffer = zsibot::container::Buffer<T>;
}
