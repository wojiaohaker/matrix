//
// Created by kanonwy on 2024/11/6
//

#pragma once

#include <filesystem>

namespace zsibot::base
{

    /**
     * @brief get current program argc
     */
    int argc();

    /**
     * @brief get current program argv
     */
    char** argv();

    /**
     * @brief get current program fs::path
     */
    const std::filesystem::path& path();

    /**
     * @brief  获取当前时间字符串
     * @return
     */
    std::string getCurrentDateString();

    /**
     * @brief get current program pid
     *
     */
    int pid();

    /**
     * @brief get current program pwd
     */
    const char* pwd();

    /**
     * @brief get current program's name
     */
    std::string getProgramName();

    /**
     * @brief get program log name
     */
    std::string getProgramLogName();

    /**
     * @brief get log ptah
     */
    std::filesystem::path getLogPath();

    /**
     * @brief get default log dir
     */
    std::filesystem::path getDefaultLogDir();

    /**
     * @brief get tmp log path
     */
    std::filesystem::path getTmpLogPath();

    /**
     * @brief get default tmp log dir
     */
    std::filesystem::path getDefaultTmpLogDir();

}  // namespace zsibot::base
