#pragma once

#include "zsibot/base/framework.hpp"
#include "zsibot/base/init_config.hpp"
#include "zsibot/modules/module.hpp"

namespace zsibot::base
{
    static constexpr int64_t JSZR_SELF_START_MANAGER_ID = 2147483647;

    template <class TFinalType, int64_t INSTANCE_ID = 0>
    class SelfStartModuleBase : public module::Module<TFinalType, INSTANCE_ID, JSZR_SELF_START_MANAGER_ID>
    {
        using Base = module::Module<TFinalType, INSTANCE_ID, JSZR_SELF_START_MANAGER_ID>;

    protected:
        /**
         * @brief 系统模块的启动入口， 接口类
         * @param self 用于函数重载识别
         * @param init_config 启动参数
         * @return 是否启动成功
         */
        virtual bool onStartSys(SelfStartModuleBase* self, const InitConfig& init_config) = 0;

        /**
         * @brief 系统模块的关闭接口
         * @param self 用于函数重载识别
         * @param init_config
         */
        virtual void onCloseSys(SelfStartModuleBase* self, const InitConfig& init_config)
        {
            ZSIBOT_UNUSED(self, init_config);
        };

        /**
         * @brief 继承于基类的 onStartModule() 函数
         */
        bool onStartModule(Base* self) final
        {
            ZSIBOT_UNUSED(self);
            return onStartSys(this, GetInitConfig());
        }

        /**
         * @brief 继承于基类的 onStopModule() 函数
         */
        void onStopModule(Base* self) final
        {
            ZSIBOT_UNUSED(self);
            onCloseSys(this, GetInitConfig());
        }
    };
}  // namespace zsibot::base


namespace zsibot::self_start
{

    template <int64_t MANAGER_ID = 0>
    void setup()
    {
        module::GlobalUnique<module::ModuleManager, MANAGER_ID>::ref().setup();
    }


    template <int64_t MANAGER_ID = 0>
    void shutdown()
    {
        module::GlobalUnique<module::ModuleManager, MANAGER_ID>::ref().shutdown();
    }
}  // namespace zsibot::self_start