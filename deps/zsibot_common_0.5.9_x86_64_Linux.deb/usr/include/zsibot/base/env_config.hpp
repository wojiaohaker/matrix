#pragma once

#include <filesystem>
#include <zsibot/log/logger.hpp>

namespace zsibot::base
{
    // ZSIBOT_LOG_DIR can change log dir location!

    /**
     * @brief get log threadpool item size
     * @details default size = 1000
     * @note ENV name = "ZSIBOT_LOG_ITEM_SIZE"
     */
    int getEnvLogThreadItemSize();

    /**
     * @brief get log threadpool size
     * @details default size = 1
     * @note ENV name = "ZSIBOT_LOG_THREAD_SIZE"
     */
    int getEnvLogThreadPoolSize();

    /**
     * @brief get single log file size from env param
     * @details default size = 100 MB
     * @note ENV name = "ZSIBOT_LOG_SIZE"
     */
    long getEnvLogFileSizeByte();


    /**
     * @brief  get log file number from env param
     * @details default size = 5
     * @note ENV name = "ZSIBOT_LOG_NUM"
     */
    int getEnvLogFileNumber();


    /**
     * @brief get param dir from env param
     * @details default = "${HOME}/.zsibot/param/${PROGRAM_NAME}/"
     * @note ENV name = "ZSIBOT_PARAM_DIR"
     */
    std::filesystem::path getEnvParamDir();

    /**
     * @brief get param use stdout or not from env param
     * @details default = false
     * @note ENV name ="ZSIBOT_LOG_STDOUT"
     */
    bool getEnvLogStdout();

    /**
     * @brief get param use
     */
    zsibot::log::level::level_enum getLogLevelByEnvparam();


    /**
     * @brief get tmp log file size from env param
     */
    long getEnvTmpLogFileSizeByte();


    /**
     * @brief get tmp log file number from env param
     */
    int getEnvTmpLogFileNumber();


}  // namespace zsibot::base
