#pragma once

#include <map>
#include <string>

namespace zsibot::base
{
    struct Version
    {
        int major = 0;
        int minor = 0;
        int patch = 0;
    };

    struct InitConfig
    {
        bool                               authorized = false;
        std::string                        node_name;
        Version                            program_version;
        std::map<std::string, std::string> parameters;
    };
}  // namespace zsibot::base
