//
// Created by kanonwy on 2024/11/6
//

#pragma once

#include <cstdlib>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <sys/types.h>
#include <type_traits>

#include "zsibot/macro/fancier.hpp"

/**
 * @brief  jszr base 所在命名空间，包含了一些基础工具
 */
namespace zsibot::base
{

    /**
     *@brief 环境变量输出的概念
     */
    template <typename T>
    using ENV_OUT_PUT_CONCEPT = ZSIBOT_CONCEPT((std::is_same_v<T, int> or std::is_same_v<T, long> or std::is_same_v<T, std::string>));

    /**
     * @brief  辅助环境变量读取类
     * @tparam T 环境变量的读取类型
     */
    template <typename T, ZSIBOT_REQUIRES(zsibot::is<ENV_OUT_PUT_CONCEPT, T>)>
    struct JszrEnvReader
    {
        /**
         * @brief 读取环境变量值
         * @param env_param_str 环境变量名称
         * @return
         */
        static std::optional<T> read(const std::string& env_param_str)
        {
            const char* env = std::getenv(env_param_str.data());
            if (env == nullptr)
            {
                return {};
            }
            if constexpr (std::is_same_v<T, int>)
            {
                try
                {
                    int res = std::stoi(env);
                    return res;
                }
                catch (const std::invalid_argument& e)
                {
                    std::cerr << "stoi() catch except: " << env << " . except reason: invalid_argument" << e.what() << std::endl;
                    return {};
                }
                catch (const std::out_of_range& e)
                {
                    std::cerr << "stoi() catch except: " << env << " . except reason: out_of_range" << e.what() << std::endl;
                    return {};
                }
                catch (...)
                {
                    std::cerr << "stoi() catch except: unknow" << std::endl;
                    return {};
                }
            }
            else if constexpr (std::is_same_v<T, long>)
            {
                try
                {
                    int res = std::stol(env);
                    return res;
                }
                catch (const std::invalid_argument& e)
                {
                    std::cerr << "stol() catch except: " << env << " . except reason: invalid_argument" << e.what() << std::endl;
                    return {};
                }
                catch (const std::out_of_range& e)
                {
                    std::cerr << "stol() catch except: " << env << " . except reason: out_of_range" << e.what() << std::endl;
                    return {};
                }
                catch (...)
                {
                    std::cerr << "stol() catch except: unknow" << std::endl;
                    return {};
                }
            }
            else if constexpr (std::is_same_v<T, std::string>)
            {
                return std::string{ env };
            }
            return {};
        }
    };

    /**
     * @brief  读取 int 类型的环境变量
     */
    using EnvVarInt = JszrEnvReader<int>;

    /**
     * @brief  读取 string 类型的环境变量
     */
    using EnvVarStr = JszrEnvReader<std::string>;

    /**
     * @brief  读取 Long 类型的环境变量
     */
    using EnvVarLong = JszrEnvReader<long>;


}  // namespace zsibot::base
