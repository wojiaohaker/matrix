//
// Created by kanonwy on 2024/11/6
//

#pragma once

#include <functional>

#include "zsibot/base/init_config.hpp"

/**
 * @brief jszr 框架启动所在的命名空间
 */
namespace zsibot
{
    /**
     * @brief jszr framework init
     * @param handle_signal deal signal or not
     */
    void initialize(bool handle_signal = true);

    /**
     * @brief jszr framework finished
     */
    void finalize();

    /**
     * @brief jszr framework exist ?
     */
    bool ok();


    void join();

    void finalize();

    /**
     * @brief force terminate the jszr framework
     */
    void terminate();

    /**
     * @brief join the signal to exist!
     */
    void joinAndFinalize();

    /**
     * @brief  注册一个信号处理
     */
    std::size_t signal(int sig, std::function<void(int siganl)> handler);

    /**
     * @brief  注册信号处理
     * @param sig
     * @param handler
     * @return
     */
    std::size_t signal(int sig, std::function<void(int signal, std::size_t handler_index)> handler);

    /**
     * @brief 打印开始 logo
     */
    void print_logo_start();

    /**
     * @brief 打印结束 logo
     */
    void print_logo_end();
}  // namespace zsibot


namespace zsibot::base
{
    const InitConfig& GetInitConfig();
}
