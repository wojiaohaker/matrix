//
// Created by kanonwy on 2024/12/25
//

#pragma once

#include "zsibot/macro.hpp"
#include "zsibot/modules/global_unique.hpp"
#include "zsibot/modules/module_base.hpp"
#include "zsibot/modules/module_manager.hpp"

namespace zsibot::module
{

    /**
     * @brief 模块抽象
     * @tparam TFinalType
     * @tparam INSTANCE_ID
     * @tparam MANAGER_ID
     */
    template <class TFinalType, int64_t INSTANCE_ID = 0, int64_t MANAGER_ID = 0>
    class Module : public ModuleBase
    {
    public:
        Module()
        {
            ZSIBOT_UNUSED(init_helper_);
        }

    protected:
        virtual bool onStartModule(Module* self) = 0;

        virtual void onStopModule(Module* self)
        {
            ZSIBOT_UNUSED(self);
        }

        /**
         * @brief 实现基类 ModuleBase 的接口
         */
        bool onStart(ModuleBase*) final
        {
            return onStartModule(this);
        }

        /**
         * @brief 实现基类 ModuleBase 的接口
         */
        void onClose(ModuleBase*) final
        {
            onStopModule(this);
        }

    private:
        /// 辅助模块注册静态成员，防止被优化
        static std::byte init_helper_;
    };

    template <class TFinalType, int64_t INSTANCE_ID, int64_t MANAGER_ID>
    std::byte Module<TFinalType, INSTANCE_ID, MANAGER_ID>::init_helper_ = []() -> std::byte
    {
        GlobalUnique<ModuleManager, MANAGER_ID>::ref().addModule(GlobalUnique<TFinalType, INSTANCE_ID>::ref());
        return {};
    }();
}  // namespace zsibot::module


/**
 * @brief ZSIBOT_NOT_OPTIMIZE_OUT_GLOBAL_UNIQUE(<type>)
 * @pre
 * 避免自启动的模块由于没有在 main 函数中显式调用而被编译器优化, 从而导致自启动模块无法运行.
 * 需要在全局域中使用（源文件中）。
 *
 * @example
 * @code{.cpp}
 * // 某一个模块
 * class MyModule
 * {
 *    //...
 * };
 *
 * ZSIBOT_NOT_OPTIMIZE_OUT_GLOBAL_UNIQUE(MyModule);
 *
 * @endcode
 */


#define ZSIBOT_NOT_OPTIMIZE_OUT_GLOBAL_UNIQUE(...)                                                                                         \
    namespace details_no_optimize_out                                                                                                      \
    {                                                                                                                                      \
        static const std::byte ZSIBOT_COUNTER_UNIQUE(_no_optimize_helper_) = []()->std::byte {zsibot::module::GlobalUnique<__VA_ARGS__>::ref();   return {};}();                                                                                                                             \
    }
