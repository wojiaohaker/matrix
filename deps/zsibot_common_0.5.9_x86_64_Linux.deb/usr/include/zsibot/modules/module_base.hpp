//
// Created by kanonwy on 2024/12/25
//

#pragma once

#include "zsibot/macro.hpp"
#include "zsibot/modules/policy.hpp"

namespace zsibot::module
{
    class ModuleManager;

    class ModuleBase
    {

    public:
        virtual ~ModuleBase() = default;
        friend class ModuleManager;

    protected:
        /**
         * @return 本自启动模块的启动配置，记录了名称、优先级、依赖等信息
         */
        virtual Policy getSelfStartPolicy() = 0;

        /**
         * @brief 本模块的启动入口
         * @param self 用于函数重载识别
         * @return 是否启动成功
         */
        virtual bool onStart(ModuleBase* self) = 0;

        /**
         * @brief 本模块的关闭入口
         * @param self 用于函数重载识别
         */
        virtual void onClose(ModuleBase* self)
        {
            ZSIBOT_UNUSED(self);
        };
    };

}  // namespace zsibot::module
