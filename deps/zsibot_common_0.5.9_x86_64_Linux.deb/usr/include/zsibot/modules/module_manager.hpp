//
// Created by kanonwy on 2024/12/25
//

#pragma once

#include <list>
#include <map>
#include <mutex>
#include <string>
#include <vector>

#include "zsibot/modules/module.hpp"
#include "zsibot/modules/module_base.hpp"

namespace zsibot::module
{
    class ModuleManager
    {
    public:
        /**
         * @brief 添加一个自启动模块
         * @note 需要在启动中心运行前，调用本函数做完全部模块的设置
         * @param module 需确保其生命周期在运行过程中均存在
         */
        void addModule(ModuleBase& module);

        /**
         * @brief 按规则启动所有注册的自启动模块，优先级高的先启动
         */
        void setup();

        /**
         * @brief 按规则注销全部自启动模块，注销顺序与启动顺序相反
         */
        void shutdown();

        /**
         * @brief 本类会在析构时调用 shutdown() 函数，但使用者最好在
         * 可控的流程中主动调用，以防止一些未知 bug 出现。
         */
        ~ModuleManager();

    private:
        /**
         * @brief 递归设置指定模块的依赖模块、以及这些依赖的依赖模块，形成模块依赖表、依赖链路，
         * 从而检查是否存在循环依赖、缺失的依赖、以及优先级颠倒的依赖情况。
         * @param name 指定的模块名称
         * @param depending_chain 在递归设置过程中形成的依赖链路，用于循环依赖检查
         * @param modules_dependencies 模块依赖表，索引是模块名，而值它的所有依赖模块（包括依赖模块的依赖模块）
         *
         * @note 这是一个递归函数，注意无限递归
         */
        void findDependencies(const std::string& name, std::list<std::string>& depending_chain,
            std::map<std::string, std::set<std::string>>& modules_dependencies);

        /**
         * @brief  模块结构体
         */
        struct Module
        {
            Policy      policy;
            ModuleBase* module = nullptr;
        };

        /// 保证本中心启动、关闭时线程安全
        std::mutex mutex_;

        /// 确保不会被重复启动
        bool started_ = false;

        /// 按名索引的全部模块
        std::map<std::string, Module> named_modules_;

        /// 按优先级排序的全部模块
        std::map<unsigned, std::vector<Module>> ordered_modules_;

        /// 按启动顺序排序的全部模块
        std::vector<Module> ordered_started_modules_;
    };
}  // namespace zsibot::module