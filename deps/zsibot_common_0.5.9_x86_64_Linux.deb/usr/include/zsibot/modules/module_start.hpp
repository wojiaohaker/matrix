//
// Created by kanonwy on 2024/12/25
//

#pragma once

#include "zsibot/modules/global_unique.hpp"
#include "zsibot/modules/module_manager.hpp"
#include <cstdint>

namespace zsibot::module
{
    /**
     * @brief 按一定顺序初始化全部注册的自启动模块
     * @tparam MANAGER_ID 管理单位 id
     */
    template <int64_t MANAGER_ID = 0>
    void setup()
    {
        zsibot::module::GlobalUnique<zsibot::module::ModuleManager, MANAGER_ID>::ref().setup();
    }

    /**
     * @brief 按一定初始化的倒序，注销全部自启动模块
     * @tparam MANAGER_ID 管理单位 id
     */
    template <int64_t MANAGER_ID = 0>
    void shutdown()
    {
        zsibot::module::GlobalUnique<zsibot::module::ModuleManager, MANAGER_ID>::ref().shutdown();
    }
}  // namespace zsibot::module