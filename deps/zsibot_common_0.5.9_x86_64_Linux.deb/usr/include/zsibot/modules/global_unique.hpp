//
// Created by kanonwy on 2024/12/25
//

#pragma once

#include <cstdint>

namespace zsibot::module
{

    /**
     * @brief 全局唯一修饰器
     * @tparam T 目标类型，使其获得全局唯一单例
     * @tparam N 全局单例编号，不同编号可产生不同单例，但单例永远都是有限已知的
     * @warning 用户不应该在构造函数、析构函数中，调用别的由本类修饰的单例对象！！
     */
    template <class T, int64_t N = 0>
    class GlobalUnique
    {
    public:
        static T& ref()
        {
            static T instance;
            return instance;
        }

        static T* ptr()
        {
            return &ref();
        }
    };
}  // namespace zsibot::module
