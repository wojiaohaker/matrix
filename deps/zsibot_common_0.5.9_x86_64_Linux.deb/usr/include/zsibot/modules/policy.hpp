//
// Created by kanonwy on 2024/12/25
//
#pragma once

#include <cstdint>
#include <set>
#include <string>

namespace zsibot::module
{

    /**
     * @brief 自启动模块的策略，控制控制模块之间的关系，模块的优先级.
     */
    struct Policy
    {
        /// 本模块的名称（要求唯一，至少在一个管理单位下全局唯一）
        std::string name;

        /// 本模块启动之前，需要启动的其他模块
        std::set<std::string> dependencies;

        /// 值越小，优先级越大，用户级别的模块，应该使用小的优先级（也即值应该大一些）
        uint8_t priority = 100;
    };

}  // namespace zsibot::module
