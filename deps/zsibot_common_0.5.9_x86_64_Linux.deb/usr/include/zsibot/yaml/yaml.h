#ifndef jszr_YAML_H_62B23520_7C8E_11DE_8A39_0800200C9A66
#define jszr_YAML_H_62B23520_7C8E_11DE_8A39_0800200C9A66

#if defined(_MSC_VER) ||                                            \
    (defined(__GNUC__) && (__GNUC__ == 3 && __GNUC_MINOR__ >= 4) || \
     (__GNUC__ >= 4))  // GCC supports "pragma once" correctly since 3.4
#pragma once
#endif

#include "zsibot/yaml/parser.h"
#include "zsibot/yaml/emitter.h"
#include "zsibot/yaml/emitterstyle.h"
#include "zsibot/yaml/stlemitter.h"
#include "zsibot/yaml/exceptions.h"

#include "zsibot/yaml/node/node.h"
#include "zsibot/yaml/node/impl.h"
#include "zsibot/yaml/node/convert.h"
#include "zsibot/yaml/node/iterator.h"
#include "zsibot/yaml/node/detail/impl.h"
#include "zsibot/yaml/node/parse.h"
#include "zsibot/yaml/node/emit.h"

#endif  // YAML_H_62B23520_7C8E_11DE_8A39_0800200C9A66
