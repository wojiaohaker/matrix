#pragma once

#include "zsibot/binding/object.hpp"
#include "zsibot/binding/yaml/builder.hpp"
#include "zsibot/binding/yaml/object_creator.hpp"

namespace zsibot::binding
{
    /**
     * @brief 将 binding object 转换为 yaml 对象
     *
     * 生成的 yaml 对象中，可能包含两种根元素：
     *   - '_': 记录 object 的全部信息；
     *   - '__enums__': 记录 object 中涉及的所有枚举量信息表；
     *
     * @note 后续相关接口均有相同设计。
     */
    zsibot::yaml::Node toYaml(const Object& obj, yaml::Builder<Object>&& builder = {});

    /**
     * @brief 将 binding object 转换为 yaml 对象
     */
    zsibot::yaml::Node toYaml(const Object& obj, yaml::Builder<Object>& builder);

    /**
     * @brief 将 binding object view 转换为 yaml 对象
     */
    zsibot::yaml::Node toYaml(const ObjectView& obj, yaml::Builder<ObjectView>&& builder = {});

    /**
     * @brief 将 binding object view 转换为 yaml 对象
     */
    zsibot::yaml::Node toYaml(const ObjectView& obj, yaml::Builder<ObjectView>& builder);

    /**
     * @brief 将 binding object view 转换为 yaml 对象
     */
    zsibot::yaml::Node toYaml(const ObjectConstView& obj, yaml::Builder<ObjectView>&& builder = {});

    /**
     * @brief 将 binding object view 转换为 yaml 对象
     */
    zsibot::yaml::Node toYaml(const ObjectConstView& obj, yaml::Builder<ObjectView>& builder);

    /**
     * @brief 将 yaml 对象转换为 binding object
     */
    Object fromYaml(const zsibot::yaml::Node& yaml, yaml::ObjectCreator&& creator = {});

    /**
     * @brief 将 yaml 对象转换为 binding object
     */
    Object fromYaml(const zsibot::yaml::Node& yaml, yaml::ObjectCreator& creator);
}  // namespace zsibot::binding
