#pragma once

#include "zsibot/binding/macro_helper.hpp"
#include "zsibot/binding/object/object_type.hpp"
#include "zsibot/binding/object/object_mem.hpp"
#include "zsibot/binding/object/type_base.hpp"
#include "zsibot/binding/object/type_info.hpp"
#include "zsibot/binding/object/value_base.hpp"


namespace zsibot::binding
{

    template <class T>
    constexpr std::size_t hash()
    {
        return details::getTypeInfo<T>().hash_code;
    }

    template <class T>
    constexpr const char* name()
    {
        return details::getTypeInfo<T>().name;
    }
}  // namespace zsibot::binding


#define ZSIBOT_BINDING_VALUE(_type_)                                                                                                         \
    ZSIBOT_DETAILS_BINDING_REGISTER_TYPE_INFO(::_type_)                                                                                      \
    ZSIBOT_DETAILS_BINDING_IMPL_IS_VALUE(::_type_)


#define ZSIBOT_BINDING_OBJECT(_type_, ...)                                                                                                   \
    ZSIBOT_DETAILS_BINDING_REGISTER_TYPE_INFO(::_type_)                                                                                      \
    ZSIBOT_DETAILS_BINDING_IMPL_FIELDS_FILLING(::_type_, __VA_ARGS__)                                                                        \
    ZSIBOT_DETAILS_BINDING_IMPL_FIELDS_VISITING(::_type_, __VA_ARGS__)
