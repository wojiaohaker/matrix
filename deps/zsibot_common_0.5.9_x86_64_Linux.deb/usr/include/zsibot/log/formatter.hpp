#pragma once

#include <zsibot/log/details/log_msg.hpp>
#include <zsibot/fmt/format.h>

namespace zsibot::log {

    class formatter {
    public:
        virtual ~formatter() = default;
        virtual void format(const details::log_msg &msg, memory_buf_t &dest) = 0;
        virtual std::unique_ptr<formatter> clone() const = 0;
    };
}  // namespace spdlog
