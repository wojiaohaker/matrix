#pragma once

#include <zsibot/log/details/null_mutex.hpp>
#include <zsibot/fmt/format.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <exception>
#include <functional>
#include <initializer_list>
#include <memory>
#include <string>
#include <type_traits>


#define ZSIBOTLOG_FMT_RUNTIME(format_string) fmt::runtime(format_string)
#define ZSIBOTLOG_FMT_STRING(format_string)  FMT_STRING(format_string)


#if FMT_USE_CONSTEXPR
#define ZSIBOTLOG_CONSTEXPR_FUNC FMT_CONSTEXPR
#endif

#define ZSIBOTLOG_DEPRECATED __attribute__((deprecated))

#ifndef ZSIBOTLOG_FUNCTION
#define ZSIBOTLOG_FUNCTION static_cast<const char*>(__FUNCTION__)
#endif

#ifdef ZSIBOTLOG_NO_EXCEPTIONS
#define ZSIBOTLOG_TRY
#define ZSIBOTLOG_THROW(ex)                                                                                                                \
    do                                                                                                                                     \
    {                                                                                                                                      \
        printf("spdlog fatal error: %s\n", ex.what());                                                                                     \
        std::abort();                                                                                                                      \
    }                                                                                                                                      \
    while (0)
#define ZSIBOTLOG_CATCH_STD
#else
#define ZSIBOTLOG_TRY       try
#define ZSIBOTLOG_THROW(ex) throw(ex)
#define ZSIBOTLOG_CATCH_STD                                                                                                                \
    catch (const std::exception&) {}
#endif

namespace zsibot::log
{
    class formatter;

    namespace sinks
    {
        class sink;
    }
    using filename_t = std::string;
#define ZSIBOTLOG_FILENAME_T(s) s

    using log_clock       = std::chrono::system_clock;
    using sink_ptr        = std::shared_ptr<sinks::sink>;
    using sinks_init_list = std::initializer_list<sink_ptr>;
    using err_handler     = std::function<void(const std::string& err_msg)>;

    namespace fmt_lib = fmt;

    using string_view_t = fmt::basic_string_view<char>;
    using memory_buf_t  = fmt::basic_memory_buffer<char, 250>;

    template <typename... Args>
    using format_string_t = fmt::format_string<Args...>;

    template <class T>
    using remove_cvref_t = typename std::remove_cv<typename std::remove_reference<T>::type>::type;

    template <typename Char>
    using fmt_runtime_string = fmt::runtime_format_string<Char>;

    template <class T, class Char = char>
    struct is_convertible_to_basic_format_string
        : std::integral_constant<bool, std::is_convertible<T, fmt::basic_string_view<Char>>::value
                                           || std::is_same<remove_cvref_t<T>, fmt_runtime_string<Char>>::value>
    {
    };


#define ZSIBOTLOG_BUF_TO_STRING(x) fmt::to_string(x)


    template <class T>
    struct is_convertible_to_any_format_string
        : std::integral_constant<bool,
              is_convertible_to_basic_format_string<T, char>::value || is_convertible_to_basic_format_string<T, wchar_t>::value>
    {
    };
    using level_t = std::atomic<int>;

#define ZSIBOTLOG_LEVEL_TRACE    0
#define ZSIBOTLOG_LEVEL_DEBUG    1
#define ZSIBOTLOG_LEVEL_INFO     2
#define ZSIBOTLOG_LEVEL_WARN     3
#define ZSIBOTLOG_LEVEL_ERROR    4
#define ZSIBOTLOG_LEVEL_CRITICAL 5
#define ZSIBOTLOG_LEVEL_OFF      6

#if !defined(ZSIBOTLOG_ACTIVE_LEVEL)
#define ZSIBOTLOG_ACTIVE_LEVEL ZSIBOTLOG_LEVEL_INFO
#endif

    namespace level
    {
        enum level_enum : int
        {
            trace    = ZSIBOTLOG_LEVEL_TRACE,
            debug    = ZSIBOTLOG_LEVEL_DEBUG,
            info     = ZSIBOTLOG_LEVEL_INFO,
            warn     = ZSIBOTLOG_LEVEL_WARN,
            err      = ZSIBOTLOG_LEVEL_ERROR,
            critical = ZSIBOTLOG_LEVEL_CRITICAL,
            off      = ZSIBOTLOG_LEVEL_OFF,
            n_levels
        };

#define ZSIBOTLOG_LEVEL_NAME_TRACE    zsibot::log::string_view_t("trace", 5)
#define ZSIBOTLOG_LEVEL_NAME_DEBUG    zsibot::log::string_view_t("debug", 5)
#define ZSIBOTLOG_LEVEL_NAME_INFO     zsibot::log::string_view_t("info", 4)
#define ZSIBOTLOG_LEVEL_NAME_WARNING  zsibot::log::string_view_t("warning", 7)
#define ZSIBOTLOG_LEVEL_NAME_ERROR    zsibot::log::string_view_t("error", 5)
#define ZSIBOTLOG_LEVEL_NAME_CRITICAL zsibot::log::string_view_t("critical", 8)
#define ZSIBOTLOG_LEVEL_NAME_OFF      zsibot::log::string_view_t("off", 3)

#if !defined(ZSIBOTLOG_LEVEL_NAMES)
#define SPDLOG_LEVEL_NAMES                                                                                                                 \
    { ZSIBOTLOG_LEVEL_NAME_TRACE, ZSIBOTLOG_LEVEL_NAME_DEBUG, ZSIBOTLOG_LEVEL_NAME_INFO, ZSIBOTLOG_LEVEL_NAME_WARNING,                     \
        ZSIBOTLOG_LEVEL_NAME_ERROR, ZSIBOTLOG_LEVEL_NAME_CRITICAL, ZSIBOTLOG_LEVEL_NAME_OFF }
#endif

#if !defined(ZSIBOTLOG_SHORT_LEVEL_NAMES)

#define ZSIBOTLOG_SHORT_LEVEL_NAMES { "T", "D", "I", "W", "E", "C", "O" }
#endif

        const string_view_t&           to_string_view(zsibot::log::level::level_enum l) noexcept;
        const char*                    to_short_c_str(zsibot::log::level::level_enum l) noexcept;
        zsibot::log::level::level_enum from_str(const std::string& name) noexcept;

    }  // namespace level


    enum class color_mode
    {
        always,
        automatic,
        never
    };


    enum class pattern_time_type
    {
        local,  // log localtime
        utc     // log utc
    };


    class zsibotlog_ex : public std::exception
    {
    public:
        explicit zsibotlog_ex(std::string msg);
        zsibotlog_ex(const std::string& msg, int last_errno);
        const char* what() const noexcept override;

    private:
        std::string msg_;
    };

    [[noreturn]] void throw_zsibotlog_ex(const std::string& msg, int last_errno);
    [[noreturn]] void throw_zsibotlog_ex(std::string msg);

    struct source_loc
    {
        constexpr source_loc() = default;
        constexpr source_loc(const char* filename_in, int line_in, const char* funcname_in)
            : filename{ filename_in },
              line{ line_in },
              funcname{ funcname_in }
        {
        }

        constexpr bool empty() const noexcept
        {
            return line <= 0;
        }
        const char* filename{ nullptr };
        int         line{ 0 };
        const char* funcname{ nullptr };
    };

    struct file_event_handlers
    {
        file_event_handlers()
            : before_open(nullptr),
              after_open(nullptr),
              before_close(nullptr),
              after_close(nullptr)
        {
        }

        std::function<void(const filename_t& filename)>                         before_open;
        std::function<void(const filename_t& filename, std::FILE* file_stream)> after_open;
        std::function<void(const filename_t& filename, std::FILE* file_stream)> before_close;
        std::function<void(const filename_t& filename)>                         after_close;
    };

    namespace details
    {


        constexpr zsibot::log::string_view_t to_string_view(const memory_buf_t& buf) noexcept
        {
            return zsibot::log::string_view_t{ buf.data(), buf.size() };
        }

        constexpr zsibot::log::string_view_t to_string_view(zsibot::log::string_view_t str) noexcept
        {
            return str;
        }

        template <typename T, typename... Args>
        inline fmt::basic_string_view<T> to_string_view(fmt::basic_format_string<T, Args...> fmt)
        {
            return fmt;
        }


        using std::enable_if_t;
        using std::make_unique;


        template <typename T, typename U, enable_if_t<!std::is_same<T, U>::value, int> = 0>
        constexpr T conditional_static_cast(U value)
        {
            return static_cast<T>(value);
        }

        template <typename T, typename U, enable_if_t<std::is_same<T, U>::value, int> = 0>
        constexpr T conditional_static_cast(U value)
        {
            return value;
        }

    }  // namespace details
}  // namespace zsibot::log
