#pragma once

#include <chrono>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <thread>

namespace zsibot::log::details
{
    class periodic_worker
    {
    public:
        template <typename Rep, typename Period>
        periodic_worker(const std::function<void()>& callback_fun, std::chrono::duration<Rep, Period> interval)
        {
            active_ = (interval > std::chrono::duration<Rep, Period>::zero());
            if (!active_)
            {
                return;
            }

            worker_thread_ = std::thread(
                [this, callback_fun, interval]()
                {
                    for (;;)
                    {
                        std::unique_lock<std::mutex> lock(this->mutex_);
                        if (this->cv_.wait_for(lock, interval,
                                [this]
                                {
                                    return !this->active_;
                                }))
                        {
                            return;  // active_ == false, so exit this thread
                        }
                        callback_fun();
                    }
                });
        }
        std::thread& get_thread()
        {
            return worker_thread_;
        }
        periodic_worker(const periodic_worker&)            = delete;
        periodic_worker& operator=(const periodic_worker&) = delete;
        ~periodic_worker();

    private:
        bool                    active_;
        std::thread             worker_thread_;
        std::mutex              mutex_;
        std::condition_variable cv_;
    };

    inline periodic_worker::~periodic_worker() {
        if (worker_thread_.joinable()) {
            {
                std::lock_guard<std::mutex> lock(mutex_);
                active_ = false;
            }
            cv_.notify_one();
            worker_thread_.join();
        }
    }

}  // namespace zsibot::log::details