#pragma once

#include <zsibot/log/details/log_msg.hpp>


namespace zsibot::log::details
{


    class  log_msg_buffer : public log_msg
    {
        memory_buf_t buffer;
        void         update_string_views();

    public:
        log_msg_buffer() = default;
        explicit log_msg_buffer(const log_msg& orig_msg);
        log_msg_buffer(const log_msg_buffer& other);
        log_msg_buffer(log_msg_buffer&& other) noexcept;
        log_msg_buffer& operator=(const log_msg_buffer& other);
        log_msg_buffer& operator=(log_msg_buffer&& other) noexcept;
    };

}  // namespace zsibot::log::details
