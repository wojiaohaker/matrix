#pragma once

#include <zsibot/log/details/log_msg_buffer.hpp>
#include <zsibot/log/details/mpmc_queue.hpp>
#include <zsibot/log/details/os.hpp>

#include <chrono>
#include <functional>
#include <future>
#include <memory>
#include <thread>
#include <vector>

namespace zsibot::log
{
    class async_logger;

    namespace details
    {

        using async_logger_ptr = std::shared_ptr<zsibot::log::async_logger>;

        enum class async_msg_type
        {
            log,
            flush,
            terminate
        };

        // Async msg to move to/from the queue
        // Movable only. should never be copied
        struct async_msg : log_msg_buffer
        {
            async_msg_type     msg_type{ async_msg_type::log };
            async_logger_ptr   worker_ptr;
            std::promise<void> flush_promise;

            async_msg()  = default;
            ~async_msg() = default;

            // should only be moved in or out of the queue..
            async_msg(const async_msg&) = delete;


            async_msg(async_msg&&)            = default;
            async_msg& operator=(async_msg&&) = default;

            // construct from log_msg with given type
            async_msg(async_logger_ptr&& worker, async_msg_type the_type, const details::log_msg& m)
                : log_msg_buffer{ m },
                  msg_type{ the_type },
                  worker_ptr{ std::move(worker) },
                  flush_promise{}
            {
            }

            async_msg(async_logger_ptr&& worker, async_msg_type the_type)
                : log_msg_buffer{},
                  msg_type{ the_type },
                  worker_ptr{ std::move(worker) },
                  flush_promise{}
            {
            }

            async_msg(async_logger_ptr&& worker, async_msg_type the_type, std::promise<void>&& promise)
                : log_msg_buffer{},
                  msg_type{ the_type },
                  worker_ptr{ std::move(worker) },
                  flush_promise{ std::move(promise) }
            {
            }

            explicit async_msg(async_msg_type the_type)
                : async_msg{ nullptr, the_type }
            {
            }
        };

        class thread_pool
        {
        public:
            using item_type = async_msg;
            using q_type    = details::mpmc_blocking_queue<item_type>;

            thread_pool(size_t q_max_items, size_t threads_n, std::function<void()> on_thread_start, std::function<void()> on_thread_stop);
            thread_pool(size_t q_max_items, size_t threads_n, std::function<void()> on_thread_start);
            thread_pool(size_t q_max_items, size_t threads_n);

            // message all threads to terminate gracefully and join them
            ~thread_pool();

            thread_pool(const thread_pool&)       = delete;
            thread_pool& operator=(thread_pool&&) = delete;

            void              post_log(async_logger_ptr&& worker_ptr, const details::log_msg& msg, async_overflow_policy overflow_policy);
            std::future<void> post_flush(async_logger_ptr&& worker_ptr, async_overflow_policy overflow_policy);
            size_t            overrun_counter();
            void              reset_overrun_counter();
            size_t            discard_counter();
            void              reset_discard_counter();
            size_t            queue_size();

        private:
            q_type q_;

            std::vector<std::thread> threads_;

            void post_async_msg_(async_msg&& new_msg, async_overflow_policy overflow_policy);
            void worker_loop_();

            // process next message in the queue
            // return true if this thread should still be active (while no terminate msg
            // was received)
            bool process_next_msg_();
        };

    }  // namespace details
}  // namespace zsibot::log
