#pragma once

#include <ctime>
#include <zsibot/log/common.hpp>


namespace zsibot::log::details::os
{

    zsibot::log::log_clock::time_point now() noexcept;

    std::tm localtime(const std::time_t& time_tt) noexcept;

    std::tm localtime() noexcept;

    std::tm gmtime(const std::time_t& time_tt) noexcept;

    std::tm gmtime() noexcept;

#if !defined(ZSIBOTLOG_EOL)
#define ZSIBOTLOG_EOL "\n"
#endif

    constexpr static const char* default_eol = ZSIBOTLOG_EOL;

#if !defined(ZSIBOTLOG_FOLDER_SEPS)
#define ZSIBOTLOG_FOLDER_SEPS "/"
#endif

    constexpr static const char                   folder_seps[]          = ZSIBOTLOG_FOLDER_SEPS;
    constexpr static const filename_t::value_type folder_seps_filename[] = ZSIBOTLOG_FILENAME_T(ZSIBOTLOG_FOLDER_SEPS);

    bool fopen_s(FILE** fp, const filename_t& filename, const filename_t& mode);

    int remove(const filename_t& filename) noexcept;

    int remove_if_exists(const filename_t& filename) noexcept;

    int rename(const filename_t& filename1, const filename_t& filename2) noexcept;

    bool path_exists(const filename_t& filename) noexcept;

    size_t filesize(FILE* f);

    int utc_minutes_offset(const std::tm& tm = details::os::localtime());

    size_t _thread_id() noexcept;

    size_t thread_id() noexcept;

    void sleep_for_millis(unsigned int milliseconds) noexcept;

    std::string filename_to_str(const filename_t& filename);

    int pid() noexcept;


    bool is_color_terminal() noexcept;

    bool in_terminal(FILE* file) noexcept;


    filename_t dir_name(const filename_t& path);

    bool create_dir(const filename_t& path);

    std::string getenv(const char* field);

    bool fsync(FILE* fp);

}  // namespace zsibot::log::details::os
