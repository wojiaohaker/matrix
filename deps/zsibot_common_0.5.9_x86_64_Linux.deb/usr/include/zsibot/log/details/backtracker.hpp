#pragma once

#include <zsibot/log/details/log_msg_buffer.hpp>
#include <zsibot/log/details/ring_cache.hpp>

#include <atomic>
#include <functional>
#include <mutex>


namespace zsibot::log::details
{
    class  backtracer
    {
        mutable std::mutex         mutex_;
        std::atomic<bool>          enabled_{ false };
        circular_q<log_msg_buffer> messages_;

    public:
        backtracer() = default;
        backtracer(const backtracer& other);

        backtracer(backtracer&& other) noexcept;
        backtracer& operator=(backtracer other);

        void enable(size_t size);
        void disable();
        bool enabled() const;
        void push_back(const log_msg& msg);
        bool empty() const;

        void foreach_pop(std::function<void(const details::log_msg&)> fun);
    };

}  // namespace zsibot::log::details
