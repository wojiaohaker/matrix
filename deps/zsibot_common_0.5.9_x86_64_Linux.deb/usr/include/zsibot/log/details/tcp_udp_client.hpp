#pragma once

#include <arpa/inet.h>
#include <cstring>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <string>
#include <sys/socket.h>
#include <unistd.h>

#include <zsibot/log/common.hpp>
#include <zsibot/log/details/os.hpp>


namespace zsibot::log::details
{

    /**
     *  @brief a easy udp client which for send log
     */
    class udp_client
    {
        static constexpr int TX_BUFFER_SIZE = 1024 * 10;
        int                  socket_        = -1;
        struct sockaddr_in   sockAddr_{};

        void cleanup_()
        {
            if (socket_ != -1)
            {
                ::close(socket_);
                socket_ = -1;
            }
        }

    public:
        udp_client(const std::string& host, uint16_t port)
        {
            socket_ = ::socket(PF_INET, SOCK_DGRAM, 0);
            if (socket_ < 0)
            {
                throw_spdlog_ex("error: Create Socket Failed!");
            }

            int option_value = TX_BUFFER_SIZE;
            if (::setsockopt(socket_, SOL_SOCKET, SO_SNDBUF, reinterpret_cast<const char*>(&option_value), sizeof(option_value)) < 0)
            {
                cleanup_();
                throw_spdlog_ex("error: setsockopt(SO_SNDBUF) Failed!");
            }

            sockAddr_.sin_family = AF_INET;
            sockAddr_.sin_port   = htons(port);

            if (::inet_aton(host.c_str(), &sockAddr_.sin_addr) == 0)
            {
                cleanup_();
                throw_spdlog_ex("error: Invalid address!");
            }

            ::memset(sockAddr_.sin_zero, 0x00, sizeof(sockAddr_.sin_zero));
        }

        ~udp_client()
        {
            cleanup_();
        }

        int fd() const
        {
            return socket_;
        }

        void send(const char* data, size_t n_bytes)
        {
            ssize_t   toslen = 0;
            socklen_t tolen  = sizeof(struct sockaddr);
            if ((toslen = ::sendto(socket_, data, n_bytes, 0, (struct sockaddr*)&sockAddr_, tolen)) == -1)
            {
                throw_spdlog_ex("sendto(2) failed", errno);
            }
        }
    };


    /**
     * @brief tcp client for send log msg
     */
    class tcp_client
    {
        int socket_ = -1;

    public:
        bool is_connected() const
        {
            return socket_ != -1;
        }

        void close()
        {
            if (is_connected())
            {
                ::close(socket_);
                socket_ = -1;
            }
        }

        int fd() const
        {
            return socket_;
        }

        ~tcp_client()
        {
            close();
        }

        void connect(const std::string& host, int port)
        {
            close();
            struct addrinfo hints{};
            memset(&hints, 0, sizeof(struct addrinfo));
            hints.ai_family   = AF_UNSPEC;       // To work with IPv4, IPv6, and so on
            hints.ai_socktype = SOCK_STREAM;     // TCP
            hints.ai_flags    = AI_NUMERICSERV;  // port passed as as numeric value
            hints.ai_protocol = 0;

            auto             port_str = std::to_string(port);
            struct addrinfo* addrinfo_result;
            auto             rv = ::getaddrinfo(host.c_str(), port_str.c_str(), &hints, &addrinfo_result);
            if (rv != 0)
            {
                throw_spdlog_ex(fmt_lib::format("::getaddrinfo failed: {}", gai_strerror(rv)));
            }

            // Try each address until we successfully connect(2).
            int last_errno = 0;
            for (auto* rp = addrinfo_result; rp != nullptr; rp = rp->ai_next)
            {
                const int flags = SOCK_CLOEXEC;
                socket_         = ::socket(rp->ai_family, rp->ai_socktype | flags, rp->ai_protocol);
                if (socket_ == -1)
                {
                    last_errno = errno;
                    continue;
                }
                rv = ::connect(socket_, rp->ai_addr, rp->ai_addrlen);
                if (rv == 0)
                {
                    break;
                }
                last_errno = errno;
                ::close(socket_);
                socket_ = -1;
            }
            ::freeaddrinfo(addrinfo_result);
            if (socket_ == -1)
            {
                throw_spdlog_ex("::connect failed", last_errno);
            }

            int enable_flag = 1;
            ::setsockopt(socket_, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char*>(&enable_flag), sizeof(enable_flag));
        }

        void send(const char* data, size_t n_bytes)
        {
            size_t bytes_sent = 0;
            while (bytes_sent < n_bytes)
            {
                const int send_flags   = MSG_NOSIGNAL;
                auto      write_result = ::send(socket_, data + bytes_sent, n_bytes - bytes_sent, send_flags);
                if (write_result < 0)
                {
                    close();
                    throw_spdlog_ex("write(2) failed", errno);
                }

                if (write_result == 0)  // (probably should not happen but in any case..)
                {
                    break;
                }
                bytes_sent += static_cast<size_t>(write_result);
            }
        }
    };
}  // namespace zsibot::log::details
