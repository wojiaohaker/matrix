#pragma once

#include <zsibot/log/common.hpp>
#include <zsibot/log/details/log_msg.hpp>
#include <zsibot/log/pattern_formatter.hpp>
#include <zsibot/log/sinks/sink.hpp>

#include <memory>
#include <mutex>

namespace zsibot::log::sinks
{
    template <typename Mutex>
    class base_sink : public sink
    {
    public:
        base_sink();
        explicit base_sink(std::unique_ptr<zsibot::log::formatter> formatter);
        ~base_sink() override = default;

        base_sink(const base_sink&) = delete;
        base_sink(base_sink&&)      = delete;

        base_sink& operator=(const base_sink&) = delete;
        base_sink& operator=(base_sink&&)      = delete;

        void log(const details::log_msg& msg) final;
        void flush() final;
        void set_pattern(const std::string& pattern) final;
        void set_formatter(std::unique_ptr<zsibot::log::formatter> sink_formatter) final;

    protected:
        // sink formatter
        std::unique_ptr<zsibot::log::formatter> formatter_;
        Mutex                                   mutex_;

        virtual void sink_it_(const details::log_msg& msg) = 0;
        virtual void flush_()                              = 0;
        virtual void set_pattern_(const std::string& pattern);
        virtual void set_formatter_(std::unique_ptr<zsibot::log::formatter> sink_formatter);
    };


    template <typename Mutex>
    base_sink<Mutex>::base_sink()
        : formatter_{ details::make_unique<zsibot::log::pattern_formatter>() }
    {
    }

    template <typename Mutex>
    base_sink<Mutex>::base_sink(std::unique_ptr<zsibot::log::formatter> formatter)
        : formatter_{ std::move(formatter) }
    {
    }

    template <typename Mutex>
    void base_sink<Mutex>::log(const details::log_msg& msg)
    {
        std::lock_guard<Mutex> lock(mutex_);
        sink_it_(msg);
    }

    template <typename Mutex>
    void base_sink<Mutex>::flush()
    {
        std::lock_guard<Mutex> lock(mutex_);
        flush_();
    }

    template <typename Mutex>
    void base_sink<Mutex>::set_pattern(const std::string& pattern)
    {
        std::lock_guard<Mutex> lock(mutex_);
        set_pattern_(pattern);
    }

    template <typename Mutex>
    void base_sink<Mutex>::set_formatter(std::unique_ptr<zsibot::log::formatter> sink_formatter)
    {
        std::lock_guard<Mutex> lock(mutex_);
        set_formatter_(std::move(sink_formatter));
    }

    template <typename Mutex>
    void base_sink<Mutex>::set_pattern_(const std::string& pattern)
    {
        set_formatter_(details::make_unique<zsibot::log::pattern_formatter>(pattern));
    }

    template <typename Mutex>
    void base_sink<Mutex>::set_formatter_(std::unique_ptr<zsibot::log::formatter> sink_formatter)
    {
        formatter_ = std::move(sink_formatter);
    }

}  // namespace zsibot::log::sinks