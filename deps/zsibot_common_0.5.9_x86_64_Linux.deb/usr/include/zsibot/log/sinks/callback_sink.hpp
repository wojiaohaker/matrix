#pragma once

#include <zsibot/log/details/null_mutex.hpp>
#include <zsibot/log/details/synchronous_factory.hpp>
#include <zsibot/log/sinks/base_sink.hpp>

#include <mutex>
#include <string>

namespace zsibot::log
{

    // callbacks type
    typedef std::function<void(const details::log_msg& msg)> custom_log_callback;

    namespace sinks
    {
        /*
         * Trivial callback sink, gets a callback function and calls it on each log
         */
        template <typename Mutex>
        class callback_sink final : public base_sink<Mutex>
        {
        public:
            explicit callback_sink(const custom_log_callback& callback)
                : callback_{ callback }
            {
            }

        protected:
            void sink_it_(const details::log_msg& msg) override
            {
                callback_(msg);
            }
            void flush_() override {};

        private:
            custom_log_callback callback_;
        };

        using callback_sink_mt = callback_sink<std::mutex>;
        using callback_sink_st = callback_sink<details::null_mutex>;

    }  // namespace sinks

    //
    // factory functions
    //
    template <typename Factory = zsibot::log::synchronous_factory>
    inline std::shared_ptr<logger> callback_logger_mt(const std::string& logger_name, const custom_log_callback& callback)
    {
        return Factory::template create<sinks::callback_sink_mt>(logger_name, callback);
    }

    template <typename Factory = zsibot::log::synchronous_factory>
    inline std::shared_ptr<logger> callback_logger_st(const std::string& logger_name, const custom_log_callback& callback)
    {
        return Factory::template create<sinks::callback_sink_st>(logger_name, callback);
    }

}  // namespace zsibot::log
