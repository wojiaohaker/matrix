#pragma once

#include <zsibot/log/details/log_msg.hpp>
#include <zsibot/log/formatter.hpp>


namespace zsibot::log::sinks
{
    class sink
    {
    public:
        virtual ~sink()                                                                    = default;
        virtual void log(const details::log_msg& msg)                                      = 0;
        virtual void flush()                                                               = 0;
        virtual void set_pattern(const std::string& pattern)                               = 0;
        virtual void set_formatter(std::unique_ptr<zsibot::log::formatter> sink_formatter) = 0;

        void              set_level(level::level_enum log_level);
        level::level_enum level() const;
        bool              should_log(level::level_enum msg_level) const;

    protected:
        // sink log level - default is all
        level_t level_{ level::trace };
    };

}  // namespace zsibot::log::sinks
