//
// Created by kanonwy on 2025/04/24
//

#pragma once
#include "zsibot/thread/thread_impl/thread_impl.hpp"
#include "zsibot/thread/thread_settings.hpp"


#include <atomic>
#include <memory>
#include <string>
#include <thread>
#include <vector>


namespace zsibot::task
{
    class PeriodicTaskManager;

    /**
     * @brief 周期性的任务，抽象接口
     */
    class PeriodicTask
    {
    public:
        /**
         * @brief 构造函数
         * @param task_manager
         * @param period 单位:秒，0.1 表示 100 ms
         * @param name 任务的名称
         */
        PeriodicTask(PeriodicTaskManager& task_manager, float period, std::string name);


        /**
         * @brief 设置周期性任务的线程配置
         * @param settings
         */
        void setThreadSettings(const zsibot::ThreadSettings& settings);

        /**
         * @brief 周期任务启动
         */
        void start();

        /**
         * @brief 周期任务停止
         */
        void stop();

        void printStatus() const;

        void clearMax();

        bool isSlow() const;


        virtual void init() {}
        virtual void run() {}
        virtual void cleanup() {}

        virtual ~PeriodicTask()
        {
            stop();
        }

        float getPeriod() const
        {
            return period_;
        }


        float getRuntime() const
        {
            return lastRuntime_;
        }


        float getMaxPeriod() const
        {
            return maxPeriod_;
        }

        float getMaxRuntime() const
        {
            return maxRuntime_;
        }

    private:
        /**
         * @brief loop for stop
         */
        void loopFunction();

        float                  period_;
        std::atomic_bool       running_        = false;
        float                  lastRuntime_    = 0;
        float                  lastPeriodTime_ = 0;
        float                  maxPeriod_      = 0;
        float                  maxRuntime_     = 0;
        std::string            name_;
        zsibot::thread         js_thread_;             ///<<< 支持优先级的任务
        zsibot::ThreadSettings js_thread_settings_{};  ///<<< 当前工作线程设置
    };


    /**
     * @brief 周期任务管理类
     */
    class PeriodicTaskManager
    {
    public:
        PeriodicTaskManager() = default;

        ~PeriodicTaskManager() = default;
        /**
         * @brief 将指定的任务纳入管理
         * @param task 周期任务派生实例
         */
        void addTask(PeriodicTask* task);

        void printStatus() const;

        void printStatusOfSlowTasks() const;

        void stopAll() const;

    private:
        std::vector<PeriodicTask*> tasks_;
    };
}  // namespace zsibot::task