//
// Created by kanonwy on 2025/06/24
//

#pragma once

#include "zsibot/thread/thread_impl/thread_impl.hpp"
#include "zsibot/thread/thread_settings.hpp"


#include <atomic>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <type_traits>
#include <unordered_map>

namespace zsibot::task
{

    // forward declare
    class MutableFrequencyTask;

    /**
     * @brief mutable frequency task manager.
     */
    class MutableFrequencyTaskManager
    {
    public:
        static std::shared_ptr<MutableFrequencyTask> getTaskByName(const std::string& name);

        static bool addMutableFrequencyTask(std::shared_ptr<MutableFrequencyTask> task);

        static bool stopTask(const std::string& name);

        static bool startTask(const std::string& name);

        /**
         * @brief create a mutable frequency task
         * @tparam D deriver class of MutableFrequencyTask
         * @tparam TS D construct param type
         * @param args
         * @return
         */
        template <typename D, typename... TS>
        static std::shared_ptr<MutableFrequencyTask> createTask(TS... args)
        {
            static_assert(
                std::is_base_of_v<zsibot::task::MutableFrequencyTask, D>, "make sure type D is the derive class of MutableFrequencyTask");
            std::shared_ptr<MutableFrequencyTask> task = std::make_shared<D>(std::forward<TS>(args)...);
            addMutableFrequencyTask(task);
            return task;
        }

        static void inspectStatus();


    private:
        MutableFrequencyTaskManager() = default;
        static inline std::unordered_map<std::string, std::shared_ptr<MutableFrequencyTask>> tasks_{};
        static inline std::mutex mutex_{};
    };

    /**
     * @brief mutable frequency task
     */
    class MutableFrequencyTask
    {
    public:
        /**
         * @brief 构造函数
         * @param period 单位:秒，0.1 表示 100 ms
         * @param name 任务的名称
         */
        MutableFrequencyTask(float period, std::string name);


        /**
         * @brief 设置周期性任务的线程配置
         * @param settings
         */
        void setThreadSettings(const zsibot::ThreadSettings& settings);

        /**
         * @brief set new period and restart
         * @param period
         */
        void setPeriodAndReLaunch(const float period);

        void start();

        void stop();

        void printStatus() const;

        void clearMax();

        bool isSlow() const;


        virtual void init() {}
        virtual void run() {}
        virtual void cleanup() {}


        virtual ~MutableFrequencyTask()
        {
            stop();
        }

        float getPeriod() const
        {
            return period_;
        }


        float getRuntime() const
        {
            return lastRuntime_;
        }

        std::string getName() const
        {
            return name_;
        }


        float getMaxPeriod() const
        {
            return maxPeriod_;
        }

        float getMaxRuntime() const
        {
            return maxRuntime_;
        }

        float getLastPeriod() const
        {
            return lastPeriodTime_;
        }


    private:
        /**
         * @brief loop for stop
         */
        void loopFunction();

        float                  period_;
        std::atomic_bool       running_        = false;
        float                  lastRuntime_    = 0;
        float                  lastPeriodTime_ = 0;
        float                  maxPeriod_      = 0;
        float                  maxRuntime_     = 0;
        std::string            name_;
        zsibot::thread         js_thread_;             ///<<< 支持优先级的任务
        zsibot::ThreadSettings js_thread_settings_{};  ///<<< 当前工作线程设置
    };
}  // namespace zsibot::task