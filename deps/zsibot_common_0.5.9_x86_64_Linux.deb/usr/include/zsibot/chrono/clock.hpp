#pragma once

#include <zsibot/thread_lock.hpp>
#include <zsibot/unit/time.hpp>

namespace zsibot::chrono
{
    /**
     * @brief 时钟，可用于记录时间，查看两个记录点之间的时间差距。
     */
    class Clock final : public zsibot::thread_lock::RecursiveLock
    {
    public:
        /**
         * @brief 重置时间，开始计时
         */
        void start();

        /**
         * @brief 暂停计时
         * @return 当前已经统计的时间
         */
        zsibot::unit::Time pause();

        /**
         * @brief 恢复计时
         * @return 当前已经统计的时间
         */
        zsibot::unit::Time resume();

        /**
         * @brief 查看当前已经统计的时间
         * @return
         */
        zsibot::unit::Time watch();

        /**
         * @brief 查看距离上一次调用本类的函数，已经过去多少时间
         * @return
         */
        zsibot::unit::Time interval();

        /**
         * @brief 设置当前的时间值
         * @param time
         */
        void set(const zsibot::unit::Time& time);

        /**
         * @return 当前计时器是否在统计时间
         */
        [[nodiscard]] bool isRunning() const;

    private:
        // 从记录开始到当前的时间总计（单位：微秒）
        long long time_ = 0;

        // 上一次访问时的时间值（单位：微秒）
        long long last_ = 0;

        // 标识当前时钟是否在工作
        bool running_ = false;
    };
}  // namespace zsibot::chrono
