#pragma once

#include <chrono>

namespace zsibot::chrono
{
    /**
     * @brief 被分解的时间数据，可表示日期、时分秒、以及更小的时间单位。
     */
    struct Date
    {
        int year  = 0;
        int month = 1;  // (1 - 12 )
        int day   = 1;  // (1 - 31 )
        int hour  = 0;  // (0 - 23 )
        int min   = 0;  // (0 - 59 )
        int sec   = 0;  // (0 - 59 )
        int ms    = 0;  // (0 - 999)

        // 保存了去除秒数部分的剩余时间值
        std::chrono::nanoseconds nsec{};

        Date() = default;

        /**
         * @brief 使用系统时间点，构造本日期对象
         */
        Date(const std::chrono::time_point<std::chrono::system_clock>& time_point);

        /**
         * @brief 使用系统时间点数据进行赋值，更新日期数据
         */
        Date& operator=(const std::chrono::time_point<std::chrono::system_clock>& time_point);

        /**
         * @brief 将本身持有的时间数据，转化为系统时间点。
         * 若 nsec 字段为零时，采用 ms 字段的值作为去除秒数的部分。
         */
        [[nodiscard]] std::chrono::time_point<std::chrono::system_clock> toTimePoint() const;

        /**
         * @brief 使用当前的时间点，创建一个日期对象
         */
        static Date now();

        /**
         * @brief 本地时区名称
         */
        [[nodiscard]] static const char* zone();
    };
}  // namespace jszr::chrono
