#pragma once

#include <functional>
#include <queue>

#include <zsibot/thread_lock.hpp>
#include <zsibot/unit/time.hpp>


namespace zsibot::chrono
{
    /**
     * @brief 定时器类
     * @details 简单的定时器实现
     */
    class Timer : public zsibot::thread_lock::RecursiveLock
    {
    public:
        using Handler = std::function<void(Timer& timer)>;

        /**
         * @brief 创建一个永久性的定时任务。
         * @param interval 触发任务的间隔时间
         * @param handler 执行任务的函数
         */
        void schedule(const zsibot::unit::Time& interval, const Handler& handler);

        /**
         * @brief 创建一个只执行一次的定时任务。
         * @param interval 触发任务的间隔时间（从调用时开始计时）
         * @param handler 执行任务的函数
         * @note 本函数可以连续调用，以追加多次定时任务。
         */
        Timer& scheduleOnce(const zsibot::unit::Time& interval, const Handler& handler);

        /**
         * @brief 创建一个指定执行次数的定时任务。
         * @param interval 触发任务的间隔时间
         * @param handler 执行任务的函数
         * @param count 重复次数，若为负数，则认为是一个永久性的定时任务。
         * @note 本函数可以连续调用，以追加多次定时任务。
         */
        Timer& schedule(const zsibot::unit::Time& interval, const Handler& handler, int count);

        /**
         * @brief 取消所有定时任务。
         */
        void cancel();

        /**
         * @return 是否有定时任务正在排队运行
         */
        bool isScheduling() const;

        /**
         * @brief 析构时，需要取消所有定时任务
         */
        ~Timer() override;

    private:
        /**
         * @brief 处理一次定时调用
         */
        void onSchedule();

        /**
         * @brief 尝试加载新的定时任务，若定时任务执行完毕，则将终止定时器
         */
        void processNextSchedule();

    private:
        struct ScheduleData
        {
            // 一次调度计划中，需要被回调的用户函数
            Handler handler;

            // 间隔时间
            zsibot::unit::Time interval;

            // 被定时触发的次数（小于零，认为是无限次触发）
            int count = 0;
        };

        // linux下的定时器
        timer_t timer_id_ = nullptr;

        // 定时器是否初始化（_timer_id 可能为 0，因此不能通过判断 _timer_id 是否为零来判断定时器是否初始化）
        bool is_initialized_ = false;

        // 多个串联的调度计划
        std::queue<ScheduleData> schedules_;
    };
}  // namespace jszr::chrono
