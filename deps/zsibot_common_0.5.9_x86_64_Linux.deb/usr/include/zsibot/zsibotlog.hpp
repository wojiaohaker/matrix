#pragma once

#include <zsibot/fmt/format.h>
#include <zsibot/log/common.hpp>
#include <zsibot/log/details/register.hpp>
#include <zsibot/log/details/synchronous_factory.hpp>
#include <zsibot/log/logger.hpp>
#include <zsibot/log/pattern_formatter.hpp>

#include <chrono>
#include <functional>
#include <memory>
#include <string>

namespace zsibot::log
{

    using default_factory = synchronous_factory;

    // Create and register a logger with a templated sink type
    // The logger's level, formatter and flush level will be set according the
    // global settings.
    //
    // Example:
    //   spdlog::create<daily_file_sink_st>("logger_name", "dailylog_filename", 11, 59);
    template <typename Sink, typename... SinkArgs>
    inline std::shared_ptr<zsibot::log::logger> create(std::string logger_name, SinkArgs&&... sink_args)
    {
        return default_factory::create<Sink>(std::move(logger_name), std::forward<SinkArgs>(sink_args)...);
    }

    // Initialize and register a logger,
    // formatter and flush level will be set according the global settings.
    //
    // Useful for initializing manually created loggers with the global settings.
    //
    // Example:
    //   auto mylogger = std::make_shared<spdlog::logger>("mylogger", ...);
    //   spdlog::initialize_logger(mylogger);
    inline void initialize_logger(std::shared_ptr<logger> logger);

    // Return an existing logger or nullptr if a logger with such name doesn't
    // exist.
    // example: spdlog::get("my_logger")->info("hello {}", "world");
    std::shared_ptr<logger> get(const std::string& name);

    // Set global formatter. Each sink in each logger will get a clone of this object
    void set_formatter(std::unique_ptr<zsibot::log::formatter> formatter);

    // Set global format string.
    // example: spdlog::set_pattern("%Y-%m-%d %H:%M:%S.%e %l : %v");
    void set_pattern(std::string pattern, pattern_time_type time_type = pattern_time_type::local);

    // enable global backtrace support
    void enable_backtrace(size_t n_messages);

    // disable global backtrace support
    void disable_backtrace();

    // call dump backtrace on default logger
    void dump_backtrace();

    // Get global logging level
    level::level_enum get_level();

    // Set global logging level
    void set_level(level::level_enum log_level);

    // Determine whether the default logger should log messages with a certain level
    bool should_log(level::level_enum lvl);

    // Set global flush level
    void flush_on(level::level_enum log_level);

    // Start/Restart a periodic flusher thread
    // Warning: Use only if all your loggers are thread safe!
    template <typename Rep, typename Period>
    inline void flush_every(std::chrono::duration<Rep, Period> interval)
    {
        details::registry::instance().flush_every(interval);
    }

    // Set global error handler
    void set_error_handler(void (*handler)(const std::string& msg));

    // Register the given logger with the given name
    void register_logger(std::shared_ptr<logger> logger);

    // Apply a user defined function on all registered loggers
    // Example:
    // spdlog::apply_all([&](std::shared_ptr<spdlog::logger> l) {l->flush();});
    void apply_all(const std::function<void(std::shared_ptr<logger>)>& fun);

    // Drop the reference to the given logger
    void drop(const std::string& name);

    // Drop all references from the registry
    void drop_all();

    // stop any running threads started by spdlog and clean registry loggers
    void shutdown();

    // Automatic registration of loggers when using spdlog::create() or spdlog::create_async
    void set_automatic_registration(bool automatic_registration);

    // API for using default logger (stdout_color_mt),
    // e.g: spdlog::info("Message {}", 1);
    //
    // The default logger object can be accessed using the spdlog::default_logger():
    // For example, to add another sink to it:
    // spdlog::default_logger()->sinks().push_back(some_sink);
    //
    // The default logger can replaced using spdlog::set_default_logger(new_logger).
    // For example, to replace it with a file logger.
    //
    // IMPORTANT:
    // The default API is thread safe (for _mt loggers), but:
    // set_default_logger() *should not* be used concurrently with the default API.
    // e.g do not call set_default_logger() from one thread while calling spdlog::info() from another.

    std::shared_ptr<zsibot::log::logger> default_logger();

    zsibot::log::logger* default_logger_raw();

    void set_default_logger(std::shared_ptr<zsibot::log::logger> default_logger);

    // Initialize logger level based on environment configs.
    //
    // Useful for applying SPDLOG_LEVEL to manually created loggers.
    //
    // Example:
    //   auto mylogger = std::make_shared<spdlog::logger>("mylogger", ...);
    //   spdlog::apply_logger_env_levels(mylogger);
    void apply_logger_env_levels(std::shared_ptr<logger> logger);

    template <typename... Args>
    inline void log(source_loc source, level::level_enum lvl, format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->log(source, lvl, fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void log(level::level_enum lvl, format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->log(source_loc{}, lvl, fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void trace(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->trace(fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void debug(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->debug(fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void info(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->info(fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void warn(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->warn(fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void error(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->error(fmt, std::forward<Args>(args)...);
    }

    template <typename... Args>
    inline void critical(format_string_t<Args...> fmt, Args&&... args)
    {
        default_logger_raw()->critical(fmt, std::forward<Args>(args)...);
    }

    template <typename T>
    inline void log(source_loc source, level::level_enum lvl, const T& msg)
    {
        default_logger_raw()->log(source, lvl, msg);
    }

    template <typename T>
    inline void log(level::level_enum lvl, const T& msg)
    {
        default_logger_raw()->log(lvl, msg);
    }
    template <typename T>
    inline void trace(const T& msg)
    {
        default_logger_raw()->trace(msg);
    }

    template <typename T>
    inline void debug(const T& msg)
    {
        default_logger_raw()->debug(msg);
    }

    template <typename T>
    inline void info(const T& msg)
    {
        default_logger_raw()->info(msg);
    }

    template <typename T>
    inline void warn(const T& msg)
    {
        default_logger_raw()->warn(msg);
    }

    template <typename T>
    inline void error(const T& msg)
    {
        default_logger_raw()->error(msg);
    }

    template <typename T>
    inline void critical(const T& msg)
    {
        default_logger_raw()->critical(msg);
    }

}  // namespace zsibot::log


//
// 编译时控制日志的全局等级
// 需要在 include zsibot/log.hpp 之前定义 ZSIBOTLOG_ACTIVE_LEVEL 为下列等级之一
// ZSIBOTLOG_LEVEL_TRACE,
// ZSIBOTLOG_LEVEL_DEBUG,
// ZSIBOTLOG_LEVEL_INFO,
// ZSIBOTLOG_LEVEL_WARN,
// ZSIBOTLOG_LEVEL_ERROR,
// ZSIBOTLOG_LEVEL_CRITICAL,
// ZSIBOTLOG_LEVEL_OFF
//

#ifndef ZSIBOTLOG_NO_SOURCE_LOC
#define ZSIBOTLOG_LOGGER_CALL(logger, level, ...)                                                                                          \
    (logger)->log(zsibot::log::source_loc{ __FILE__, __LINE__, ZSIBOTLOG_FUNCTION }, level, __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_CALL(logger, level, ...) (logger)->log(zsibot::log::source_loc{}, level, __VA_ARGS__)
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_TRACE
#define ZSIBOTLOG_LOGGER_TRACE(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::trace, __VA_ARGS__)
#define ZSIBOTLOG_TRACE(...)                ZSIBOTLOG_LOGGER_TRACE(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_TRACE(logger, ...) (void)0
#define ZSIBOTLOG_TRACE(...)                (void)0
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_DEBUG
#define ZSIBOTLOG_LOGGER_DEBUG(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::debug, __VA_ARGS__)
#define ZSIBOTLOG_DEBUG(...)                ZSIBOTLOG_LOGGER_DEBUG(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_DEBUG(logger, ...) (void)0
#define ZSIBOTLOG_DEBUG(...)                (void)0
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_INFO
#define ZSIBOTLOG_LOGGER_INFO(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::info, __VA_ARGS__)
#define ZSIBOTLOG_INFO(...)                ZSIBOTLOG_LOGGER_INFO(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_INFO(logger, ...) (void)0
#define ZSIBOTLOG_INFO(...)                (void)0
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_WARN
#define ZSIBOTLOG_LOGGER_WARN(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::warn, __VA_ARGS__)
#define ZSIBOTLOG_WARN(...)                ZSIBOTLOG_LOGGER_WARN(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_WARN(logger, ...) (void)0
#define ZSIBOTLOG_WARN(...)                (void)0
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_ERROR
#define ZSIBOTLOG_LOGGER_ERROR(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::err, __VA_ARGS__)
#define ZSIBOTLOG_ERROR(...)                ZSIBOTLOG_LOGGER_ERROR(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_ERROR(logger, ...) (void)0
#define ZSIBOTLOG_ERROR(...)                (void)0
#endif

#if ZSIBOTLOG_ACTIVE_LEVEL <= ZSIBOTLOG_LEVEL_CRITICAL
#define ZSIBOTLOG_LOGGER_CRITICAL(logger, ...) ZSIBOTLOG_LOGGER_CALL(logger, zsibot::log::level::critical, __VA_ARGS__)
#define ZSIBOTLOG_CRITICAL(...)                ZSIBOTLOG_LOGGER_CRITICAL(zsibot::log::default_logger_raw(), __VA_ARGS__)
#else
#define ZSIBOTLOG_LOGGER_CRITICAL(logger, ...) (void)0
#define ZSIBOTLOG_CRITICAL(...)                (void)0
#endif


class TmpLogger
{
public:
    static TmpLogger& instance()
    {
        static TmpLogger instance;
        return instance;
    }

    static void set_logger(const std::shared_ptr<zsibot::log::logger>& logger)
    {
        tmp_logger_ = logger;
    }

    static std::shared_ptr<zsibot::log::logger> Logger()
    {
        return tmp_logger_;
    }


private:
    TmpLogger() = default;
    inline static std::shared_ptr<zsibot::log::logger> tmp_logger_{ nullptr };
};


#define ZSIBOT_TMPLOG_TRACE(...)    TmpLogger::instance().Logger()->trace(__VA_ARGS__)
#define ZSIBOT_TMPLOG_DEBUG(...)    TmpLogger::instance().Logger()->debug(__VA_ARGS__)
#define ZSIBOT_TMPLOG_INFO(...)     TmpLogger::instance().Logger()->info(__VA_ARGS__)
#define ZSIBOT_TMPLOG_WARN(...)     TmpLogger::instance().Logger()->warn(__VA_ARGS__)
#define ZSIBOT_TMPLOG_ERROR(...)    TmpLogger::instance().Logger()->error(__VA_ARGS__)
#define ZSIBOT_TMPLOG_CRITICAL(...) TmpLogger::instance().Logger()->critical(__VA_ARGS__)
