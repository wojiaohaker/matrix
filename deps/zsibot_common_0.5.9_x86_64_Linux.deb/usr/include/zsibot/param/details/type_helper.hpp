#pragma once

#include "zsibot/binding/object/object_view.hpp"
#include "zsibot/macro/unused.hpp"
#include "zsibot/param/backend/static_info_register.hpp"
#include "zsibot/modules/global_unique.hpp"

namespace zsibot::param::details
{
    /**
     * @brief 指定数据类型的辅助类，主要用于静态注册参数的信息
     */
    template <class T>
    class TypeHelper
    {
    public:
        TypeHelper()
        {
            ZSIBOT_UNUSED(init_helper_);  // 确保该变量被初始化
        }

        /**
         * @brief 为给定对象创建内存视图。
         * @note 通过故意使用本函数，使本类的静态变量真的被实例化
         */
        static binding::ObjectView bind(T& obj)
        {
            binding::ObjectView view;
            view.bind(obj);
            return view;
        }

    private:
        static std::byte init_helper_;  ///< 用于帮助信息注册的静态成员变量，确保该变量被初始化，不被优化掉
    };

    template <class T>
    std::byte TypeHelper<T>::init_helper_ = []() -> std::byte
    {
        static T default_value;
        zsibot::module::GlobalUnique<backend::StaticInfoRegister>::ref().setDefaultValue(default_value);
        return {};
    }();

    /**
     * @brief 创建指定对象的内存视图
     */
    template <class T>
    binding::ObjectView createView(T& obj)
    {
        // 通过 TypeHelper 的函数进行构建，将顺便静态注册该类型的参数信息
        return zsibot::module::GlobalUnique<TypeHelper<T>>::ref().bind(obj);
    }
}  // namespace zsibot::param::details
