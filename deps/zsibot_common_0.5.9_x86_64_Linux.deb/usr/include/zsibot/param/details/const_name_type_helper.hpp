#pragma once

#include "zsibot/param/details/type_helper.hpp"

namespace zsibot::param::details
{
    /**
     * @brief 指定数据类型、指定常量参数名称的辅助类，用于拥有常量名称的静态参数的信息注册
     */
    template <class T, const char* NAME>
    class ConstNameTypeHelper
    {
    public:
        ConstNameTypeHelper()
        {
            ZSIBOT_UNUSED(init_helper_);
        }

        /**
         * @brief 用于 ZSIBOT_PARAM 宏，由静态参数对象调用，可强行实例化本类，
         * 以进行静态实例化。
         */
        binding::ObjectView bind(T& obj)
        {
            return createView(obj);
        }

    private:
        static std::byte init_helper_;
    };

    template <class T, const char* NAME>
    std::byte ConstNameTypeHelper<T, NAME>::init_helper_ = []() -> std::byte
    {
        // 向参数系统注册本常量名称参数
        module::GlobalUnique<backend::StaticInfoRegister>::ref().addItem<T>(NAME);
        return {};
    }();
}  // namespace zsibot::param::details
