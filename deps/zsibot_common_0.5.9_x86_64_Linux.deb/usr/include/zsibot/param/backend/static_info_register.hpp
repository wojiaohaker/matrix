#pragma once

#include "zsibot/binding.hpp"
#include "zsibot/param/backend/static_info.hpp"

namespace zsibot::param::backend
{
    /**
     * @brief 维护进程内使用到的参数信息，将在程序静态区初始化时注册
     */
    class StaticInfoRegister
    {
    public:
        /**
         * @brief 设置指定数据类型的参数默认值及其内存结构
         */
        template <class T>
        void setDefaultValue(T& static_object)
        {
            getInfo<T>().view.bind(static_object);
        }

        /**
         * @brief 添加一个指定类型的、组内使用的静态参数项
         */
        template <class T>
        void addItem(std::string name)
        {
            getInfo<T>().items.insert(std::move(name));
        }

        /**
         * @brief 获取注册的全部内容
         */
        [[nodiscard]] const std::map<std::string, StaticInfo>& getAllInfo() const
        {
            return data_;
        }

    private:
        /**
         * @brief 获取指定数据类型的静态信息
         */
        template <class T>
        StaticInfo& getInfo()
        {
            return data_[binding::name<T>()];
        }

        std::map<std::string, StaticInfo> data_;
    };
}  // namespace zsibot::param::backend
