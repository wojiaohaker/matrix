#pragma once

#include "zsibot/binding/object/object_view.hpp"

#include <set>
#include <string>


namespace zsibot::param::backend
{
    struct StaticInfo
    {
        binding::ObjectView   view;   ///< 该数据类型的内存视图，其中指向了一个默认构造的全局静态对象
        std::set<std::string> items;  ///< 使用该数据类型的静态参数
    };
}  // namespace zsibot::param::backend
