#pragma once

#include "zsibot/base.hpp"
#include "zsibot/base/self_start.hpp"
#include "zsibot/binding/object.hpp"
#include "zsibot/binding/object/object_view.hpp"
#include "zsibot/container/record.hpp"
#include "zsibot/modules/module_manager.hpp"
#include "zsibot/param/backend/interface.hpp"
#include "zsibot/yaml/yaml.h"

#include <filesystem>

namespace zsibot::param::backend
{

    class Sys final : public base::SelfStartModuleBase<Sys>, public ParamInterface
    {
    public:
        Sys() {}

        ~Sys() override {}

        /**
         * @brief
         * @param name
         * @param view
         * @return
         */
        bool read(const std::string& name, binding::ObjectView& view) override;

        /**
         * @brief
         * @param name
         * @param view
         * @return
         */
        bool readStatic(const std::string& name, binding::ObjectView& view) override;

        /**
         * @brief get self start policy
         * @return
         */
        module::Policy getSelfStartPolicy() override;

        /**
         * @brief  init parameter system module
         * @param self
         * @param init_config
         * @return
         */
        bool onStartSys(SelfStartModuleBase* self, const zsibot::base::InitConfig& init_config) override;

        /**
         * @brief close parameter system module
         * @param self
         * @param init_config
         */
        void onCloseSys(SelfStartModuleBase* self, const zsibot::base::InitConfig& init_config) override;


    private:
        struct MetaData
        {
            yaml::Node      meta_node;
            binding::Object default_obj;
            binding::Object meta_obj;
        };

        struct Data
        {
            binding::Object                 static_value;
            binding::Object                 dynamic_value;
            std::filesystem::file_time_type last_modified;
        };

        /**
         * @brief init all params default value meta info.
         */
        void initData();

        /**
         * @brief  do some prepare work
         * @param init_config
         */
        void prepareWork(const base::InitConfig& init_config);


        /**
         * @brief init all parameter files
         */
        void initAllParameterFiles();


        /**
         * @brief init static value
         * @param ptr
         * @param type_name
         * @param param_name
         * @return
         */
        bool initStaticValue(zsibotc::record_ptr<Data>& ptr, const std::string& type_name, const std::string& param_name);


        /**
         * @brief update dynamic value
         * @param ptr
         * @param type_name
         * @param param_name
         * @return
         */
        bool updateDynamicValue(zsibotc::record_ptr<Data>& ptr, const std::string& type_name, const std::string& param_name);


        static void assign(binding::ObjectView& view, const binding::Object& obj);

        /**
         * @brief get param file path
         * @param path
         * @param param_name
         * @return
         */
        static std::filesystem::path getFilePath(const std::filesystem::path& path, const std::string& param_name);

        static std::filesystem::file_time_type getFileLastChangedTime(const std::filesystem::path& path);

        static binding::Object readParameterObject(const MetaData& meta, const std::filesystem::path& path);


        static void writeToFile(const std::filesystem::path& path, const MetaData& meta, const binding::Object& param);


        std::map<std::string, MetaData>  meta_datas_;
        zsibotc::record<std::string, Data> datas_;
        std::filesystem::path            static_data_root_;                ///< 静态参数的存储根目录
        std::filesystem::path            dynamic_data_root_;               ///< 动态参数的存储根目录
        std::filesystem::path            comm_public_data_root_;           ///< 公共参数目录
        bool                             static_init_mode_       = false;  ///< 是否为静态参数的初始化模式
        bool                             dynamic_init_mode_      = false;  ///< 是否为动态参数的初始化模式
        bool                             enable_static_creating_ = false;  ///< 是否允许创建静态参数文件及其所在目录
    };
}  // namespace zsibot::param::backend
