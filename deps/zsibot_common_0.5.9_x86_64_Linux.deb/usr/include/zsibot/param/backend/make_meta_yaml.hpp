#pragma once

#include "zsibot/binding_yaml.hpp"

namespace zsibot::param::backend
{
    /**
     * @brief 为给定数据类型构造其元数据，其每个容器都将只包含一个元素
     * @param view 构造过程中，将修改视图对象的内容，因此该数据必须只能来自参数注册中心
     */
    zsibot::yaml::Node makeMetaYaml(binding::ObjectView& view);
}  // namespace zsibot::param::backend
