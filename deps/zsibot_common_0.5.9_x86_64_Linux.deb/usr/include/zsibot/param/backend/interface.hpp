#pragma once

#include "zsibot/binding.hpp"
#include "zsibot/binding/object/object_view.hpp"

namespace zsibot::param::backend
{
    /**
     * @brief 参数后端抽象接口类
     */
    class ParamInterface
    {
    public:
        /**
         * @brief read param
         * @param name param name
         * @param view
         * @return
         */
        virtual bool read(const std::string& name, binding::ObjectView& view) = 0;


        /**
         * @brief
         * @param name param name
         * @param view right value
         * @return
         */
        bool read(const std::string& name, binding::ObjectView&& view)
        {
            return read(name, view);
        }

        /**
         * @brief 读取指定的静态参数，返回是否读取成功
         */
        virtual bool readStatic(const std::string& name, binding::ObjectView& view) = 0;

        /**
         * @brief 重载以支持传入临时 ObjectView 对象
         */
        bool readStatic(const std::string& name, binding::ObjectView&& view)
        {
            return readStatic(name, view);
        }

        virtual ~ParamInterface() = default;
    };

    /**
     * @brief 获取参数后端系统的数据指针
     */
    extern ParamInterface* getSys();
}  // namespace zsibot::param::backend
