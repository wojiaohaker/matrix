#pragma once

#include "zsibot/binding/assign.hpp"

namespace zsibot::param::backend
{
    /**
     * @brief 特别处理枚举类型不匹配的情况，直接使用整数值进行赋值
     */
    class ObjectAssigner final : public binding::IAssigner<binding::ASSIGN_OBJECT_TO_OBJECT_VIEW>
    {
    public:
        /**
         * @brief JUST pbj type miss
         * @param dst
         * @param src
         * @return
         */
        bool onObjectTypeMiss(binding::ObjectView& dst, const binding::Object& src) override;

        bool onValueTypeMiss(binding::ObjectView::Value& dst, const binding::Object::Value& src) override;

        bool onOmittedField(const std::string& field_name, const binding::Object& field) override;

        bool onUnwantedField(const std::string& field_name, const binding::ObjectView& field) override;
    };
}  // namespace zsibot::param::backend
