#pragma once

#include <stack>

#include "zsibot/binding/object.hpp"

namespace zsibot::param::backend
{
    /**
     * @brief 对象扫描器
     */
    class ObjectScanner
    {
    public:
        /**
         * @brief 扫描给定的 binding::Object 对象，检查它是否符合 meta 中定义结构，
         * 如果出现非法情况，则使用 default_value 的内容为其赋值。
         * @param target 被扫描的对象，不允许出现缺失、多余、或错误的结构
         * @param default_value 扫描出错时，用于提供默认值的对象
         * @param meta 扫描时所用的结构信息参考
         * @return 扫描过程是否无错，如果出错，返回 false
         */
        bool scan(binding::Object& target, const binding::Object& default_value, const binding::Object& meta);

    private:
        /**
         * @brief 一步遍历的处理过程
         */
        void doScan();

        /**
         * @brief 处理值类型的情况，如果值类型不匹配，但是可以兼容转换时，将尽量保留目标节点的原值，
         * 目前仅数值类型可以互相转换。
         */
        void doScanValue(binding::Object::Value& target, const binding::Object::Value& meta, const binding::Object::Value* default_value);

        /**
         * @brief 处理链表类型的情况，将进一步扫描链表中每一个元素
         */
        void doScanList(binding::Object::List& target, const binding::Object::List& meta, const binding::Object::List* default_value);

        /**
         * @brief 处理动态数据类型的情况，将进一步扫描动态数组中的每一个元素
         */
        void doScanVector(
            binding::Object::Vector& target, const binding::Object::Vector& meta, const binding::Object::Vector* default_value);

        /**
         * @brief 处理字符串字典型数据的情况，将进一步扫描其中的每一个元素
         */
        void doScanStrDict(
            binding::Object::StrDict& target, const binding::Object::StrDict& meta, const binding::Object::StrDict* default_value);

        /**
         * @brief 处理 optional 数据的情况，将扫描其中可能存在的值
         */
        void doScanOptional(
            binding::Object::Optional& target, const binding::Object::Optional& meta, const binding::Object::Optional* default_value);

        /**
         * @brief 处理结构化数据的情况，将扫描其中的所有存在字段，并剔除不存在的字段，
         * 以及补充缺失的字段。
         */
        void doScanStruct(
            binding::Object::Struct& target, const binding::Object::Struct& meta, const binding::Object::Struct* default_value);

    private:
        std::stack<binding::Object*> target_nodes_;  ///< 扫描的赋值目标的递归节点栈

        /**
         * @brief  默认值对象的递归节点栈
         *
         * @note
         * 由于默认值中有些容器可能是空的，因此该栈不是每一层都是有效数据，
         * 无效数据将使用空指针表示
         */
        std::stack<const binding::Object*> default_nodes_;

        // 元数据的所有层次的容器仅包含一个元素，用于表示数据结构
        std::stack<const binding::Object*> meta_nodes_;         ///< 元数据对象的递归节点栈，
        bool                               has_error_ = false;  ///< 标记过程中是否出错
    };
}  // namespace zsibot::param::backend
