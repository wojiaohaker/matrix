//
// Created by kanonwy on 2024/12/24
//

#pragma once

#include <condition_variable>
#include <functional>
#include <memory>
#include <thread>

namespace zsibot::callback_thread
{
    /**
     * @brief 持久化可调用线程
     * @details 启动一个持续的 callback 任务线程
     */
    class CCallbackThread
    {
    public:
        CCallbackThread(std::function<void()> callback)
            : callback_(callback)
        {
        }

        ~CCallbackThread()
        {
            stop();
        }

        CCallbackThread(const CCallbackThread&)            = delete;
        CCallbackThread& operator=(const CCallbackThread&) = delete;
        CCallbackThread(CCallbackThread&& rhs)             = delete;
        CCallbackThread& operator=(CCallbackThread&& rhs)  = delete;

        /**
         * @brief 启动持久任务线程
         * @tparam DurationType 持续时间类型 std::chrono::T
         * @param timeout 超时时间
         */
        template <typename DurationType>
        void start(DurationType timeout)
        {
            callbackThread_ = std::thread(&CCallbackThread::callbackFunction<DurationType>, this, timeout);
        }

        /**
         * @brief 停止线程
         */
        void stop()
        {
            {
                const std::unique_lock<std::mutex> lock(mtx_);
                stopThread_ = true;
                cv_.notify_one();
            }
            if (callbackThread_.joinable())
            {
                callbackThread_.join();
            }
        }

    private:
        std::thread             callbackThread_;       ///<<< 线程句柄
        std::function<void()>   callback_;             ///<<< 对应回调函数
        std::mutex              mtx_;                  ///<<< 保护互斥量
        std::condition_variable cv_;                   ///<<< 条件变量
        bool                    stopThread_{ false };  ///<<< 线程停止标志

        /**
         * @brief 实际回调执行函数
         */
        template <typename DurationType>
        void callbackFunction(DurationType timeout)
        {
            while (true)
            {
                {
                    std::unique_lock<std::mutex> lock(mtx_);
                    if (cv_.wait_for(lock, timeout,
                            [this]
                            {
                                return stopThread_;
                            }))
                    {
                        break;
                    }
                }
                if (callback_)
                {
                    callback_();
                }
            }
        }
    };
}  // namespace zsibot::callback_thread
