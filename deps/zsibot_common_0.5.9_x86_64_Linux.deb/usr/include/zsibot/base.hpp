//
// Created by kanonwy on 2024/11/6
//

#pragma once

#include "zsibot/base/env_var.hpp"
#include "zsibot/base/framework.hpp"
#include "zsibot/base/init_config.hpp"
#include "zsibot/base/self_start.hpp"
#include "zsibot/base/this_process.hpp"

/**
 *  @mainpage zsibot 文档
 *  zsibot 的一个基础工具包，包括了一些基础编程工具
 *  ### Author
 *  - kanonwy
 *  ### 基本模块
 * <div class="tabbed">
 *   <br>
 *   | Item | 模块名称  | 模块描述| target 名称                                       |
 *   |-----:|-----------|-----------------------|--------------------------------------------|
 *   |    1  | base         |  zsibot 框架启动基础            | zsibot::zsibot_base                   |
 *   |    2  | macro        |  zsibot 宏库                   | zsibot::zsibot_macro                  |
 *   |    3  | utils        |  zsibot 类型萃取工具封装         | zsibot::zsibot_utils                  |
 *   |    4  | serialize    |  zsibot 简单结构体序列化工具      | zsibot::zsibot_serialize              |
 *   |    5  | thread       |  zsibot 简单线程封装，支持优先级   | zsibot::zsibot_thread                 |
 *   |    6  | thread_pool  |  zsibot 基于 CGRAPH 修改的线程池 | zsibot::zsibot_thread_pool            |
 *   |    7  | rmw          |  zsibot 通信适配层 （开发中）     | zsibot::zsibot_rmw                    |
 *   |    8  | perftools    |  zsibot 性能工具封装             | zsibot::zsibot_perftools              |
 *   |    9  | net          |  zsibot udp 封装                | zsibot::zsibot_net                   |
 * </div>
 *
 * ## 组件依赖关系
 *
 * @dot 基础组件依赖关系
 *  digraph example {
 *      node [fontsize="12"];
 * rankdir="LR"
 *      base -> macro
 *      base -> jszrlog
 *  }
 * @enddot
 *
 * ## 基础依赖
 * - C++17 above(gcc11 以上)
 * - cmake 3.20 ++
 * ## 安装
 * 目前使用 deb 直接安装即可，后续使用 zsibot_cli 安装和管理。
 * 支持平台:
 * - x86(Ubuntu22.04)
 * - aarch64(Ubuntu22.04)
 * @code{.bash}
 * @endcode
 * ## 基本使用
 * 更加详细的使用见 Related Pages
 * ### CMakeLists.txt
 * @code{.cmake}
 * # 查找 jszr 库
 * find_package(zsibot REQUIRED)
 * add_executable(zsibot_test src/main.cpp)
 * # 采用与 boost 类似的子模块的方式，链接基础库和宏库，自动引入头文件依赖
 * target_link_libraries(cpp_code PRIVATE
 *      zsibot::zsibot_base
 *      zsibot::zsibot_macro
 * )
 * @endcode
 *
 * ### main.cpp
 * @code{.cpp}
 * #include <zsibot/base.hpp>
 *
 * int main()
 * {
 *    // 初始化（必须）
 *    zsibot::initialize();
 *    int i = 100;
 *    while(i > 0)
 *    {
 *        i--;
 *        // 支持六种级别的日志
 *        zsibot::log::trace("trace: {}",i);
 *        zsibot::log::debug("debug: {}",i);
 *        zsibot::log::info("info: {}",i);
 *        zsibot::log::warn("warn: {}",i);
 *        zsibot::log::error("error: {}",i);
 *        zsibot::log::critical("critical: {}",i);
 *    }
 *
 *   // 资源回收（必须）
 *   zsibot::finalize();
 *   return 0;
 * }
 * @endcode
 */
