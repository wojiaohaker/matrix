#pragma once

#include <mutex>
#include <shared_mutex>

#include <zsibot/macro.hpp>
#include <zsibot/utils.hpp>

#include "zsibot/thread_lock/ban_lock_impl.hpp"
#include "zsibot/thread_lock/lock_helper.hpp"
#include "zsibot/thread_lock/lock_impl.hpp"
#include "zsibot/thread_lock/shared_ban_lock_impl.hpp"
#include "zsibot/thread_lock/shared_lock_helper.hpp"
#include "zsibot/thread_lock/shared_lock_impl.hpp"


/**
 * 以下的宏是用于多线程加锁的语法糖。
 * @example 继承一个可以被加锁的类
 * @code{.cpp}
 * class A :
 *    public zsibot::thread_lock::MutexLock
 * {
 * public:
 *     void f()
 *     {
 *         ZSIBOT_SYNCHRONIZED(this)
 *         {
 *             // ...
 *         }
 *     }
 * };
 * @endcode
 * @example 修饰任意类型使之成为可以被加锁的类型
 *
 * @code{.cpp}
 * zsibot::thread_lock::MutexLockable<std::vector<int>> data;
 *
 * ZSIBOT_SYNCHRONIZED(data)
 * {
 *     // ...
 * }
 *
 * ZSIBOT_SYNCHRONIZED(&data)
 * {
 *     // ...
 * }
 * @endcode
 */

/**
 * @brief eon 线程锁相关宏所在的命名空间，用于简化线程间数据同步
 */
namespace zsibot::thread_lock
{
    using MutexLock     = details::LockImpl<std::timed_mutex>;
    using RecursiveLock = details::LockImpl<std::recursive_timed_mutex>;
    using SharedLock    = details::SharedLockImpl<std::shared_timed_mutex>;

    using MutexBanLock     = details::BanLockImpl<std::timed_mutex>;
    using RecursiveBanLock = details::BanLockImpl<std::recursive_timed_mutex>;
    using SharedBanLock    = details::SharedBanLockImpl<std::shared_timed_mutex>;

    /**
     * @brief 修饰一个类型，使之变成可互斥锁的
     */
    template <class T>
    class MutexLockable : public T, public MutexLock
    {
    public:
        using T::T;
        using T::operator=;
    };

    /**
     * @brief 修饰一个类型，使之变成可递归锁的
     */
    template <class T>
    class RecursiveLockable : public T, public RecursiveLock
    {
    public:
        using T::T;
        using T::operator=;
    };

    /**
     * @brief 修饰一个类型，使之变成可读写锁的
     */
    template <class T>
    class SharedLockable : public T, public SharedLock
    {
    public:
        using T::T;
        using T::operator=;
    };

    /**
     * @brief 修饰一个类型，使之变成可互斥禁锁的
     */
    template <class T>
    class MutexBanLockable : public T, public MutexBanLock
    {
    public:
        using T::T;
        using T::operator=;
    };

    /**
     * @brief 修饰一个类型，使之变成可递归禁锁的
     */
    template <class T>
    class RecursiveBanLockable : public T, public RecursiveBanLock
    {
    public:
        using T::T;
        using T::operator=;
    };

    /**
     * @brief 修饰一个类型，使之变成可读写禁锁的
     */
    template <class T>
    class SharedBanLockable : public T, public SharedBanLock
    {
    public:
        using T::T;
        using T::operator=;
    };
}  // namespace zsibot::thread_lock

// 用于加锁宏的辅助宏，创建自动上锁、解锁的辅助对象
#define ZSIBOT_DETAILS_LOCK_HELPER(_lock_) ::zsibot::thread_lock::details::LockHelper<::zsibot::utils::intrinsic_type<decltype(_lock_)>>

#define ZSIBOT_DETAILS_SHARED_LOCK_HELPER(_lock_)                                                                                          \
    ::zsibot::thread_lock::details::SharedLockHelper<::zsibot::utils::intrinsic_type<decltype(_lock_)>>

/**
 * @brief 作用于锁对象或指针，制造一个加锁的作用域
 * @example 无时限加锁
 * @code{.cpp}
 * zsibot::thread_lock::MutexLockable<MyData> obj;
 *
 * ZSIBOT_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * @endcode
 *
 * @example 有时限加锁
 * @code{.cpp}
 * ZSIBOT_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 */
#define ZSIBOT_SYNCHRONIZED(...) ZSIBOT_CONCAT(ZSIBOT_DETAILS_SYNCHRONIZED_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__)

#define ZSIBOT_DETAILS_SYNCHRONIZED_1(_lock_)                                                                                              \
    if constexpr (ZSIBOT_DETAILS_LOCK_HELPER(_lock_) ZSIBOT_COUNTER_UNIQUE(__lock__)(_lock_); true)

#define ZSIBOT_DETAILS_SYNCHRONIZED_2(_lock_, _time_)                                                                                      \
    if (ZSIBOT_DETAILS_LOCK_HELPER(_lock_) ZSIBOT_LINE_UNIQUE(__lock__)(_lock_, _time_); ZSIBOT_LINE_UNIQUE(__lock__).isOwned())


/**
 * @brief 作用于禁锁对象或指针，制造一个加禁锁的作用域，禁锁可以被控制从而禁止加锁
 *
 * @example 无时限加禁锁
 *
 * @code{.cpp}
 * zsibot::thread_lock::MutexBanLockable<MyData> obj;
 *
 * ZSIBOT_BAN_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * else
 * {
 *     // ... 加锁被禁止时执行
 * }
 * @endcode
 *
 * @example 有时限加禁锁
 * @code{.cpp}
 * ZSIBOT_BAN_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 */
#define ZSIBOT_BAN_SYNCHRONIZED(...) ZSIBOT_CONCAT(ZSIBOT_DETAILS_BAN_SYNCHRONIZED_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__)

// 无时限加禁锁（用于指针）
#define ZSIBOT_DETAILS_BAN_SYNCHRONIZED_1(_lock_)                                                                                          \
    if (ZSIBOT_DETAILS_LOCK_HELPER(_lock_) ZSIBOT_COUNTER_UNIQUE(__lock__)(_lock_); (_lock_).IsLockable())

// 有时限加禁锁（用于指针）
#define ZSIBOT_DETAILS_BAN_SYNCHRONIZED_2(_lock_, _time_)                                                                                  \
    if (ZSIBOT_DETAILS_LOCK_HELPER(_lock_) ZSIBOT_LINE_UNIQUE(__lock__)(_lock_, _time_);                                                   \
        ZSIBOT_LINE_UNIQUE(__lock__).isOwned() and (_lock_).IsLockable())


/**
 * @brief 作用于共享锁对象或指针，制造一个写者锁的作用域
 * @example 无时限写者锁
 *
 * @code{.cpp}
 * zsibot::thread_lock::SharedLockable<MyData> obj;
 *
 * ZSIBOT_WRITER_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * @endcode
 *
 * @example 有时限写者锁
 * @code{.cpp}
 * ZSIBOT_WRITER_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 */
#define ZSIBOT_WRITER_SYNCHRONIZED(...) ZSIBOT_SYNCHRONIZED(__VA_ARGS__)


/**
 * @brief 作用于共享禁锁对象或指针，制造一个写者禁锁的作用域
 * @example 无时限写者锁
 * @code{.cpp}
 * zsibot::thread_lock::SharedBanLockable<MyData> obj;
 *
 * ZSIBOT_BAN_WRITER_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * else
 * {
 *     // ... 加锁被禁止时执行
 * }
 * @endcode
 *
 * @example 有时限写者锁
 * @code{.cpp}
 * ZSIBOT_BAN_WRITER_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 *
 */
#define ZSIBOT_BAN_WRITER_SYNCHRONIZED(...) ZSIBOT_BAN_SYNCHRONIZED(__VA_ARGS__)


/**
 * @brief 作用于共享锁对象或指针，制造一个读者锁的作用域
 * @example 无时限读者锁
 *
 * @code{.cpp}
 * zsibot::thread_lock::SharedLockable<MyData> obj;
 *
 * ZSIBOT_READER_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * @endcode
 *
 * @example 有时限读者锁
 * @code{.cpp}
 * ZSIBOT_READER_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 */
#define ZSIBOT_READER_SYNCHRONIZED(...) ZSIBOT_CONCAT(ZSIBOT_DETAILS_READER_SYNCHRONIZED_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__)

// 无时限加锁（用于指针）
#define ZSIBOT_DETAILS_READER_SYNCHRONIZED_1(_lock_)                                                                                       \
    if constexpr (ZSIBOT_DETAILS_SHARED_LOCK_HELPER(_lock_) ZSIBOT_COUNTER_UNIQUE(__lock__)(_lock_); true)

// 有时限加锁（用于指针）
#define ZSIBOT_DETAILS_READER_SYNCHRONIZED_2(_lock_, _time_)                                                                               \
    if (ZSIBOT_DETAILS_SHARED_LOCK_HELPER(_lock_) ZSIBOT_LINE_UNIQUE(__lock__)(_lock_, _time_); ZSIBOT_LINE_UNIQUE(__lock__).isOwned())


/**
 * @brief 作用于共享禁锁对象或指针，制造一个读者禁锁的作用域
 *
 * @example 无时限读者锁
 *
 * @code{.cpp}
 * zsibot::thread_lock::SharedBanLockable<MyData> obj;
 *
 * ZSIBOT_BAN_READER_SYNCHRONIZED(obj)
 * {
 *     // ...
 * }
 * else
 * {
 *     // ... 加锁被禁止时执行
 * }
 * @endcode
 *
 * @example 有时限读者锁
 *
 * @code{.cpp}
 * ZSIBOT_BAN_READER_SYNCHRONIZED(&obj, zsibot::unit::Second(1))
 * {
 *     // ...
 * }
 * @endcode
 */
#define ZSIBOT_BAN_READER_SYNCHRONIZED(...)                                                                                                \
    ZSIBOT_CONCAT(ZSIBOT_DETAILS_BAN_READER_SYNCHRONIZED_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__)

// 无时限读者锁
#define ZSIBOT_DETAILS_BAN_READER_SYNCHRONIZED_1(_lock_)                                                                                   \
    if (ZSIBOT_DETAILS_SHARED_LOCK_HELPER(_lock_) ZSIBOT_COUNTER_UNIQUE(__lock__)(_lock_); (_lock_).IsLockable())

// 有时限读者锁
#define ZSIBOT_DETAILS_BAN_READER_SYNCHRONIZED_2(_lock_, _time_)                                                                           \
    if (ZSIBOT_DETAILS_SHARED_LOCK_HELPER(_lock_) ZSIBOT_LINE_UNIQUE(__lock__)(_lock_, _time_);                                            \
        ZSIBOT_LINE_UNIQUE(__lock__).isOwned() and (_lock_).IsLockable())
