#pragma once

#include <functional>
#include <string>

#include <zsibot/unit/time.hpp>

#include <zsibot/chrono/clock.hpp>
#include <zsibot/chrono/date.hpp>
#include <zsibot/chrono/timer.hpp>

/**
 * @brief eon 时间相关封装所在的命名空间
 * @details 封装了一些标准库的函数
 */
namespace zsibot::chrono
{
    /**
     * @brief 获取当前的系统时间，eon 目前使用 system_clock 表达时间戳
     */
    static inline auto now()
    {
        return std::chrono::system_clock::now();
    }

    /**
     * @brief 当前的系统时间，使用时间类表达，精度不足，但是方便使用
     * @return jszr::unit::Time
     */
    zsibot::unit::Time nowApprox();

    /**
     * @brief 返回当前时间(单位：秒)
     */
    double sec();

    /**
     * @brief 当前的毫秒数
     */
    long long ms();

    /**
     * @brief 当前的微秒数
     */
    long long us();

    /**
     * @brief 当前的纳秒数
     */
    long long ns();

    /**
     * @brief 返回一个日期 + 时间，可用于按时间命名的场景（如，创建日志文件）
     * @return 返回一个字符串类型
     */
    std::string date();

    /**
     * @brief 将线程挂起一段时间
     * @param time
     */
    void sleep(const zsibot::unit::Time& time);

    /**
     * @brief 使用轮询的方法，监听给定的条件函数返回值；若条件函数返回 true，则退出等待流程；直到超时。
     * @param time
     * @param condition
     * @return 是否等待条件成立
     */
    bool wait(const zsibot::unit::Time& time, const std::function<bool()>& condition);

    /**
     * @brief 使用轮询的方法，监听给定的条件函数返回值；若条件函数返回 true，则退出等待流程。
     * @warning 若条件无法成立，则该等待流程无法退出，有这种可能性的情况下，请开发者使用别的开发模式。
     * @param condition
     */
    void wait(const std::function<bool()>& condition);

    /**
     * @brief 完全挂起线程
     * @warning 永远无法结束，仅用于调试，千万别用于正式工程中。
     */
    [[noreturn]] void hang();
}  // namespace jszr::chrono
