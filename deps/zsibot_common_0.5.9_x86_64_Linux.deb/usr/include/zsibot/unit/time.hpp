#pragma once

#include <chrono>

#include "zsibot/unit/details/unit_base.hpp"

namespace zsibot::unit
{
    enum class TimeUnit
    {
        Undefined = -1,
        Second,
        Minute,
        Hour,
        Day,
        Week,
        MilliSecond,
        MicroSecond,
        Default = 0
    };

    namespace details
    {
        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::Second>()
        {
            return 1.0;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::Minute>()
        {
            return 1.0 / 60.0;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::Hour>()
        {
            return 1.0 / 3600.0;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::Day>()
        {
            return 1.0 / 86400.0;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::Week>()
        {
            return 1.0 / 604800.0;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::MilliSecond>()
        {
            return 1e3;
        }

        template <>
        constexpr double getRatio<TimeUnit, TimeUnit::MicroSecond>()
        {
            return 1e6;
        }
    }  // namespace details

    using Time = details::UnitSystem<TimeUnit>;

    using Second      = details::Unit<TimeUnit, TimeUnit::Second>;
    using Minute      = details::Unit<TimeUnit, TimeUnit::Minute>;
    using Hour        = details::Unit<TimeUnit, TimeUnit::Hour>;
    using Day         = details::Unit<TimeUnit, TimeUnit::Day>;
    using Week        = details::Unit<TimeUnit, TimeUnit::Week>;
    using MilliSecond = details::Unit<TimeUnit, TimeUnit::MilliSecond>;
    using MicroSecond = details::Unit<TimeUnit, TimeUnit::MicroSecond>;

    template <class T>
    using TimeClass = ZSIBOT_CONCEPT((std::is_base_of_v<Time, T>));
}  // namespace zsibot::unit

namespace zsibotu
{
    using sec  = zsibot::unit::Second;
    using min  = zsibot::unit::Minute;
    using hour = zsibot::unit::Hour;
    using day  = zsibot::unit::Day;
    using week = zsibot::unit::Week;
    using ms   = zsibot::unit::MilliSecond;
    using us   = zsibot::unit::MicroSecond;
}  // namespace zsibotu

namespace zsibot::utils
{
    /**
     * @brief 获取给定一段时间之后的系统时间点，以 std 的格式返回
     * @param offset 距离调用瞬间时间的时间间隔
     * @return 当前系统时间 + 时间间隔后得到的系统时间点
     */
    inline auto timePointFromNow(const zsibot::unit::Time& offset)
    {
        const auto us = static_cast<int64_t>(offset.get<zsibotu::us>());
        return std::chrono::system_clock::now() + std::chrono::microseconds(us);
    }
}  // namespace zsibot::utils
