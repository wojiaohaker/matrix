#pragma once

#include <limits>
#include <numeric>

#include "zsibot/macro.hpp"

namespace zsibot::unit::details
{
    /**
     * @brief 概念：类型 T 是一个 jszr::unit 的枚举类型
     */
    template <class E>
    using UnitTypeEnum = ZSIBOT_CONCEPT((std::is_enum_v<E> and zsibot::same_as<E>(E::Default) and zsibot::same_as<E>(E::Undefined)
                                         and static_cast<int>(E::Default) == 0 and static_cast<int>(E::Undefined) == -1));

    /**
     * @brief 概念：类型 TUnit 是一个 jszr::unit 的单位类，并与枚举类型 EUnit 对应
     * @tparam TUnit 某单位类
     * @tparam EUnit 某单位枚举类
     */
    template <class TUnit, class EUnit>
    using UnitClass = ZSIBOT_CONCEPT(
        (zsibot::is<UnitTypeEnum, EUnit>), (zsibot::same_as<EUnit>(TUnit::UNIT)), (ZSIBOT_DETECTS_AS(double, const TUnit, .get())));

    /**
     * @brief 获取指定单位系统从默认单位到给定单位的转换系数
     * @note 由不同单位类特化实现
     */
    template <class EUnit, EUnit TARGET>
    constexpr double getRatio();

    /**
     * @brief 获取指定单位系统从给定单位到默认单位的转换系数
     */
    template <class EUnit, EUnit SOURCE>
    constexpr double getInverseRatio()
    {
        return 1.0 / getRatio<EUnit, SOURCE>();
    }

    /**
     * @brief 获取指定单位系统从默认单位到给定单位的转换系数
     * @note 由不同单位类特化实现
     */
    template <class EUnit>
    double getRatio(EUnit unit);

    /**
     * @brief 获取指定单位系统从给定单位到默认单位的转换系数
     */
    template <class EUnit>
    double getInverseRatio(EUnit unit)
    {
        return 1.0 / getRatio(unit);
    }

    /**
     * @brief 单位系统类型，由某个单位枚举类型定义
     * @tparam EUnit 属于 jszr::unit 的单位枚举类型
     */
    template <class EUnit>
    class UnitSystem
    {
        static_assert(zsibot::is<UnitTypeEnum, EUnit>);

    public:
        UnitSystem()                      = default;
        UnitSystem(const UnitSystem&)     = default;
        UnitSystem(UnitSystem&&) noexcept = default;

        template <class TUnit>
        UnitSystem(const TUnit& unit)  // NOLINT(google-explicit-constructor)
        {
            static_assert(zsibot::is<UnitClass, TUnit, EUnit>);
            set(unit);
        }

        UnitSystem(EUnit unit_enum, double value)
        {
            set(unit_enum, value);
        }

        /**
         * @brief 零值
         */
        const static UnitSystem zero;

        /**
         * @brief 最大值
         */
        const static UnitSystem maximal;

        // 单位类型
        using UnitEnumType = EUnit;

        // 单位系统类型
        using UnitSystemType = UnitSystem;

    public:
        void set(EUnit unit_enum, double value)
        {
            _value = value * getInverseRatio(unit_enum);
        }

        template <class TUnit>
        void set(double value)
        {
            static_assert(zsibot::is<UnitClass, TUnit, EUnit>);

            _value = value * getInverseRatio<EUnit, TUnit::UNIT>();
        }

        template <class TUnit>
        void set(const TUnit& unit)
        {
            static_assert(zsibot::is<UnitClass, TUnit, EUnit>);

            _value = unit.get() * getInverseRatio<EUnit, TUnit::UNIT>();
        }

        void set(const UnitSystem& o)
        {
            _value = o._value;
        }

        [[nodiscard]] double get(EUnit unit_enum) const
        {
            return _value * getRatio(unit_enum);
        }

        template <class TUnit>
        [[nodiscard]] double get() const
        {
            static_assert(zsibot::is<UnitClass, TUnit, EUnit>);

            return _value * getRatio<EUnit, TUnit::UNIT>();
        }

        UnitSystem& operator=(const UnitSystem&)     = default;
        UnitSystem& operator=(UnitSystem&&) noexcept = default;

        template <class TUnit>
        UnitSystem& operator=(const TUnit& value)
        {
            set(value);
            return *this;
        }

    public:
        UnitSystem& operator+=(const UnitSystem& o)
        {
            _value += o._value;
            return *this;
        }

        UnitSystem& operator-=(const UnitSystem& o)
        {
            _value -= o._value;
            return *this;
        }

        UnitSystem& operator*=(double scale)
        {
            _value *= scale;
            return *this;
        }

        UnitSystem& operator/=(double scale)
        {
            _value /= scale;
            return *this;
        }

        UnitSystem operator+(const UnitSystem& o) const
        {
            UnitSystem r;
            r._value = this->_value + o._value;
            return r;
        }

        UnitSystem operator-(const UnitSystem& o) const
        {
            UnitSystem r;
            r._value = this->_value - o._value;
            return r;
        }

        UnitSystem operator*(double scale) const
        {
            UnitSystem r;
            r._value = this->_value * scale;
            return r;
        }

        UnitSystem operator/(double scale) const
        {
            UnitSystem r;
            r._value = this->_value / scale;
            return r;
        }

        double operator/(const UnitSystem& other) const
        {
            return this->_value / other._value;
        }

        friend UnitSystem operator*(double scale, const UnitSystem& x)
        {
            return x * scale;
        }

        UnitSystem operator+() const
        {
            return *this;
        }

        UnitSystem operator-() const
        {
            UnitSystem r;
            r._value = -_value;
            return r;
        }

        inline auto operator<(const UnitSystem& o) const
        {
            return _value < o._value;
        }

        inline auto operator<=(const UnitSystem& o) const
        {
            return _value <= o._value;
        }

        inline auto operator>(const UnitSystem& o) const
        {
            return _value > o._value;
        }

        inline auto operator>=(const UnitSystem& o) const
        {
            return _value >= o._value;
        }

        inline auto operator==(const UnitSystem& o) const
        {
            return _value == o._value;
        }

        inline auto operator!=(const UnitSystem& o) const
        {
            return _value != o._value;
        }

    public:
        static double ratio(EUnit from, EUnit to)
        {
            return getInverseRatio(from) * getRatio(to);
        }

    private:
        double _value = 0;
    };

    template <class EUnit>
    const UnitSystem<EUnit> UnitSystem<EUnit>::zero;

    template <class EUnit>
    const UnitSystem<EUnit> UnitSystem<EUnit>::maximal(EUnit::Default, std::numeric_limits<double>::max());
}  // namespace zsibot::unit::details
