#pragma once

#include "zsibot/unit/details/unit_system.hpp"

namespace zsibot::unit::details
{
    template <class EUnit, EUnit unit_enum = EUnit::Undefined>
    class Unit : public UnitSystem<EUnit>
    {
        static_assert(zsibot::is<UnitTypeEnum, EUnit>);
        using Base = UnitSystem<EUnit>;

    public:
        // 本单位的具体枚举类型
        constexpr static EUnit UNIT = unit_enum;

        Unit(double value = 0)  // NOLINT(google-explicit-constructor)
            : Base(UNIT, value)
        {
        }

        Unit(const Base& base)  // NOLINT(google-explicit-constructor)
            : Base(base)
        {
        }

        Unit(const Unit& other) = default;

        using Base::set;

        void set(double value)
        {
            Base::template set<Unit>(value);
        }

        using Base::get;

        [[nodiscard]] double get() const
        {
            return Base::template get<Unit>();
        }

        explicit operator double() const
        {
            return get();
        }

        Unit& operator=(double value)
        {
            set(value);
            return *this;
        }

        Unit& operator=(const Unit& o) = default;

        Unit& operator=(const Base& value)
        {
            Base::operator=(value);
            return *this;
        }

        Unit& operator+=(const Base& o)
        {
            Base::operator+=(o);
            return *this;
        }

        Unit& operator-=(const Base& o)
        {
            Base::operator-=(o);
            return *this;
        }

        Unit& operator*=(double scale)
        {
            Base::operator*=(scale);
            return *this;
        }

        Unit& operator/=(double scale)
        {
            Base::operator/=(scale);
            return *this;
        }

        Unit operator+(const Base& o) const
        {
            return Unit(*this) += o;
        }

        Unit operator-(const Base& o) const
        {
            return Unit(*this) -= o;
        }

        Unit operator*(double scale) const
        {
            return Unit(*this) *= scale;
        }

        Unit operator/(double scale) const
        {
            return Unit(*this) /= scale;
        }

        friend Unit operator*(double scale, const Unit& x)
        {
            return x * scale;
        }

        Unit operator+() const
        {
            return *this;
        }

        Unit operator-() const
        {
            return Unit(Base::operator-());
        }
    };
}  // namespace zsibot::unit::details
