#pragma once


#include "zsibot/thread_lock/ban_lock_impl.hpp"


namespace zsibot::thread_lock::details
{
    template <class TMutex>
    class SharedBanLockImpl : public BanLockImpl<TMutex>
    {
    public:
        void sharedLock() const
        {
            BanLockImpl<TMutex>::mutex_.lock_shared();
            BanLockBase::enter();
        }

        void unSharedLock() const
        {
            BanLockImpl<TMutex>::mutex_.unlock_shared();
            BanLockBase::leave();
        }

        [[nodiscard]] bool trySharedLock() const
        {
            bool locked = BanLockImpl<TMutex>::mutex_.try_lock_shared();

            if (locked)
                BanLockBase::enter();

            return locked;
        }

        [[nodiscard]] bool trySharedLockFor(const zsibot::unit::Time& time) const
        {
            bool locked = BanLockImpl<TMutex>::mutex_.try_lock_shared_until(zsibot::utils::timePointFromNow(time));

            if (locked)
                BanLockBase::enter();

            return locked;
        }
    };
}  // namespace zsibot::thread_lock::details
