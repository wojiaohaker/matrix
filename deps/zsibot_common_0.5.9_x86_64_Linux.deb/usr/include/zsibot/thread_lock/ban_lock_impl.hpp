#pragma once

#include "zsibot/thread_lock/ban_lock_base.hpp"
#include "zsibot/unit.hpp"

namespace zsibot::thread_lock::details
{
    template <class TMutex>
    class BanLockImpl : public BanLockBase
    {
    public:
        void lock() const
        {
            mutex_.lock();
            enter();
        }

        void unLock() const
        {
            mutex_.unlock();
            leave();
        }

        bool tryLock() const
        {
            const bool locked = mutex_.try_lock();

            if (locked)
                enter();

            return locked;
        }

        bool tryLockFor(const zsibot::unit::Time& time) const
        {
            const bool locked = mutex_.try_lock_until(zsibot::utils::timePointFromNow(time));

            if (locked)
                enter();

            return locked;
        }

        [[nodiscard]] bool isLockable() const
        {
            return not isBanned();
        }

        virtual ~BanLockImpl()
        {
            freeSelf();
        }

    protected:
        void freeSelf()
        {
            if (mutex_.try_lock())
                unLock();
        }
        mutable TMutex mutex_;
    };
}  // namespace zsibot::thread_lock::details
