#pragma once

#include "zsibot/thread_lock/lock_impl.hpp"


namespace zsibot::thread_lock::details
{
    template <class TMutex>
    class SharedLockImpl : public LockImpl<TMutex>
    {
    public:
        void sharedLock() const
        {
            LockImpl<TMutex>::mutex_.lock_shared();
        }

        void unSharedLock() const
        {
            LockImpl<TMutex>::mutex_.unlock_shared();
        }

        [[nodiscard]] bool trySharedLock() const
        {
            return LockImpl<TMutex>::mutex_.try_lock_shared();
        }

        [[nodiscard]] bool trySharedLockFor(const zsibot::unit::Time& time) const
        {
            return LockImpl<TMutex>::mutex_.try_lock_shared_until(zsibot::utils::timePointFromNow(time));
        }
    };
}  // namespace zsibot::thread_lock::details
