#pragma once

#include <memory>

#include "zsibot/unit/time.hpp"

namespace zsibot::thread_lock::details
{
    template <class TLock>
    class LockHelper
    {
    public:
        explicit LockHelper(const TLock& m)
            : lock_(m)
        {
            lock_.lock();
            owned_ = true;
        }

        LockHelper(const TLock& m, const zsibot::unit::Time& time)
            : lock_(m)
        {
            owned_ = lock_.tryLockFor(time);
        }

        explicit LockHelper(const TLock* m)
            : LockHelper(*m)
        {
        }

        LockHelper(const TLock* m, const zsibot::unit::Time& time)
            : LockHelper(*m, time)
        {
        }


        [[nodiscard]] bool isOwned() const
        {
            return owned_;
        }

        ~LockHelper()
        {
            owned_ = false;
            lock_.unLock();
        }

    private:
        const TLock& lock_;

        bool owned_ = false;
    };

    template <class TInnerType>
    class LockHelper<std::shared_ptr<TInnerType>> : public LockHelper<TInnerType>
    {
    public:
        explicit LockHelper(const std::shared_ptr<TInnerType>& ptr)
            : LockHelper<TInnerType>(ptr.get())
        {
        }

        LockHelper(const std::shared_ptr<TInnerType>& ptr, const zsibot::unit::Time& time)
            : LockHelper<TInnerType>(ptr.get(), time)
        {
        }
    };

    template <class TInnerType>
    class LockHelper<std::unique_ptr<TInnerType>> : public LockHelper<TInnerType>
    {
    public:
        explicit LockHelper(const std::unique_ptr<TInnerType>& ptr)
            : LockHelper<TInnerType>(ptr.get())
        {
        }

        LockHelper(const std::unique_ptr<TInnerType>& ptr, const zsibot::unit::Time& time)
            : LockHelper<TInnerType>(ptr.get(), time)
        {
        }
    };
}  // namespace zsibot::thread_lock::details
