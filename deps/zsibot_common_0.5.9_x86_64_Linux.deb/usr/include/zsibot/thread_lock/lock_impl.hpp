#pragma once

#include "zsibot/unit/time.hpp"

namespace zsibot::thread_lock::details
{
    /**
     * @brief 锁实现模板
     * @tparam TMutex 锁类型
     */
    template <class TMutex>
    class LockImpl
    {
    public:
        virtual ~LockImpl()
        {
            freeSelf();
        }

        /**
         * @brief 加锁
         */
        void lock() const
        {
            mutex_.lock();
        }

        /**
         * @brief 解锁
         */
        void unLock() const
        {
            mutex_.unlock();
        }

        /**
         * @brief 尝试加锁
         */
        bool tryLock() const
        {
            return mutex_.try_lock();
        }

        /**
         * @brief 在一定时间内加锁
         * @param time 加锁时间
         */
        bool tryLockFor(const zsibot::unit::Time& time) const
        {
            return mutex_.try_lock_until(zsibot::utils::timePointFromNow(time));
        }

    protected:
        /**
         * @brief 释放自身
         */
        void freeSelf()
        {
            if (mutex_.try_lock())
                unLock();
        }
        mutable TMutex mutex_;  ///< 实际保存的锁类型
    };
}  // namespace zsibot::thread_lock::details
