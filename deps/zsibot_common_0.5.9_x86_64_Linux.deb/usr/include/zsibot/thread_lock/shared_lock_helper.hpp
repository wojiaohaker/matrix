#pragma once

#include "zsibot/unit/time.hpp"


namespace zsibot::thread_lock::details
{
    template <class TLock>
    class SharedLockHelper
    {
    public:
        SharedLockHelper(const TLock& m)
            : lock_(m)
        {
            lock_.sharedLock();
            owned_ = true;
        }

        SharedLockHelper(const TLock& m, const zsibot::unit::Time& time)
            : lock_(m)
        {
            owned_ = lock_.tryLockFor(time);
        }

        SharedLockHelper(const TLock* m)
            : SharedLockHelper(*m)
        {
        }

        SharedLockHelper(const TLock* m, const zsibot::unit::Time& time)
            : SharedLockHelper(*m, time)
        {
        }

        [[nodiscard]] bool isOwned() const
        {
            return owned_;
        }

        ~SharedLockHelper()
        {
            lock_.unSharedLock();
        }

    private:
        const TLock& lock_;
        bool         owned_ = false;
    };

    template <class TInnerType>
    class SharedLockHelper<std::shared_ptr<TInnerType>> : public SharedLockHelper<TInnerType>
    {
    public:
        explicit SharedLockHelper(const std::shared_ptr<TInnerType>& ptr)
            : SharedLockHelper<TInnerType>(ptr.get())
        {
        }

        SharedLockHelper(const std::shared_ptr<TInnerType>& ptr, const zsibot::unit::Time& time)
            : SharedLockHelper<TInnerType>(ptr.get(), time)
        {
        }
    };

    template <class TInnerType>
    class SharedLockHelper<std::unique_ptr<TInnerType>> : public SharedLockHelper<TInnerType>
    {
    public:
        explicit SharedLockHelper(const std::unique_ptr<TInnerType>& ptr)
            : SharedLockHelper<TInnerType>(ptr.get())
        {
        }

        SharedLockHelper(const std::unique_ptr<TInnerType>& ptr, const zsibot::unit::Time& time)
            : SharedLockHelper<TInnerType>(ptr.get(), time)
        {
        }
    };
}  // namespace zsibot::thread_lock::details
