#pragma once

#include <atomic>
#include <condition_variable>
#include <mutex>

namespace zsibot::thread_lock::details
{
    class BanLockBase
    {
    public:
        void ban();

        void permit();

        [[nodiscard]] bool isBanned() const;

    protected:
        void enter() const;

        void leave() const;

    private:
        mutable std::mutex m_;
        mutable int        count_ = 0;

        mutable std::condition_variable con_;
        std::atomic_bool                is_banned_ = false;
    };
}  // namespace zsibot::thread_lock::details
