#pragma once

#include "zsibot/binding.hpp"
#include "zsibot/binding/visit.hpp"
#include "zsibot/yaml/yaml.h"
#include <stack>

namespace zsibot::binding::yaml
{
    namespace details
    {
        template <class TObjectType>
        class BuilderBase : public ::zsibot::binding::details::IVisitor<TObjectType, true>
        {
            using Base = ::zsibot::binding::details::IVisitor<TObjectType, true>;

        public:
            /**
             * @brief 处理未知值类型的处理器；若遇到未知值类型，且没有设置该处理器时，将忽略该值
             * @param yaml 当前需设置的 yaml 节点
             * @param obj  需要处理的未知值类型
             * @return 是否继续遍历
             */
            using UnknownValueHandler = std::function<bool(zsibot::yaml::Node& yaml, const typename Base::TValue& obj)>;

            /**
             * @brief 设置值类型未知时的处理器
             */
            void setUnknownValueHandler(UnknownValueHandler handler)
            {
                unknown_value_handler_ = std::move(handler);
            }

            /**
             * @return 当前层次的 yaml 节点，仅 visit 流程结束后有意义
             */
            [[nodiscard]] zsibot::yaml::Node get() const
            {
                return root_;
            }

        protected:
            enum class ContainerType
            {
                None,
                Sequence,
                Map
            };

        protected:
            bool doBegin();

            void doEnd(bool status) const;

            bool doUndefined();

            bool doValue(const typename Base::TValue& obj);

            // bool doEnum(const typename Base::TEnum& obj);

            bool doListBegin();

            bool doVectorBegin();

            bool doStrDictBegin();

            bool doOptionalBegin();

            bool doStructBegin();

            bool doOptionalItem(bool has_value);

            bool doContainerBegin(const std::string& container_name, ContainerType container_type);

            bool doContainerItem(std::size_t idx);

            bool doContainerItem(const std::string& key, std::size_t idx);

            bool doContainerEnd(bool container_is_empty);

        protected:
            // 值类型未知时的处理器
            UnknownValueHandler unknown_value_handler_;

            // 枚举类型未知时的处理器
            // UnknownEnumHandler unknown_enum_handler_;

            // 正在构建的 yaml 文档
            zsibot::yaml::Node root_;

            // 深度优先遍历 binding object 各个层级时产生的各层 yaml 节点
            std::stack<zsibot::yaml::Node> nodes_;
        };
    }  // namespace details

    /**
     * @brief 给定的 binding object 或 object view，构建 yaml 对象
     */
    template <class TObjectType>
    class Builder;

    /**
     * @brief 给定 binding object，构建 yaml 对象
     */
    template <>
    class Builder<Object> final : public details::BuilderBase<Object>
    {
    public:
        bool onBegin(const Object& obj) override;

        void onEnd(const Object& obj, bool status) override;

        bool onUndefined() override;

        bool onValue(const Object::Value& obj) override;


        bool onListBegin(const Object::List& obj) override;

        bool onListItem(std::size_t idx, ObjectType object_type) override;

        bool onListEnd(const Object::List& obj) override;

        bool onVectorBegin(const Object::Vector& obj) override;

        bool onVectorItem(std::size_t idx, ObjectType object_type) override;

        bool onVectorEnd(const Object::Vector& obj) override;

        bool onStrDictBegin(const Object::StrDict& obj) override;

        bool onStrDictItem(const std::string& key, std::size_t idx, ObjectType object_type) override;

        bool onStrDictEnd(const Object::StrDict& obj) override;

        bool onOptionalBegin(const Object::Optional& obj) override;

        bool onOptionalItem(bool has_value, ObjectType object_type) override;

        bool onOptionalEnd(const Object::Optional& obj) override;

        bool onStructBegin(const Object::Struct& obj) override;

        bool onStructItem(const std::string& field_name, std::size_t idx, ObjectType object_type) override;

        bool onStructEnd(const Object::Struct& obj) override;
    };

    template <>
    class Builder<ObjectView> : public details::BuilderBase<ObjectView>
    {
    public:
        bool onBegin(const ObjectConstView& obj) override;

        void onEnd(const ObjectConstView& obj, bool status) override;

        bool onUndefined() override;

        bool onValue(const ObjectConstView::Value& obj) override;


        bool onListBegin(const ObjectConstView::List& obj) override;

        bool onListItem(std::size_t idx, ObjectType object_type) override;

        bool onListEnd(const ObjectConstView::List& obj) override;

        bool onVectorBegin(const ObjectConstView::Vector& obj) override;

        bool onVectorItem(std::size_t idx, ObjectType object_type) override;

        bool onVectorEnd(const ObjectConstView::Vector& obj) override;

        bool onStrDictBegin(const ObjectConstView::StrDict& obj) override;

        bool onStrDictItem(const std::string& key, std::size_t idx, ObjectType object_type) override;

        bool onStrDictEnd(const ObjectConstView::StrDict& obj) override;

        bool onOptionalBegin(const ObjectConstView::Optional& obj) override;

        bool onOptionalItem(bool has_value, ObjectType object_type) override;

        bool onOptionalEnd(const ObjectConstView::Optional& obj) override;

        bool onStructBegin(const ObjectConstView::Struct& obj) override;

        bool onStructItem(const std::string& field_name, std::size_t idx, ObjectType object_type) override;

        bool onStructEnd(const ObjectConstView::Struct& obj) override;
    };
}  // namespace zsibot::binding::yaml
