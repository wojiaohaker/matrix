#pragma once

#include <zsibot/binding.hpp>
#include <zsibot/binding/create.hpp>
#include <zsibot/yaml/yaml.h>
#include <stack>

/**
 * @brief eon 对象绑定到 yaml 文件实现的命名空间
 * @details 其中实现了让 zsibot::binding::obeject 与 yaml 对象转换的逻辑。
 *          可以使得一个 yaml 对象转换为一个 object 对象，也可以使得一个 object 对象
 *          输出为 yaml 文件。
 */
namespace zsibot::binding::yaml
{
    /**
     * @brief yaml 对象创建者
     *
     * @details 用于创建指定 yaml 对象, 继承自 ICreator 抽象基类
     */
    class ObjectCreator : public ICreator
    {
    public:
        /**
         * @brief 处理未知值类型的处理器；若遇到未知值类型，且没有设置该处理器时，且设置该值为空
         * @param value 当前正在设置的值对象
         * @param yaml 该值对象对应的 yaml 节点
         * @return 是否成功处理，若返回 false，将设置该值对象为空
         */
        using UnknownValueHandler = std::function<bool(Object::Value& value, const zsibot::yaml::Node& yaml)>;

    public:
        /**
         * @brief 设置未知值类型的处理器
         */
        void setUnknownValueHandler(UnknownValueHandler handler);

        /**
         * @brief 设置 yaml 根节点
         * @note 本步骤需要在 create 流程开始之前执行
         */
        void prepare(const zsibot::yaml::Node& root_yaml);

    public:
        ObjectType next() override;

        std::size_t nextVectorSize() override;

        bool nextListItem(std::size_t current_size) override;

        bool nextVectorItem(std::size_t current_size) override;

        std::optional<std::string> nextStrDictItem(std::size_t current_size) override;

        bool nextOptionalItem() override;

        void closeOptionalItem() override;

        std::optional<std::string> nextStructItem(std::size_t current_size) override;

        void initValue(Object::Value& dst) override;


    private:
        /**
         * @brief 检查下一个节点是否是顺序型数据，若是，返回该候选类型，同时初始化迭代器，
         * 否则返回 undefined.
         */
        ObjectType nextSequence(ObjectType candidate_type);

        /**
         * @brief 检查下一个节点是否为字典型数据，若是，返回该候选类型，同时初始化迭代器，
         * 否则返回 undefined.
         */
        ObjectType nextMap(ObjectType candidate_type);

        /**
         * @brief 检查下一个顺序型元素是否存在，并更新迭代器
         */
        bool nextSequenceItem(std::size_t current_size);

        /**
         * @brief 检查下一个字典型元素是否存在，并更新迭代器
         */
        std::optional<std::string> nextMapItem(std::size_t current_size);

    private:
        /**
         * @brief 构建对象过程中的存储节点
         */
        struct Node
        {
            /// 本层节点的 yaml 数据
            zsibot::yaml::Node data;

            /// 可能的正在遍历的容器迭代器
            zsibot::yaml::Node::const_iterator iterator;

            /// 是否已经被遍历
            bool visited = false;
        };

    private:
        /// 未知值类型的处理器
        UnknownValueHandler unknown_value_handler_;

        /// 正在递归解析的各个层级的 yaml 节点
        std::stack<Node> nodes_;
    };
}  // namespace zsibot::binding::yaml
