#pragma once

#include <cstdint>
#include <string>

#include <zsibot/macro.hpp>


// C++ 数值型基础类型实例化宏
#define ZSIBOT_DETAILS_BINDING_INSTANTIATES_NUMBER_TYPE(_func_)                                                                               \
    _func_(Int8) _func_(UInt8) _func_(Int16) _func_(UInt16) _func_(Int32) _func_(UInt32) _func_(Int64) _func_(UInt64) _func_(Float)        \
        _func_(Double)

// C++ 基础类型实例化宏
#define ZSIBOT_DETAILS_BINDING_INSTANTIATES_BASIC_TYPE(_func_) _func_(Bool) _func_(Char) ZSIBOT_DETAILS_BINDING_INSTANTIATES_NUMBER_TYPE(_func_)

// eon::binding 支持的容器类型
#define ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(_func_) _func_(List) _func_(Vector) _func_(StrDict) _func_(Optional)

/**
 * @brief 一般基础值类型的实例化宏，用户可利用该宏展开处理相同的代码
 */
#define ZSIBOT_BINDING_INSTANTIATES_BASIC_VALUE_TYPE(_func_)                                                                                  \
    ZSIBOT_DETAILS_BINDING_INSTANTIATES_BASIC_TYPE(_func_)                                                                                    \
    _func_(String)

/**
 * @brief 特殊值类型的实例化宏，用户可利用该宏展开处理相同的代码
 */
// #define ZSIBOT_BINDING_INSTANTIATES_SPECIAL_VALUE_TYPE(_func_) _func_(Angle) _func_(Distance) _func_(Time) _func_(Speed) _func_(Weight)
#define ZSIBOT_BINDING_INSTANTIATES_SPECIAL_VALUE_TYPE(_func_)
/**
 * @brief eon::binding 内置的值类型实例化宏，用户可利用该宏展开处理相同的代码
 */
#define ZSIBOT_BINDING_INSTANTIATES_VALUE_TYPE(_func_)                                                                                        \
    ZSIBOT_BINDING_INSTANTIATES_BASIC_VALUE_TYPE(_func_)                                                                                      \
    ZSIBOT_BINDING_INSTANTIATES_SPECIAL_VALUE_TYPE(_func_)

/**
 * @brief eon::binding::TObject/ObjectView 的简单类型的实例化宏
 */
// #define ZSIBOT_BINDING_INSTANTIATES_SIMPLE_OBJECT_TYPE(_func_) _func_(Value) _func_(Enum)

#define ZSIBOT_BINDING_INSTANTIATES_SIMPLE_OBJECT_TYPE(_func_) _func_(Value)

/**
 * @brief eon::binding::TObject/ObjectView 的复杂类型的实例化宏
 */
#define ZSIBOT_BINDING_INSTANTIATES_COMPLEX_OBJECT_TYPE(_func_)                                                                               \
    ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(_func_)                                                                                \
    _func_(Struct)

/**
 * @brief eon::binding::TObject/ObjectView 各种类型的实例化宏
 */
#define ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(_func_)                                                                                       \
    ZSIBOT_BINDING_INSTANTIATES_SIMPLE_OBJECT_TYPE(_func_)                                                                                    \
    ZSIBOT_BINDING_INSTANTIATES_COMPLEX_OBJECT_TYPE(_func_)
