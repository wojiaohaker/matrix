#pragma once

#include "zsibot/binding/object/object_view.hpp"

namespace zsibot::binding
{
    class Object;

    namespace details
    {
        /**
         * @brief 设置值对象的内容，提供给 assign 流程使用
         */
        void assignValue(Object& dst, std::any data, TypeInfo type_info);

        /**
         * @brief 设置枚举对象的内容，提供给 assign 流程使用
         */
        // void assignEnum(Object& dst, EnumNumber num, TypeInfo type_info, const EnumItemTable* items_ptr);
    }  // namespace details
}  // namespace zsibot::binding

namespace zsibot::binding
{
    class Object
    {
    public:
        /**
         * @brief 值类型
         */
        class Value : public details::ValueBase
        {
        public:
            /**
             * @brief 进行类型初始化，并赋值给定值对象
             * @tparam T 需要初始化的对象的模版类型
             */
            template <class T>
            T& init(T default_value = {})
            {
                static_assert(details::isValue<T>());

                setTypeInfo(details::getTypeInfo<T>());
                setValueType(getValueType<T>());

                data_ = std::move(default_value);
                return std::any_cast<T&>(data_);
            }

            /**
             * @brief 重置本值对象的类型信息
             */
            void reset();

        public:
            /**
             * @brief 将本值对象中的数据转换为给定类型，并返回该数据的引用。
             * @tparam T 需要装换的模版类型
             * @throw std::logic_error 若本值对象拥有的类型与给定类型冲突时，将抛出异常
             */
            template <class T>
            T& as()
            {
                static_assert(details::isValue<T>());

                if (not is<T>())
                    throw std::logic_error("wrong type");

                return std::any_cast<T&>(data_);
            }

            template <class T>
            const T& as() const
            {
                return zsibot::utils::remove_const(this)->as<T>();
            }

            /**
             * @brief 将本值对象的数据转换为给定类型，并返回该数据的指针。
             * 若本值对象拥有的类型与给定类型冲突时，将返回空指针
             */
            template <class T>
            T* ptr()
            {
                static_assert(details::isValue<T>());

                if (not is<T>())
                    return nullptr;
                else
                    return &std::any_cast<T&>(data_);
            }

            template <class T>
            const T* ptr() const
            {
                return zsibot::utils::remove_const(this)->ptr<T>();
            }

            [[nodiscard]] const std::any& getAny() const;

        private:
            friend void details::assignValue(Object& dst, std::any data, details::TypeInfo type_info);
            std::any    data_;
        };

        /**
         * @brief 枚举类型
         */
        // class Enum : public details::EnumBase
        // {
        //     template <class E>
        //     union Mem
        //     {
        //         EnumNumber general;
        //         E          raw;
        //     };
        //
        // public:
        //     /**
        //      * @brief 进行类型初始化，并赋值给定枚举对象
        //      */
        //     template <class E>
        //     E& init(E default_value = {})
        //     {
        //         static_assert(std::is_enum_v<E>);
        //
        //         setTypeInfo(details::getTypeInfo<E>());
        //         setEnumItemTable(&enumerate<E>());
        //
        //         number_ = EnumNumber(default_value);
        //         return ((Mem<E>*)(&number_))->raw;
        //     }
        //
        // public:
        //     /**
        //      * @brief 设定枚举值
        //      * @note 即使本类没有进行类型初始化，也不影响本接口使用
        //      */
        //     void setNumber(EnumNumber n) override;
        //
        //     /**
        //      * @return 获取枚举值
        //      * @note 即使本类没有进行类型初始化，也不影响本接口使用
        //      */
        //     [[nodiscard]] EnumNumber number() const override;
        //
        // public:
        //     /**
        //      * @brief 将本枚举值对象的数据转换为给定类型，返回该数据的引用
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     E& as()
        //     {
        //         static_assert(std::is_enum_v<E>);
        //
        //         if (not is<E>())
        //             throw std::logic_error("wrong type");
        //         else
        //             return ((Mem<E>*)(&number_))->raw;
        //     }
        //
        //     template <class E>
        //     const E& as() const
        //     {
        //         return zsibot::utils::remove_const(this)->as<E>();
        //     }
        //
        //     /**
        //      * @brief 将本枚举值对象的数据转换为给定类型，返回该数据的指针
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     E* ptr()
        //     {
        //         static_assert(std::is_enum_v<E>);
        //
        //         if (not is<E>())
        //             return nullptr;
        //         else
        //             return &((Mem<E>*)(&number_))->raw;
        //     }
        //
        //     template <class E>
        //     const E* ptr() const
        //     {
        //         return zsibot::utils::remove_const(this)->ptr<E>();
        //     }
        //
        // private:
        //     // 由 assign 流程使用
        //     friend void details::assignEnum(Object& dst, EnumNumber num, details::TypeInfo type_info, const EnumItemTable* items_ptr);
        //
        // private:
        //     EnumNumber number_ = {};
        // };

    public:
        /**
         * @brief 链表型数据
         */
        class List
        {
        public:
            using Iterator      = zsibot::iterator<Object>;
            using ConstIterator = zsibot::iterator<const Object>;

        private:
            using IteratorCore = zsibot::container::iterator::WrapperCore<Object, std::list<Object>::iterator>;

            using ConstIteratorCore = zsibot::container::iterator::WrapperCore<const Object, std::list<Object>::const_iterator>;

        public:
            /**
             * @brief 使用给定的链表型数据，递归初始化本对象
             */
            template <class T>
            void init(std::list<T> default_value = {})
            {
                clear();

                for (T& i : default_value)
                    pushBack().init(std::move(i));
            }

        public:
            /**
             * @brief 添加新元素到队列末尾
             * @return 新追加的对象
             */
            Object& pushBack();

            /**
             * @brief 添加新元素到队列开端
             * @return 新追加的对象
             */
            Object& pushFront();

            /**
             * @return 队列开端的对象
             */
            Object& front();

            /**
             * @return 队列开端的对象
             */
            [[nodiscard]] const Object& front() const;

            /**
             * @return 队列末尾的对象
             */
            Object& back();

            /**
             * @return 队列末尾的对象
             */
            [[nodiscard]] const Object& back() const;

            /**
             * @return 元素个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 链表中是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @brief 清空所有元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增的对象
             */
            Object& insert(const Iterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增的对象
             */
            Object& insert(const ConstIterator& it);

        public:
            Iterator begin();
            Iterator end();

            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for TObject::TList");
            }

        private:
            std::list<Object> data_;
        };

    public:
        /**
         * @brief 动态数组型数据
         */
        class Vector
        {
        public:
            using Iterator      = zsibot::iterator<Object>;
            using ConstIterator = zsibot::iterator<const Object>;

        private:
            using IteratorCore = zsibot::container::iterator::WrapperCore<Object, std::vector<Object>::iterator>;

            using ConstIteratorCore = zsibot::container::iterator::WrapperCore<const Object, std::vector<Object>::const_iterator>;

        public:
            /**
             * @brief 使用给定的动态数组型对象，递归初始化本对象
             */
            template <class T>
            void init(std::vector<T> default_value = {})
            {
                reserve(default_value.size());
                clear();

                for (auto& i : default_value)
                    pushBack().init(std::move(i));
            }

        public:
            /**
             * @brief 添加新元素到数组末尾
             * @return 新增的对象
             */
            Object& pushBack();

            /**
             * @brief 删除最后一个元素
             */
            void popBack();

            /**
             * @return 数组第一个对象
             */
            Object& front();

            /**
             * @return 数组第一个对象
             */
            [[nodiscard]] const Object& front() const;

            /**
             * @return 数组最后一个对象
             */
            Object& back();

            /**
             * @return 数组最后一个对象
             */
            [[nodiscard]] const Object& back() const;

            /**
             * @return 数组内指定索引的对象
             */
            Object& operator[](std::size_t i);

            /**
             * @return 数组内指定索引的对象
             */
            const Object& operator[](std::size_t i) const;

            /**
             * @return 数组内指定索引的对象
             */
            Object& at(std::size_t i);

            /**
             * @return 数组内指定索引的对象
             */
            [[nodiscard]] const Object& at(std::size_t i) const;

            /**
             * @brief 重置数组大小
             */
            void resize(std::size_t n);

            /**
             * @brief 预分配数组的内存
             */
            void reserve(std::size_t n);

            /**
             * @return 元素个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 数组是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @brief 清空所有元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增的对象
             */
            Object& insert(const Iterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增的对象
             */
            Object& insert(const ConstIterator& it);

        public:
            Iterator begin();
            Iterator end();

            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for TObject::TVector");
            }

        private:
            std::vector<Object> data_;
        };

    public:
        /**
         * @brief 字符串字典型数据，仅支持 key 为 string 的情况
         */
        class StrDict
        {
        public:
            using DataType      = std::map<std::string, Object>::value_type;
            using Iterator      = zsibot::iterator<DataType>;
            using ConstIterator = zsibot::iterator<const DataType>;

        private:
            using IteratorCore = zsibot::container::iterator::WrapperCore<DataType, std::map<std::string, Object>::iterator>;

            using ConstIteratorCore = zsibot::container::iterator::WrapperCore<const DataType, std::map<std::string, Object>::const_iterator>;

        public:
            template <class T>
            void init(std::map<std::string, T> default_value = {})
            {
                clear();

                for (auto& [key, value] : default_value)
                    insertOfAssign(key, Object())->second.init(std::move(value));
            }

        public:
            /**
             * @return 元素个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 字典是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @return 指定键值的对象
             * @throw std::out_of_range 若指定键值的元素不存在时，将抛出异常
             */
            Object& at(const std::string& key);

            /**
             * @return 指定键值的对象
             * @throw std::out_of_range 若指定键值的元素不存在时，将抛出异常
             */
            [[nodiscard]] const Object& at(const std::string& key) const;

            /**
             * @return 指定键值的对象
             * @throw std::out_of_range 若指定键值的元素不存在时，将抛出异常
             */
            Object& operator[](const std::string& key);

            /**
             * @brief 查找指定键值的元素
             * @return 该元素的迭代器，若不存在该元素时，返回 end()
             */
            Iterator find(const std::string& key);

            /**
             * @brief 查找指定键值的元素
             * @return 该元素的迭代器，若不存在该元素时，返回 end()
             */
            [[nodiscard]] ConstIterator find(const std::string& key) const;

            /**
             * @brief 删除所有的元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);


            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 删除指定键值的元素
             */
            void erase(const std::string& key);

            /**
             * @brief 插入或刷新指定键值的元素
             * @return 该键值的对象迭代器
             */
            Iterator insertOfAssign(const std::string& key, Object obj);

        public:
            Iterator begin();
            Iterator end();

            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for TObject::TStrDict");
            }

        private:
            std::map<std::string, Object> data_;
        };

    public:
        /**
         * @brief optional 类型的数据
         */
        class Optional
        {
        public:
            Optional();

            Optional(const Optional& other);

            Optional(Optional&& other) noexcept;

            Optional& operator=(const Optional& other);

            Optional& operator=(Optional&& other) noexcept;

            ~Optional();

        public:
            /**
             * @brief 使用 optional 类型的对象，递归初始化本对象
             */
            template <class T>
            void init(std::optional<T> default_value = {})
            {
                if (default_value.has_value())
                    emplace().init(std::move(default_value.value()));
                else
                    reset();
            }

        public:
            /**
             * @brief 填充数据，将替换原有的数据
             * @return 新增的对象
             */
            Object& emplace();

            /**
             * @brief 清空数据
             */
            void reset();

            /**
             * @return 是否存在有效数据
             */
            [[nodiscard]] bool has_value() const;

            /**
             * @return 有效的对象
             */
            Object& value();

            /**
             * @return 有效的对象
             */
            [[nodiscard]] const Object& value() const;

        private:
            // 对象数据
            Object* data_ptr_ = nullptr;

            // 对象数据是否可用
            bool is_data_valid_ = false;
        };

        /**
         * @brief 结构型对象
         */
        class Struct
        {
        public:
            using DataType      = std::pair<const std::string, Object>;
            using Iterator      = zsibot::iterator<DataType>;
            using ConstIterator = zsibot::iterator<const DataType>;

        private:
            using IteratorCore = zsibot::container::iterator::WrapperCore<DataType, std::list<DataType>::iterator>;

            using ConstIteratorCore = zsibot::container::iterator::WrapperCore<const DataType, std::list<DataType>::const_iterator>;

        public:
            Struct() = default;

            Struct(const Struct& other);

            Struct(Struct&& other) noexcept = default;

            Struct& operator=(const Struct& other);

            Struct& operator=(Struct&& other) noexcept = default;

        public:
            /**
             * @brief 使用给定的结构化类型对象，递归初始化本对象的内容
             */
            template <class T>
            void init(T default_value = {})
            {
                // 清空已有字段
                clear();

                // 访问该类型的所有字段，逐一初始化
                visitFields(default_value,
                    [this](const char* field_name, auto& field)
                    {
                        this->pushBack(field_name).init(std::move(field));
                    });
            }

        public:
            /**
             * @brief 在字段列表末尾添加新的字段
             * @return 新增的对象
             * @throw std::logic_error 若指定名称的字段已经存在时，将抛出异常
             */
            Object& pushBack(const std::string& field_name);

            /**
             * @brief 在字段列表末尾添加新的字段
             * @return 新增的对象
             * @throw std::logic_error 若指定名称的字段已经存在时，将抛出异常
             */
            Object& pushFront(const std::string& field_name);

            /**
             * @return 第一个字段及其名称
             */
            DataType& front();

            /**
             * @return 第一个字段及其名称
             */
            [[nodiscard]] const DataType& front() const;

            /**
             * @return 最后一个字段及其名称
             */
            DataType& back();

            /**
             * @return 最后一个字段及其名称
             */
            [[nodiscard]] const DataType& back() const;

            /**
             * @return 字段的数量
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 字段是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @brief 清空所有字段
             */
            void clear();

            /**
             * @return 指定名称的字段
             * @throw std::out_of_range 若指定键值的元素不存在时，将抛出异常
             */
            Object& get(const std::string& field_name);

            /**
             * @return 指定名称的字段
             * @throw std::out_of_range 若指定键值的元素不存在时，将抛出异常
             */
            [[nodiscard]] const Object& get(const std::string& field_name) const;

            /**
             * @brief 查找指定名称的字段
             * @return 该字段的迭代器，若没有找到，将返回 end()
             */
            Iterator find(const std::string& field_name);

            /**
             * @brief 查找指定名称的字段
             * @return 该字段的迭代器，若没有找到，将返回 end()
             */
            [[nodiscard]] ConstIterator find(const std::string& field_name) const;

            /**
             * @brief 删除指定位置处的字段
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的字段
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 删除指定名称的字段
             */
            void erase(const std::string& field_name);

            /**
             * @brief 在指定位置处，插入新的字段
             * @return 新增的对象
             * @throw std::logic_error 若指定名称的字段已经存在时，将抛出异常
             */
            Object& insert(const Iterator& it, const std::string& field_name);

            /**
             * @brief 在指定位置处，插入新的字段
             * @return 新增的对象
             * @throw std::logic_error 若指定名称的字段已经存在时，将抛出异常false
             */
            Object& insert(const ConstIterator& it, const std::string& field_name);

        public:
            Iterator begin();
            Iterator end();

            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for TObject::TStruct");
            }

        private:
            std::list<DataType>                                  data_;
            std::map<std::string, std::list<DataType>::iterator> data_iterators_by_name_;
        };

    public:
        Object()                         = default;
        Object(const Object&)            = default;
        Object& operator=(const Object&) = default;

        Object(Object&& other) noexcept;
        Object& operator=(Object&& other) noexcept;

    public:
        /**
         * @return 数据的类型
         */
        [[nodiscard]] ObjectType type() const;

        [[nodiscard]] bool isUndefined() const;

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    bool is##_type_() const;                                                                                                               \
                                                                                                                                           \
    _type_& as##_type_();                                                                                                                  \
                                                                                                                                           \
    const _type_& as##_type_() const;                                                                                                      \
                                                                                                                                           \
    _type_& initAs##_type_();

        ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 将本对象初始化为指定类型（内部数据均为空）
         */
        void initAs(ObjectType object_type);

    public:
        template <class T>
        void init(T default_value = {})
        {
            if constexpr (details::isValue<T>())
            {
                data_.emplace<Value>().init(std::move(default_value));
            }
            // else if constexpr (std::is_enum_v<T>)
            // {
            //     data_.emplace<Enum>().init(std::move(default_value));
            // }
            else
            {
                data_.emplace<Struct>().init(std::move(default_value));
            }
        }

        void init(const char* literal_str)
        {
            init(std::string(literal_str));
        }

#define ZSIBOT_DETAILS_IMPL(_container_type_)                                                                                                \
    template <class T>                                                                                                                     \
    void init(::zsibot::binding::def::_container_type_<T> default_value = {})                                                                \
    {                                                                                                                                      \
        data_.emplace<_container_type_>().init(std::move(default_value));                                                                  \
    }

        ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 重置对象为空
         */
        void reset();

    private:
        // 本对象的真实形态数据
#define ZSIBOT_DETAILS_IMPL(_type_) , _type_
        std::variant<std::nullptr_t ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)> data_ = nullptr;
#undef ZSIBOT_DETAILS_IMPL
    };
}  // namespace zsibot::binding
