#pragma once

#include <zsibot/binding/object.hpp>
#include <zsibot/binding/object/object_const_view.hpp>
#include <zsibot/binding/object/object_view.hpp>


namespace zsibot::binding::details
{
    template <class T, bool IS_CONST>
    struct ConstOrNot;

    template <class T>
    struct ConstOrNot<T, true>
    {
        using Type = const T;
    };

    template <class T>
    struct ConstOrNot<T, false>
    {
        using Type = T;
    };

    template <>
    struct ConstOrNot<ObjectView, true>
    {
        using Type = const ObjectConstView;
    };

    template <class TObjectType, bool IS_CONST>
    class IVisitor
    {
    protected:
        using TObject   = typename ConstOrNot<TObjectType, IS_CONST>::Type;
        using TValue    = typename ConstOrNot<typename TObject::Value, IS_CONST>::Type;
        // using TEnum     = typename ConstOrNot<typename TObject::Enum, IS_CONST>::Type;
        using TList     = typename ConstOrNot<typename TObject::List, IS_CONST>::Type;
        using TVector   = typename ConstOrNot<typename TObject::Vector, IS_CONST>::Type;
        using TStrDict  = typename ConstOrNot<typename TObject::StrDict, IS_CONST>::Type;
        using TOptional = typename ConstOrNot<typename TObject::Optional, IS_CONST>::Type;
        using TStruct   = typename ConstOrNot<typename TObject::Struct, IS_CONST>::Type;

    public:
        /**
         * @brief 准备开始遍历
         * @return 是否允许遍历
         */
        virtual bool onBegin(TObject& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 结束遍历的收尾
         * @param status 此前的遍历是否被中断
         */
        virtual void onEnd(TObject& obj, bool status)
        {
            ZSIBOT_UNUSED(obj, status);
        }

        /**
         * @return 是否继续遍历
         */
        virtual bool onUndefined()
        {
            return true;
        }

        /**
         * @brief 处理值类型的对象
         * @return 是否继续遍历
         */
        virtual bool onValue(TValue& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 处理枚举类型的对象
         * @return 是否继续遍历
         */
        // virtual bool onEnum(TEnum& obj)
        // {
        //     ZSIBOT_UNUSED(obj);
        //     return true;
        // }

        /**
         * @brief 准备开始处理链表型的对象
         * @return 是否继续遍历
         */
        virtual bool onListBegin(TList& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理下一个的列表元素
         * @param idx 该元素在列表中的排位
         * @param object_type 该元素的类型
         * @return 是否继续遍历
         */
        virtual bool onListItem(std::size_t idx, ObjectType object_type)
        {
            ZSIBOT_UNUSED(idx, object_type);
            return true;
        }

        /**
         * @brief 结束处理链表型的对象
         * @return 是否继续遍历
         */
        virtual bool onListEnd(TList& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理动态数组类型的对象
         * @return 是否继续遍历
         */
        virtual bool onVectorBegin(TVector& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理下一个数组元素
         * @param idx 该元素在数组中的排位
         * @param object_type 该元素的类型
         * @return 是否继续遍历
         */
        virtual bool onVectorItem(std::size_t idx, ObjectType object_type)
        {
            ZSIBOT_UNUSED(idx, object_type);
            return true;
        }

        /**
         * @brief 结束处理动态数组类型的对象
         * @return 是否继续遍历
         */
        virtual bool onVectorEnd(TVector& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始遍历字符串字典类型的对象
         * @return 是否继续遍历
         */
        virtual bool onStrDictBegin(TStrDict& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理下一个字符串字典元素
         * @param key 该元素的键值
         * @param idx 该元素在字典中的排位
         * @param object_type 该元素的类型
         * @return 是否继续遍历
         */
        virtual bool onStrDictItem(const std::string& key, std::size_t idx, ObjectType object_type)
        {
            ZSIBOT_UNUSED(key, idx, object_type);
            return true;
        }

        /**
         * @brief 结束处理字符串字典型对象
         * @return 是否继续遍历
         */
        virtual bool onStrDictEnd(TStrDict& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 开始准备处理 optional 类型的对象
         * @return 是否继续遍历
         */
        virtual bool onOptionalBegin(TOptional& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理 optional 对象中的值
         * @param has_value 该值是否存在
         * @param object_type 该值的类型
         * @return 是否继续遍历
         */
        virtual bool onOptionalItem(bool has_value, ObjectType object_type)
        {
            ZSIBOT_UNUSED(has_value, object_type);
            return true;
        }

        /**
         * @brief 结束处理 optional 类型的对象
         * @return 是否继续遍历
         */
        virtual bool onOptionalEnd(TOptional& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理结构化类型的对象
         * @return 是否继续遍历
         */
        virtual bool onStructBegin(TStruct& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

        /**
         * @brief 准备开始处理下一个字段
         * @param field_name 该字段的名称
         * @param idx 该字段的排位
         * @param object_type 该字段的类型
         * @return 是否继续遍历
         */
        virtual bool onStructItem(const std::string& field_name, std::size_t idx, ObjectType object_type)
        {
            ZSIBOT_UNUSED(field_name, idx, object_type);
            return true;
        }

        /**
         * @brief 结束处理结构化类型的对象
         * @return 是否继续遍历
         */
        virtual bool onStructEnd(TStruct& obj)
        {
            ZSIBOT_UNUSED(obj);
            return true;
        }

    public:
        virtual ~IVisitor() = default;
    };
}  // namespace zsibot::binding::details

namespace zsibot::binding
{
    using IConstObjectVisitor       = details::IVisitor<Object, true>;
    using IMutableObjectVisitor     = details::IVisitor<Object, false>;
    using IConstObjectViewVisitor   = details::IVisitor<ObjectView, true>;
    using IMutableObjectViewVisitor = details::IVisitor<ObjectView, false>;

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const Object& obj, IConstObjectVisitor& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const Object& obj, IConstObjectVisitor&& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(Object& obj, IMutableObjectVisitor& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(Object& obj, IMutableObjectVisitor&& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const ObjectView& obj, IConstObjectViewVisitor& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const ObjectView& obj, IConstObjectViewVisitor&& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const ObjectConstView& obj, IConstObjectViewVisitor& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(const ObjectConstView& obj, IConstObjectViewVisitor&& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(ObjectView& obj, IMutableObjectViewVisitor& visitor);

    /**
     * @brief 遍历对象
     * @return 是否被中断
     */
    bool visit(ObjectView& obj, IMutableObjectViewVisitor&& visitor);
}  // namespace zsibot::binding
