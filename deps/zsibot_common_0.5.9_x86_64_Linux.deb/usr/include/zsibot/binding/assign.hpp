#pragma once


#include "zsibot/binding/object.hpp"
#include "zsibot/binding/object/object_view.hpp"

namespace zsibot::binding
{

    enum class AssignmentFallback
    {
        /// 中断赋值处理
        Break,

        /// 忽略当前对象的赋值，继续后续的赋值流程
        Ignore,

        /// 修改类型，以求适配
        Fix
    };
}  // namespace zsibot::binding


namespace zsibot::binding::details
{
    template <class TSrcObject, class TDstObject>
    class IAssigner;

    template <class TSrcObject>
    class IAssigner<TSrcObject, Object>
    {
    public:
        /**
         * @brief 需要赋值的对象类型不一致时的处理
         * @return 处理策略
         */
        virtual AssignmentFallback onObjectTypeMiss(Object& dst, const TSrcObject& src) = 0;

        /**
         * @brief 需要赋值的值对象类型不一致时的处理
         * @return 处理策略
         */
        virtual AssignmentFallback onValueTypeMiss(Object::Value& dst, const typename TSrcObject::Value& src) = 0;

        /**
         * @brief 需要赋值的枚举对象类型不一致时的处理
         * @return 处理策略
         */
        // virtual AssignmentFallback onEnumTypeMiss(Object::Enum& dst, const typename TSrcObject::Enum& src) = 0;

        /**
         * @brief 需要赋值的结构型对象缺失字段时的处理
         * @return 处理策略
         */
        virtual AssignmentFallback onOmittedField(const std::string& field_name, const TSrcObject& field) = 0;

        /**
         * @brief 需要赋值的结构型对象存在多余字段时的处理
         * @return 处理策略
         */
        virtual AssignmentFallback onUnwantedField(const std::string& field_name, const Object& field) = 0;

    public:
        virtual ~IAssigner() = default;
    };

    template <class TSrcObject>
    class IAssigner<TSrcObject, ObjectView>
    {
    public:
        /**
         * @brief 需要赋值的对象类型不一致时的处理
         * @return 是否继续赋值流程
         */
        virtual bool onObjectTypeMiss(ObjectView& dst, const TSrcObject& src) = 0;

        /**
         * @brief 需要赋值的值对象类型不一致时的处理
         * @return 是否继续赋值流程
         */
        virtual bool onValueTypeMiss(ObjectView::Value& dst, const typename TSrcObject::Value& src) = 0;

        /**
         * @brief 需要赋值的枚举对象类型不一致时的处理
         * @return 是否继续赋值流程
         */
        // virtual bool onEnumTypeMiss(ObjectView::Enum& dst, const typename TSrcObject::Enum& src) = 0;

        /**
         * @brief 需要赋值的结构型对象缺失字段时的处理
         * @return 是否继续赋值流程
         */
        virtual bool onOmittedField(const std::string& field_name, const TSrcObject& field) = 0;

        /**
         * @brief 需要赋值的结构型对象存在多余字段时的处理
         * @return 是否继续赋值流程
         */
        virtual bool onUnwantedField(const std::string& field_name, const ObjectView& field) = 0;

    public:
        virtual ~IAssigner() = default;
    };
}  // namespace zsibot::binding::details

namespace zsibot::binding::details
{

    template <class TSrcObject, class TDstObject>
    class DefaultAssignerImpl;

    template <class TSrcObject>
    class DefaultAssignerImpl<TSrcObject, Object> : public IAssigner<TSrcObject, Object>
    {
    public:
        AssignmentFallback onObjectTypeMiss(Object&, const TSrcObject&) override
        {
            return AssignmentFallback::Fix;
        }

        AssignmentFallback onValueTypeMiss(Object::Value&, const typename TSrcObject::Value&) override
        {
            return AssignmentFallback::Fix;
        }

        // AssignmentFallback onEnumTypeMiss(Object::Enum&, const typename TSrcObject::Enum&) override
        // {
        //     return AssignmentFallback::Fix;
        // }

        AssignmentFallback onOmittedField(const std::string&, const TSrcObject&) override
        {
            return AssignmentFallback::Fix;
        }

        AssignmentFallback onUnwantedField(const std::string&, const Object&) override
        {
            return AssignmentFallback::Ignore;
        }
    };

    template <class TSrcObject>
    class DefaultAssignerImpl<TSrcObject, ObjectView> : public IAssigner<TSrcObject, ObjectView>
    {
    public:
        bool onObjectTypeMiss(ObjectView&, const TSrcObject&) override
        {
            return false;
        }

        bool onValueTypeMiss(ObjectView::Value&, const typename TSrcObject::Value&) override
        {
            return false;
        }

        // bool onEnumTypeMiss(ObjectView::Enum&, const typename TSrcObject::Enum&) override
        // {
        //     return false;
        // }

        bool onOmittedField(const std::string&, const TSrcObject&) override
        {
            return false;
        }

        bool onUnwantedField(const std::string&, const ObjectView&) override
        {
            return false;
        }
    };
}  // namespace zsibot::binding::details

namespace zsibot::binding
{
    enum Assignment
    {
        ASSIGN_OBJECT_TO_OBJECT,
        ASSIGN_OBJECT_TO_OBJECT_VIEW,
        ASSIGN_OBJECT_VIEW_TO_OBJECT,
        ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW
    };

    namespace details
    {
        template <Assignment TYPE>
        struct AssignerSelector;

        template <>
        struct AssignerSelector<ASSIGN_OBJECT_TO_OBJECT>
        {
            using Type = IAssigner<Object, Object>;
        };

        template <>
        struct AssignerSelector<ASSIGN_OBJECT_TO_OBJECT_VIEW>
        {
            using Type = IAssigner<Object, ObjectView>;
        };

        template <>
        struct AssignerSelector<ASSIGN_OBJECT_VIEW_TO_OBJECT>
        {
            using Type = IAssigner<ObjectConstView, Object>;
        };

        template <>
        struct AssignerSelector<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>
        {
            using Type = IAssigner<ObjectConstView, ObjectView>;
        };
    }  // namespace details

    /**
     * @brief 赋值器接口
     * @tparam TYPE 赋值的情况分类
     */
    template <Assignment TYPE>
    using IAssigner = typename details::AssignerSelector<TYPE>::Type;
}  // namespace zsibot::binding

namespace zsibot::binding
{
    namespace details
    {
        template <Assignment TYPE>
        struct DefaultAssignerImplSelector;

        template <>
        struct DefaultAssignerImplSelector<ASSIGN_OBJECT_TO_OBJECT>
        {
            using Type = DefaultAssignerImpl<Object, Object>;
        };

        template <>
        struct DefaultAssignerImplSelector<ASSIGN_OBJECT_TO_OBJECT_VIEW>
        {
            using Type = DefaultAssignerImpl<Object, ObjectView>;
        };

        template <>
        struct DefaultAssignerImplSelector<ASSIGN_OBJECT_VIEW_TO_OBJECT>
        {
            using Type = DefaultAssignerImpl<ObjectConstView, Object>;
        };

        template <>
        struct DefaultAssignerImplSelector<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>
        {
            using Type = DefaultAssignerImpl<ObjectConstView, ObjectView>;
        };
    }  // namespace details

    /**
     * @brief 默认赋值器，赋值给 TObject 时，将采样覆盖式赋值；赋值给 ObjectView 时，将执行严格的匹配检查。
     */
    template <Assignment TYPE>
    using DefaultAssigner = typename details::DefaultAssignerImplSelector<TYPE>::Type;
}  // namespace zsibot::binding


namespace zsibot::binding
{
    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const Object& src, IAssigner<ASSIGN_OBJECT_TO_OBJECT>&& assigner = DefaultAssigner<ASSIGN_OBJECT_TO_OBJECT>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const Object& src, IAssigner<ASSIGN_OBJECT_TO_OBJECT>& assigner);

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const ObjectView& src,
        IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>&& assigner = DefaultAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const ObjectView& src, IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>& assigner);

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const ObjectConstView& src,
        IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>&& assigner = DefaultAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(Object& dst, const ObjectConstView& src, IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT>& assigner);

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const Object& src,
        IAssigner<ASSIGN_OBJECT_TO_OBJECT_VIEW>&& assigner = DefaultAssigner<ASSIGN_OBJECT_TO_OBJECT_VIEW>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const Object& src, IAssigner<ASSIGN_OBJECT_TO_OBJECT_VIEW>& assigner);

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const ObjectView& src,
        IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>&& assigner = DefaultAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const ObjectView& src, IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>& assigner);

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const ObjectConstView& src,
        IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>&& assigner = DefaultAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>());

    /**
     * @brief 赋值对象
     * @return 是否被中断
     */
    bool assign(ObjectView& dst, const ObjectConstView& src, IAssigner<ASSIGN_OBJECT_VIEW_TO_OBJECT_VIEW>& assigner);
}  // namespace zsibot::binding
