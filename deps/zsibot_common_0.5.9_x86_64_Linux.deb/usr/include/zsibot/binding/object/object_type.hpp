#pragma once

#include <list>
#include <map>
#include <optional>
#include <string>
#include <vector>

#include "zsibot/binding/macro_helper.hpp"

namespace zsibot::binding::def
{
    template <class T>
    using List = std::list<T>;

    template <class T>
    using Vector = std::vector<T>;

    template <class T>
    using StrDict = std::map<std::string, T>;

    template <class T>
    using Optional = std::optional<T>;

    template <class T>
    using Struct = T;


    using Bool   = bool;
    using Char   = char;
    using Int8   = int8_t;
    using UInt8  = uint8_t;
    using Int16  = int16_t;
    using UInt16 = uint16_t;
    using Int32  = int32_t;
    using UInt32 = uint32_t;
    using Int64  = int64_t;
    using UInt64 = uint64_t;
    using Float  = float;
    using Double = double;
    using String = std::string;
    // TODO: custom type
}  // namespace zsibot::binding::def

namespace zsibot::binding
{
    /**
     * @brief object type enum
     */
    enum class ObjectType
    {
        Undefined,

#define ZSIBOT_DETAILS_IMPL(_type_) _type_,
        ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL
    };


    /**
     * @brief get object type str
     * @param type object type enum
     * @return
     */
    inline std::string GetObjectTypeStr(const ObjectType& type)
    {
        switch (type)
        {
            case ObjectType::Undefined:
                return "Undefined";

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    case ObjectType::_type_:                                                                                                               \
        return #_type_;

                ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL


            default:;
                return "Undefined";
        }
    }


    /**
     * @brief the type of value enum
     */
    enum class ValueType : size_t
    {
        Undefined,

#define ZSIBOT_DETAILS_IMPL(_type_) _type_,
        // zsibot::binding 内置的值类型
        ZSIBOT_BINDING_INSTANTIATES_VALUE_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        // 用户定义的值类型
        CustomDefined,
    };

    /**
     * @brief get value type str
     * @param type value type enum
     * @return
     */
    inline std::string GetValueTypeStr(const ValueType& type)
    {
        switch (type)
        {
            case ValueType::Undefined:
                return "Undefined";

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    case ValueType::_type_:                                                                                                                \
        return #_type_;

                ZSIBOT_BINDING_INSTANTIATES_VALUE_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL


            default:;
                return "Undefined";
        }
    }

}  // namespace zsibot::binding


namespace zsibot::binding::details
{
    // 将 def 中的类型导入到 details 命名空间中
    using namespace ::zsibot::binding::def;

    /**
     * @brief 判断一个类型是否为值类型
     */
    template <class T>
    static constexpr bool isValue()
    {
        return false;
    }

}  // namespace zsibot::binding::details

// 创建将给定类型判断为值类型的判定过程
#define ZSIBOT_DETAILS_BINDING_IMPL_IS_VALUE(_type_)                                                                                         \
    namespace zsibot::binding::details                                                                                                       \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        [[maybe_unused]] constexpr inline bool isValue<_type_>()                                                                           \
        {                                                                                                                                  \
            return true;                                                                                                                   \
        }                                                                                                                                  \
    }

namespace zsibot::binding
{
    /**
     * @brief get value type
     */
    template <class T>
    constexpr ValueType getValueType()
    {
        if constexpr (not details::isValue<T>())
            return ValueType::Undefined;

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    if constexpr (std::is_same_v<def::_type_, T>)                                                                                          \
        return ValueType::_type_;

        ZSIBOT_BINDING_INSTANTIATES_VALUE_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        return ValueType::CustomDefined;
    }
}  // namespace zsibot::binding