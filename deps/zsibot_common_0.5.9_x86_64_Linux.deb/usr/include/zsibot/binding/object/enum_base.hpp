#pragma once

#include <cstdint>

namespace zsibot::binding
{
    using EnumNumber = std::int64_t;

    struct EnumItem
    {
        std::string name;
        EnumNumber  number = 0;

        /**
         * @brief Description a normal enum
         * @tparam TEnum
         * @param name
         * @param n
         */
        template <class TEnum>
        EnumItem(std::string name, TEnum n)
            : name(std::move(name)),
              number(static_cast<EnumNumber>(n))
        {
            static_assert(std::is_enum_v<TEnum>);
        }
    };

}