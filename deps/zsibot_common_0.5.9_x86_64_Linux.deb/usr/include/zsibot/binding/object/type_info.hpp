#pragma once

#include "zsibot/binding/object/object_type.hpp"

namespace zsibot::binding::details
{
    struct TypeInfo
    {
        // 类型名称
        const char* name = nullptr;

        // 类型哈希值
        std::size_t hash_code = 0;
    };


    template <class T>
    static constexpr TypeInfo getSimplexTypeInfo();


    template <class T>
    static constexpr TypeInfo getContainerTypeInfo();


    template <class T>
    struct TypeHelper
    {
        constexpr static TypeInfo info = getSimplexTypeInfo<T>();
    };

    template <class T, bool IS_VALUE = isValue<T>()>
    struct ContainerTypeHelper;

    template <class T>
    struct ContainerTypeHelper<T, true>
    {
        constexpr static TypeInfo info = getSimplexTypeInfo<T>();
    };


    template <class T>
    struct ContainerTypeHelper<T, false>
    {
        constexpr static TypeInfo info = getContainerTypeInfo<T>();
    };

    // 特化被显式注册为值类型的容器化类型，让他们的信息来自简单类型计算的结果
#define ZSIBOT_DETAILS_IMPL(_container_type_)                                                                                                \
    template <class T>                                                                                                                     \
    struct TypeHelper<def::_container_type_<T>>                                                                                            \
    {                                                                                                                                      \
        constexpr static TypeInfo info = ContainerTypeHelper<def::_container_type_<T>>::info;                                              \
    };

    ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

    template <class T>
    static constexpr TypeInfo getTypeInfo()
    {
        return TypeHelper<T>::info;
    }

}  // namespace zsibot::binding::details


// 辅助类型展开
#define ZSIBOT_DETAILS_BINDING_EXPAND_TYPE(_type_) , _type_


// 指定类型在一种容器内的信息注册实例化宏，辅助全容器类型信息注册宏的实现
#define ZSIBOT_DETAILS_BINDING_REGISTER_CONTAINER_TYPE_INFO_DO(_type_, _container_)                                                          \
    namespace zsibot::binding::details                                                                                                       \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        [[maybe_unused]] constexpr inline TypeInfo getContainerTypeInfo<def::_container_<_type_>>()                                        \
        {                                                                                                                                  \
            using namespace zsibot::string_hash::literals;                                                                                   \
                                                                                                                                           \
            TypeInfo info;                                                                                                                 \
            info.name      = #_container_ "<" #_type_ ">";                                                                                 \
            info.hash_code = #_container_ "<" #_type_ ">"##_js_hash;                                                                       \
                                                                                                                                           \
            return info;                                                                                                                   \
        }                                                                                                                                  \
    }


#define ZSIBOT_DETAILS_BINDING_REGISTER_TYPE_INFO(_type_)                                                                                    \
    namespace zsibot::binding::details                                                                                                       \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        [[maybe_unused]] constexpr inline TypeInfo getSimplexTypeInfo<_type_>()                                                            \
        {                                                                                                                                  \
            using namespace zsibot::string_hash::literals;                                                                                   \
                                                                                                                                           \
            TypeInfo info;                                                                                                                 \
            info.name      = #_type_;                                                                                                      \
            info.hash_code = #_type_##_fnv_hash;                                                                                           \
                                                                                                                                           \
            return info;                                                                                                                   \
        }                                                                                                                                  \
    }                                                                                                                                      \
    ZSIBOT_MACRO_INVOKE_WITH(ZSIBOT_DETAILS_BINDING_REGISTER_CONTAINER_TYPE_INFO_DO, 1,                                                        \
        _type_ ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_BINDING_EXPAND_TYPE))
