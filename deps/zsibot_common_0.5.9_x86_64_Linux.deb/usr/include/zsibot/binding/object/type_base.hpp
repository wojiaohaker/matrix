#pragma once

#include "zsibot/binding/object/type_info.hpp"

namespace zsibot::binding::details
{
    class TypeBase
    {
    protected:
        TypeBase() = default;

        explicit TypeBase(const TypeInfo& info)
            : info_(info)
        {
        }

    public:
        [[nodiscard]] const char* name() const
        {
            return info_.name;
        }


        [[nodiscard]] std::size_t hashCode() const
        {
            return info_.hash_code;
        }

        template <class T>
        [[nodiscard]] bool is() const
        {
            return getTypeInfo<T>().hash_code == info_.hash_code;
        }

    protected:
        void setTypeInfo(const TypeInfo& info)
        {
            info_ = info;
        }

    private:
        friend TypeInfo getTypeInfo(const TypeBase& type_base)
        {
            return type_base.info_;
        }

        TypeInfo info_;
    };
}  // namespace zsibot::binding::details