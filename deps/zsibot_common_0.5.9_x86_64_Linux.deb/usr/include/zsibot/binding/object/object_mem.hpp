#pragma once

#include "zsibot/container/iterator.hpp"
#include "zsibot/binding/object/type_info.hpp"

#include <any>
#include <functional>
#include <variant>

namespace zsibot::binding::details
{
    class ObjectMem;

    template <class T>
    const ObjectMem* getObjectMem();

    template <class T>
    extern void fillFields(ObjectMem& mem);

    struct ObjectViewMeta
    {
        const ObjectMem* mem  = nullptr;
        void*            data = nullptr;
    };

}  // namespace zsibot::binding::details


namespace zsibot::binding
{
    namespace details
    {
        template <class T>
        struct VisitingHelper
        {
            template <class TVisitor>
            static void run(T& obj, TVisitor&& visitor);
        };
    }  // namespace details

    template <class T, class TVisitor>
    void visitFields(T& obj, TVisitor&& visitor)
    {
        details::VisitingHelper<T>::run(obj, std::forward<TVisitor>(visitor));
    }
}  // namespace zsibot::binding


#define ZSIBOT_DETAILS_BINDING_IMPL_FIELDS_FILLING(_type_, ...)                                                                              \
    namespace zsibot::binding::details                                                                                                       \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        [[maybe_unused]] inline void fillFields<_type_>(ObjectMem & mem)                                                                   \
        {                                                                                                                                  \
            ZSIBOT_MACRO_INVOKE_WITH(ZSIBOT_DETAILS_BINDING_IMPL_FILLING_ONE_FIELD, 1, _type_, __VA_ARGS__)                                    \
        }                                                                                                                                  \
    }

// 辅助创建结构类型的某个字段的内存信息注册过程
#define ZSIBOT_DETAILS_BINDING_IMPL_FILLING_ONE_FIELD(_type_, _field_)                                                                       \
    mem.asStruct().addField(#_field_, getObjectMem<decltype(ZSIBOT_DECLVALUE(_type_)._field_)>(), ZSIBOT_OFFSETOF(_type_, _field_));

// 创建结构类型的字段扫描过程
#define ZSIBOT_DETAILS_BINDING_IMPL_FIELDS_VISITING(_type_, ...)                                                                             \
    namespace zsibot::binding::details                                                                                                       \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        struct VisitingHelper<_type_>                                                                                                      \
        {                                                                                                                                  \
            template <class TVisitor>                                                                                                      \
            static void run(_type_& obj, TVisitor&& visitor)                                                                               \
            {                                                                                                                              \
                ZSIBOT_MACRO_INVOKE(ZSIBOT_DETAILS_BINDING_IMPL_VISITING_ONE_FIELD, __VA_ARGS__)                                               \
            }                                                                                                                              \
        };                                                                                                                                 \
                                                                                                                                           \
        template <>                                                                                                                        \
        struct VisitingHelper<const _type_>                                                                                                \
        {                                                                                                                                  \
            template <class TVisitor>                                                                                                      \
            static void run(const _type_& obj, TVisitor&& visitor)                                                                         \
            {                                                                                                                              \
                ZSIBOT_MACRO_INVOKE(ZSIBOT_DETAILS_BINDING_IMPL_VISITING_ONE_FIELD, __VA_ARGS__)                                               \
            }                                                                                                                              \
        };                                                                                                                                 \
    }

// 辅助创建结构型的某个字段的扫描过程
#define ZSIBOT_DETAILS_BINDING_IMPL_VISITING_ONE_FIELD(_field_) visitor(#_field_, obj._field_);

namespace zsibot::binding::details
{
    /**
     * @brief 记录某种类型的内存布局，以及隔离了真实类型的操作接口。
     */
    class ObjectMem
    {
    public:
        class Value
        {
        public:
            // 获取真实数据的拷贝
            std::function<std::any(void*)> copy;

            // 赋值真实数据
            std::function<void(void*, std::any data)> assign;

            // 获取值类型分类
            std::function<ValueType()> type;

            template <class T>
            explicit Value(const T*);
        };

        class List
        {
        public:
            using ConstIterator = zsibot::iterator<const ObjectViewMeta, 64>;

            // 在链表尾部追加元素
            std::function<ObjectViewMeta(void*)> push_back;

            // 在链表头部追加元素
            std::function<ObjectViewMeta(void*)> push_front;

            // 获取头部元素
            std::function<ObjectViewMeta(void*)> front;

            // 获取尾部元素
            std::function<ObjectViewMeta(void*)> back;

            // 获取元素个数
            std::function<std::size_t(void*)> size;

            // 清空链表
            std::function<void(void*)> clear;

            // 删除指定位置的元素
            std::function<ConstIterator(void*, const ConstIterator&)> erase;

            // 在指定位置处插入元素
            std::function<ObjectViewMeta(void*, const ConstIterator&)> insert;

            // 获取起止迭代器
            std::function<ConstIterator(void*)> begin;
            std::function<ConstIterator(void*)> end;

            template <class T>
            explicit List(const std::list<T>*);
        };

        class Vector
        {
        public:
            using ConstIterator = zsibot::iterator<const ObjectViewMeta, 64>;

            // 在数组末尾追加元素
            std::function<ObjectViewMeta(void*)> push_back;

            // 删除最后一个元素
            std::function<void(void*)> pop_back;

            // 获取指定索引处的元素
            std::function<ObjectViewMeta(void*, std::size_t)> at;

            // 重置数组大小
            std::function<void(void*, std::size_t)> resize;

            // 预分配数组内存
            std::function<void(void*, std::size_t)> reserve;

            // 获取元素个数
            std::function<std::size_t(void*)> size;

            // 清空所有元素
            std::function<void(void*)> clear;

            // 删除指定位置处的元素
            std::function<ConstIterator(void*, const ConstIterator&)> erase;

            // 在指定位置插入元素
            std::function<ObjectViewMeta(void*, const ConstIterator&)> insert;

            // 获取起止迭代器
            std::function<ConstIterator(void*)> begin;
            std::function<ConstIterator(void*)> end;

            template <class T>
            explicit Vector(const std::vector<T>*);
        };

        class StrDict
        {
        public:
            using Pair          = std::pair<std::string, ObjectViewMeta>;
            using ConstIterator = zsibot::iterator<const Pair, 72>;

            // 获取元素个数
            std::function<std::size_t(void*)> size;

            // 查找指定键值的元素，使用一个 bool 代表若元素不存在时，是否可以新建
            std::function<ObjectViewMeta(void*, const std::string&, bool can_emplace)> at;

            // 插入或赋值新的值到指定键值的元素上，返回它的迭代器
            std::function<ConstIterator(void*, const std::string&)> insert_or_assign;

            // 查找指定键值的元素
            std::function<ConstIterator(void*, const std::string&)> find;

            // 删除所有元素
            std::function<void(void*)> clear;

            // 删除指定位置处的元素
            std::function<ConstIterator(void*, const ConstIterator&)> erase;

            // 删除指定键值的元素
            std::function<void(void*, const std::string&)> erase_by_key;

            // 获取起止迭代器
            std::function<ConstIterator(void*)> begin;
            std::function<ConstIterator(void*)> end;

            template <class T>
            explicit StrDict(const std::map<std::string, T>*);
        };

        class Optional
        {
        public:
            // 设置新数据
            std::function<ObjectViewMeta(void*)> emplace;

            // 重置数据
            std::function<void(void*)> reset;

            // 判断当前数据是否有效
            std::function<bool(void*)> has_value;

            // 获取数据，可能无效
            std::function<ObjectViewMeta(void*)> value;

            template <class T>
            explicit Optional(const std::optional<T>*);
        };

        class Struct
        {
        public:
            using Pair          = std::pair<std::string, ObjectViewMeta>;
            using ConstIterator = zsibot::iterator<const Pair, 80>;

            struct Field
            {
                const char* name = nullptr;
                const ObjectMem* mem = nullptr;
                std::size_t offset = 0;
            };

            /**
             * @brief 添加新字段的布局。若出现了名字重复的字段，将报错
             */
            void addField(const char* name, const ObjectMem* mem, std::size_t offset);

            /**
             * @brief 按名称查找对应字段的信息
             */
            ConstIterator find(void* data_ptr, const std::string& name) const;

            /**
             * @return 字段的数量
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 字段是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @brief 获取字段内存结构的起止迭代器
             * @param data_ptr
             * @return
             */
            ConstIterator begin(void* data_ptr) const;
            ConstIterator end(void* data_ptr) const;

        // private:
            class IteratorCore : public zsibot::container::iterator::ICore<const Pair>
            {
                using Base          = zsibot::container::iterator::ICore<const Pair>;
                using This          = IteratorCore;
                using ConstIterator = std::list<Field>::const_iterator;

            public:
                IteratorCore(void* data_ptr, ConstIterator it, ConstIterator end_it);

                void next() final;

                void last() final;

                [[nodiscard]] const Pair& deref() const final;

                bool equal(const ICore* other) const final;

                long stepCountTo(const ICore* other) const final;

            private:
                void setData();

                // 真实数据的起始地址
                void* raw_ptr_ = nullptr;

                // 原始字段信息的起止迭代器
                ConstIterator it_, end_it_;

                // 当前的字段名称及其内存结构
                Pair data_;
            };

            // 所有字段的内存布局
            std::list<Field> fields_;

            // 按字段名称索引的迭代器
            std::map<std::string, std::list<Field>::const_iterator> fields_it_by_name_;
        };

        template <class T>
        void init()
        {
            if constexpr (details::isValue<T>())
            {
                info_ = getTypeInfo<T>();
                data_.emplace<Value>(static_cast<const T*>(nullptr));
            }
            // else if constexpr (std::is_enum_v<T>)
            // {
            //     info_ = getTypeInfo<T>();
            //     data_.emplace<Enum>((const T*)nullptr);
            // }
            else
            {
                initAsComplexType(static_cast<const T*>(nullptr));
            }
        }

        [[nodiscard]] ObjectType type() const;


        [[nodiscard]] TypeInfo info() const;


        [[nodiscard]] bool isUndefined() const;

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    [[nodiscard]] bool is##_type_() const;                                                                                                 \
                                                                                                                                           \
    _type_& as##_type_();                                                                                                                  \
                                                                                                                                           \
    [[nodiscard]] const _type_& as##_type_() const;

        ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

    private:

#define ZSIBOT_DETAILS_IMPL(_container_type_)                                                                                                \
    template <class T>                                                                                                                     \
    void initAsComplexType(const ::zsibot::binding::def::_container_type_<T>*)                                                               \
    {                                                                                                                                      \
        info_ = getTypeInfo<T>();                                                                                                          \
        data_.emplace<_container_type_>((const ::zsibot::binding::def::_container_type_<T>*)nullptr);                                        \
    }

        ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 初始化结构化类型的内存视图
         */
        template <class T>
        void initAsComplexType(const T*)
        {
            info_ = getTypeInfo<T>();
            data_.emplace<Struct>();
            fillFields<T>(*this);
        }

        // 内存布局数据，包含了隐藏了具体类型的操作器
#define ZSIBOT_DETAILS_IMPL(_type_) , _type_
        std::variant<std::nullptr_t ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)> data_ = nullptr;
#undef ZSIBOT_DETAILS_IMPL

        // 类型信息
        TypeInfo info_;
    };

    template <class T>
    ObjectMem::Value::Value(const T*)
    {
        copy = [](void* data_ptr) -> std::any
        {
            return *((T*)data_ptr);
        };

        assign = [](void* data_ptr, std::any data)
        {
            try
            {
                *(T*)data_ptr = std::move(std::any_cast<T&>(data));
            }
            catch (...)
            {
                ZSIBOT_NO_IMPL();
            }
        };

        type = []() -> ValueType
        {
            return getValueType<T>();
        };
    }

    // template <class T>
    // ObjectMem::Enum::Enum(const T*)
    // {
    //     set = [](void* data_ptr, EnumNumber num)
    //     {
    //         *(T*)(data_ptr) = T(num);
    //     };
    //
    //     get = [](void* data_ptr) -> EnumNumber
    //     {
    //         return EnumNumber(*(T*)(data_ptr));
    //     };
    //
    //     items = []() -> const EnumItemTable&
    //     {
    //         return enumerate<T>();
    //     };
    // }

    template <class T>
    ObjectMem::List::List(const std::list<T>*)
    {
        class IteratorCore : public zsibot::container::iterator::ICore<const ObjectViewMeta>
        {
            using Base          = zsibot::container::iterator::ICore<const ObjectViewMeta>;
            using This          = IteratorCore;
            using ConstIterator = typename std::list<T>::const_iterator;

        public:
            IteratorCore(ConstIterator it, ConstIterator end_it)
                : it_(std::move(it)),
                  end_it_(std::move(end_it))
            {
                data_.mem = getObjectMem<T>();
                setData();
            }

            void next() final
            {
                ++it_;
                setData();
            }

            void last() final
            {
                --it_;
                setData();
            }

            [[nodiscard]] const ObjectViewMeta& deref() const final
            {
                return data_;
            }

            bool equal(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return it_ == other->it_;
            }

            long stepCountTo(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return std::distance(it_, other->it_);
            }

            const ConstIterator& raw() const
            {
                return it_;
            }

        private:
            void setData()
            {
                if (it_ != end_it_)
                    data_.data = (void*)(&(*it_));
                else
                    data_.data = nullptr;
            }

        private:
            // 原始数据的迭代器
            ConstIterator it_, end_it_;

            // 当前指向的元视图数据
            ObjectViewMeta data_;
        };

        static auto cast = [](void* data_ptr) -> std::list<T>*
        {
            return static_cast<std::list<T>*>(data_ptr);
        };

        push_back = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->emplace_back() };
        };

        push_front = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->emplace_front() };
        };

        front = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->front() };
        };

        back = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->back() };
        };

        size = [](void* data_ptr) -> std::size_t
        {
            return cast(data_ptr)->size();
        };

        clear = [](void* data_ptr)
        {
            cast(data_ptr)->clear();
        };

        erase = [](void* data_ptr, const ConstIterator& it) -> ConstIterator
        {
            auto next_it = cast(data_ptr)->erase(it.core<IteratorCore>()->raw());

            return ConstIterator::fitCreate<IteratorCore>(next_it, cast(data_ptr)->end());
        };

        insert = [](void* data_ptr, const ConstIterator& it) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &(*cast(data_ptr)->insert(it.core<IteratorCore>()->raw(), T())) };
        };

        begin = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->begin(), cast(data_ptr)->end());
        };

        end = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->end(), cast(data_ptr)->end());
        };
    }

    template <class T>
    ObjectMem::Vector::Vector(const std::vector<T>*)
    {
        class IteratorCore : public zsibot::container::iterator::ICore<const ObjectViewMeta>
        {
            using Base          = zsibot::container::iterator::ICore<const ObjectViewMeta>;
            using This          = IteratorCore;
            using ConstIterator = typename std::vector<T>::const_iterator;

        public:
            IteratorCore(ConstIterator it, ConstIterator end_it)
                : it_(std::move(it)),
                  end_it_(std::move(end_it))
            {
                data_.mem = getObjectMem<T>();
                setData();
            }

            void move(long step) final
            {
                it_ += step;
                setData();
            }

            [[nodiscard]] const ObjectViewMeta& deref() const final
            {
                return data_;
            }

            bool equal(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return it_ == other->it_;
            }

            long stepCountTo(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return std::distance(it_, other->it_);
            }

            const ConstIterator& raw() const
            {
                return it_;
            }

        private:
            void setData()
            {
                if (it_ != end_it_)
                    data_.data = (void*)(&(*it_));
                else
                    data_.data = nullptr;
            }

        private:
            // 原始数据的迭代器
            ConstIterator it_, end_it_;

            // 当前指向的元视图数据
            ObjectViewMeta data_;
        };

        static auto cast = [](void* data_ptr) -> std::vector<T>*
        {
            return static_cast<std::vector<T>*>(data_ptr);
        };

        push_back = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->emplace_back() };
        };

        pop_back = [](void* data_ptr)
        {
            cast(data_ptr)->pop_back();
        };

        at = [](void* data_ptr, std::size_t i) -> ObjectViewMeta
        {
            if (i < cast(data_ptr)->size())
                return { getObjectMem<T>(), &cast(data_ptr)->at(i) };
            else
                return {};
        };

        resize = [](void* data_ptr, std::size_t n)
        {
            cast(data_ptr)->resize(n);
        };

        reserve = [](void* data_ptr, std::size_t n)
        {
            cast(data_ptr)->reserve(n);
        };

        size = [](void* data_ptr) -> std::size_t
        {
            return cast(data_ptr)->size();
        };

        clear = [](void* data_ptr)
        {
            cast(data_ptr)->clear();
        };

        erase = [](void* data_ptr, const ConstIterator& it) -> ConstIterator
        {
            auto next_it = cast(data_ptr)->erase(it.core<IteratorCore>()->raw());

            return ConstIterator::fitCreate<IteratorCore>(next_it, cast(data_ptr)->end());
        };

        insert = [](void* data_ptr, const ConstIterator& it) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &(*cast(data_ptr)->insert(it.core<IteratorCore>()->raw(), T())) };
        };

        begin = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->begin(), cast(data_ptr)->end());
        };

        end = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->end(), cast(data_ptr)->end());
        };
    }

    template <class T>
    ObjectMem::StrDict::StrDict(const std::map<std::string, T>*)
    {
        class IteratorCore : public zsibot::container::iterator::ICore<const Pair>
        {
            using Base          = zsibot::container::iterator::ICore<const Pair>;
            using This          = IteratorCore;
            using ConstIterator = typename std::map<std::string, T>::const_iterator;

        public:
            IteratorCore(ConstIterator it, ConstIterator end_it)
                : it_(std::move(it)),
                  end_it_(std::move(end_it))
            {
                data_.second.mem = getObjectMem<T>();
                setData();
            }

            void next() final
            {
                ++it_;
                setData();
            }

            void last() final
            {
                --it_;
                setData();
            }

            [[nodiscard]] const Pair& deref() const final
            {
                return data_;
            }

            bool equal(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return it_ == other->it_;
            }

            long stepCountTo(const Base* other_base) const final
            {
                auto other = dynamic_cast<const This*>(other_base);
                return std::distance(it_, other->it_);
            }

            const ConstIterator& raw() const
            {
                return it_;
            }

        private:
            void setData()
            {
                if (it_ != end_it_)
                {
                    data_.first       = it_->first;
                    data_.second.data = (void*)(&(it_->second));
                }
                else
                    data_.second.data = nullptr;
            }

        private:
            // 原始数据的迭代器
            ConstIterator it_, end_it_;

            // 当前的元素键值与元视图数据
            Pair data_;
        };

        static auto cast = [](void* data_ptr) -> std::map<std::string, T>*
        {
            return static_cast<std::map<std::string, T>*>(data_ptr);
        };

        size = [](void* data_ptr) -> std::size_t
        {
            return cast(data_ptr)->size();
        };

        at = [](void* data_ptr, const std::string& key, bool can_emplace) -> ObjectViewMeta
        {
            std::map<std::string, T>* ptr = cast(data_ptr);

            if (can_emplace)
                return { getObjectMem<T>(), &ptr->operator[](key) };
            else if (auto it = ptr->find(key); it != ptr->end())
                return { getObjectMem<T>(), &it->second };
            else
                return {};
        };

        insert_or_assign = [](void* data_ptr, const std::string& key) -> ConstIterator
        {
            auto new_it = cast(data_ptr)->insert_or_assign(key, T()).first;

            return ConstIterator::fitCreate<IteratorCore>(new_it, cast(data_ptr)->end());
        };

        find = [](void* data_ptr, const std::string& key) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->find(key), cast(data_ptr)->end());
        };

        clear = [](void* data_ptr)
        {
            cast(data_ptr)->clear();
        };

        erase = [](void* data_ptr, const ConstIterator& it) -> ConstIterator
        {
            auto next_it = cast(data_ptr)->erase(it.core<IteratorCore>()->raw());

            return ConstIterator::fitCreate<IteratorCore>(next_it, cast(data_ptr)->end());
        };

        erase_by_key = [](void* data_ptr, const std::string& key)
        {
            cast(data_ptr)->erase(key);
        };

        begin = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->begin(), cast(data_ptr)->end());
        };

        end = [](void* data_ptr) -> ConstIterator
        {
            return ConstIterator::fitCreate<IteratorCore>(cast(data_ptr)->end(), cast(data_ptr)->end());
        };
    }

    template <class T>
    ObjectMem::Optional::Optional(const std::optional<T>*)
    {
        static auto cast = [](void* data_ptr) -> std::optional<T>*
        {
            return static_cast<std::optional<T>*>(data_ptr);
        };

        emplace = [](void* data_ptr) -> ObjectViewMeta
        {
            return { getObjectMem<T>(), &cast(data_ptr)->emplace() };
        };

        reset = [](void* data_ptr)
        {
            cast(data_ptr)->reset();
        };

        has_value = [](void* data_ptr) -> bool
        {
            return cast(data_ptr)->has_value();
        };

        value = [](void* data_ptr) -> ObjectViewMeta
        {
            if (cast(data_ptr)->has_value())
                return { getObjectMem<T>(), &cast(data_ptr)->value() };
            else
                return {};
        };
    }
}  // namespace zsibot::binding::details

namespace zsibot::binding::details
{
    template <class T>
    const ObjectMem* getObjectMem()
    {
        static ObjectMem mem;
        static int       init_helper = []()
        {
            mem.init<T>();
            return 0;
        }();

        ZSIBOT_UNUSED(init_helper);
        return &mem;
    }
}  // namespace zsibot::binding::details
