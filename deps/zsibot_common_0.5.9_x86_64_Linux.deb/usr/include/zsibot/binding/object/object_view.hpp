#pragma once

#include <functional>
#include <variant>


#include "zsibot/binding/object/object_const_view.hpp"


namespace zsibot::binding
{
    class ObjectView;

    namespace details
    {
        /**
         * @brief 设置值对象的内容，提供给 assign 流程使用
         */
        void assignValue(ObjectView& dst, std::any data, TypeInfo type_info);

        /**
         * @brief 设置枚举对象的内容，提供给 assign 流程使用
         */
        // void assignEnum(ObjectView& dst, EnumNumber num, TypeInfo type_info, const EnumItemTable* items_ptr);
    }  // namespace details
}  // namespace zsibot::binding

namespace zsibot::binding
{
    class ObjectView : public details::TypeBase
    {
    public:
        /**
         * @brief 值类型视图
         */
        class Value : public ObjectConstView::Value
        {
            using Base = ObjectConstView::Value;

        public:
            explicit Value(const details::ObjectViewMeta& meta);

        public:
            using Base::as;
            using Base::ptr;

            /**
             * @brief 将本值视图的数据转换为给定类型，返回该数据的引用
             * @throw std::logic_error 若本值对象拥有的类型与给定类型冲突时，将抛出异常
             */
            template <class T>
            T& as()
            {
                return zsibot::utils::remove_const(Base::as<T>());
            }

            /**
             * @brief 将本值视图的数据转换为给定类型，返回该数据的指针。
             * 若本值对象拥有的类型与给定类型冲突时，将返回空指针。
             */
            template <class T>
            T* ptr()
            {
                return zsibot::utils::remove_const(Base::ptr<T>());
            }

        private:
            friend class ObjectView;

            // assign 流程使用
            friend void details::assignValue(ObjectView& dst, std::any data, details::TypeInfo type_info);
        };

    public:
        /**
         * @brief 枚举类型视图
         */
        // class Enum : public ObjectConstView::Enum
        // {
        //     using Base = ObjectConstView::Enum;
        //
        // public:
        //     explicit Enum(const details::ObjectViewMeta& meta);
        //
        // public:
        //     /**
        //      * @brief 将本视图指向的枚举变量，设置为指定的枚举值
        //      */
        //     void setNumber(EnumNumber n) final;
        //
        // public:
        //     using Base::as;
        //     using Base::ptr;
        //
        //     /**
        //      * @brief 将本枚举值视图的数据转换为给定类型，返回该数据的引用
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     E& as()
        //     {
        //         return zsibot::utils::remove_const(Base::as<E>());
        //     }
        //
        //     /**
        //      * @brief 将本枚举值视图的数据转换为给定类型，返回该数据的引用
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     E* ptr()
        //     {
        //         return zsibot::utils::remove_const(Base::ptr<E>());
        //     }
        //
        // private:
        //     friend class ObjectView;
        // };

    public:
        /**
         * @brief 链表类型视图
         */
        class List : public ObjectConstView::List
        {
            using Base         = ObjectConstView::List;
            using IteratorCore = details::SequenceViewIteratorCore<ObjectView, details::ObjectMem::List::ConstIterator>;

        public:
            using Iterator = zsibot::iterator<ObjectView>;

            explicit List(const details::ObjectViewMeta& meta);

            /**
             * @brief 添加新元素到队列末尾
             * @return 新增元素的内存视图
             */
            ObjectView pushBack();

            /**
             * @brief 添加新元素到队列开端
             * @return 新增元素的内存视图
             */
            ObjectView pushFront();

            /**
             * @return 头部元素的内存视图
             */
            ObjectView front();

            /**
             * @return 尾部元素的内存视图
             */
            ObjectView back();

            /**
             * @brief 清空所有元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增元素的内存视图
             */
            ObjectView insert(const Iterator& it);

            /**
             * @brief 在指定位置处插入新元素
             * @return 新增元素的内存视图
             */
            ObjectView insert(const ConstIterator& it);

        public:
            Iterator begin();
            Iterator end();

            using Base::back;
            using Base::begin;
            using Base::end;
            using Base::front;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for ObjectView::TList");
            }

        private:
            friend class ObjectView;
        };

        /**
         * @brief 动态数组类型视图
         */
        class Vector : public ObjectConstView::Vector
        {
            using Base         = ObjectConstView::Vector;
            using IteratorCore = details::SequenceViewIteratorCore<ObjectView, details::ObjectMem::Vector::ConstIterator>;

        public:
            using Iterator = zsibot::iterator<ObjectView>;

            explicit Vector(const details::ObjectViewMeta& meta);

            /**
             * @brief 添加新元素到队列末尾
             * @return 新增元素的内存视图
             */
            ObjectView pushBack();

            /**
             * @brief 删除最后一个元素
             */
            void popBack();

            /**
             * @return 数组里第一个元素的内存视图
             */
            ObjectView front();

            /**
             * @return 数组里最后一个元素的内存视图
             */
            ObjectView back();

            /**
             * @brief 指定索引的元素的内存视图
             */
            ObjectView operator[](std::size_t i);

            /**
             * @return 指定索引的元素的内存视图
             */
            ObjectView at(std::size_t i);

            /**
             * @brief 重置数组大小
             */
            void resize(std::size_t n);

            /**
             * @brief 预分配数组的内存
             */
            void reserve(std::size_t n);

            /**
             * @brief 清空所有元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 在指定位置处插入元素
             * @return 新增元素的内存视图
             */
            ObjectView insert(const Iterator& it);

            /**
             * @brief 在指定位置处插入元素
             * @return 新增元素的内存视图
             */
            ObjectView insert(const ConstIterator& it);

            Iterator begin();
            Iterator end();

            using Base::back;
            using Base::begin;
            using Base::end;
            using Base::front;
            using Base::operator[];
            using Base::at;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for ObjectView::TVector");
            }

            friend class ObjectView;
        };

        /**
         * @brief 字符串字典类型视图，仅支持 key 为 string 的情况
         */
        class StrDict : public ObjectConstView::StrDict
        {
            using Base         = ObjectConstView::StrDict;
            using IteratorCore = details::MapViewIteratorCore<std::string, ObjectView, details::ObjectMem::StrDict::ConstIterator>;

        public:
            using DataType = std::pair<std::string, ObjectView>;
            using Iterator = zsibot::iterator<DataType>;

            explicit StrDict(const details::ObjectViewMeta& meta);

            /**
             * @return 指定键值的元素的内存视图
             * @note 若指定键值的元素不存在时，将返回空视图
             */
            ObjectView at(const std::string& key);

            /**
             * @return 指定键值的元素的内存视图
             * @note 若指定键值不存在时，将创建新的元素
             */
            ObjectView operator[](const std::string& key);

            /**
             * @brief 查找指定键值的元素
             * @return 该元素的迭代器，若不存在该元素时，返回 end()
             */
            Iterator find(const std::string& key);

            /**
             * @brief 删除所有的元素
             */
            void clear();

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const Iterator& it);

            /**
             * @brief 删除指定位置处的元素
             */
            Iterator erase(const ConstIterator& it);

            /**
             * @brief 删除指定键值的元素
             */
            void erase(const std::string& key);

            /**
             * @brief 插入或刷新指定键值的元素
             * @return 该键值的对象迭代器
             */
            Iterator insertOrAssign(const std::string& key);

        public:
            Iterator begin();
            Iterator end();

            using Base::at;
            using Base::begin;
            using Base::end;
            using Base::find;

        private:
            template <class TCore, class TIterator>
            auto& raw(const TIterator& it)
            {
                return details::rawIterator<TCore>(it, "wrong iterator for ObjectView::TStrDict");
            }

            friend class ObjectView;
        };

        /**
         * @brief optional 类型视图
         */
        class Optional : public ObjectConstView::Optional
        {
            using Base = ObjectConstView::Optional;

        public:
            explicit Optional(const details::ObjectViewMeta& meta);

        public:
            /**
             * @brief 填充数据，将替换原有的数据
             * @return 新数据的内存视图
             */
            ObjectView emplace();

            /**
             * @brief 清空数据
             */
            void reset();

            /**
             * @return 数据的内存视图
             */
            ObjectView value();

        public:
            using Base::value;

        private:
            friend class ObjectView;
        };

        /**
         * @brief 结构类型视图
         */
        class Struct : public ObjectConstView::Struct
        {
            using Base = ObjectConstView::Struct;

        public:
            using DataType = std::pair<std::string, ObjectView>;
            using Iterator = zsibot::iterator<DataType>;

        private:
            // 迭代核心
            using IteratorCore = details::MapViewIteratorCore<std::string, ObjectView, details::ObjectMem::Struct::ConstIterator>;

        public:
            explicit Struct(const details::ObjectViewMeta& meta);

            /**
             * @return 指定字段的内存视图
             * @note 若指定的字段不存在时，将返回空视图
             */
            ObjectView get(const std::string& field_name);

            /**
             * @brief 查找指定名称的字段
             * @return 该字段的迭代器，若没有找到，将返回 end()
             */
            Iterator find(const std::string& field_name);

            Iterator begin();
            Iterator end();

            using Base::begin;
            using Base::end;
            using Base::find;
            using Base::get;

        private:
            friend class ObjectView;
        };

        ObjectView() = default;

        /**
         * @return 拥有的数据视图类型
         */
        [[nodiscard]] ObjectType type() const;

        [[nodiscard]] bool isUndefined() const;

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                          \
    bool is##_type_() const;                                                                                                               \
                                                                                                                                           \
    _type_& as##_type_();                                                                                                                  \
                                                                                                                                           \
    const _type_& as##_type_() const;

        ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

    public:
        /**
         * @brief 绑定给定对象的内存视图
         */
        template <class T>
        void bind(T& x)
        {
            //  创建内存结构信息
            details::ObjectViewMeta meta;
            meta.mem  = details::getObjectMem<T>();
            meta.data = &x;

            setTypeInfo(meta.mem->info());

            // 设置内存结构数据
            if constexpr (details::isValue<T>())
            {
                data_.emplace<Value>(meta);
            }
            // else if constexpr (std::is_enum_v<T>)
            // {
            //     data_.emplace<Enum>(meta);
            // }
            else
            {
                data_.emplace<Struct>(meta);
            }
        }

#define ZSIBOT_DETAILS_IMPL(_container_type_)                                                                                                \
    template <class T>                                                                                                                     \
    void bind(::zsibot::binding::def::_container_type_<T>& x)                                                                                \
    {                                                                                                                                      \
        details::ObjectViewMeta meta;                                                                                                      \
        meta.mem  = details::getObjectMem<T>();                                                                                            \
        meta.data = &x;                                                                                                                    \
                                                                                                                                           \
        setTypeInfo(meta.mem->info());                                                                                                     \
                                                                                                                                           \
        data_.emplace<_container_type_>(meta);                                                                                             \
    }

        ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 去除对已有的内存视图绑定
         */
        void reset();

        /**
         * @brief 将本对象转换为 const 的视图对象
         */
        [[nodiscard]] ObjectConstView toConst() const;

    private:
        ObjectView(const details::ObjectViewMeta& meta);

        template <class TView, class TMemIt>
        friend class details::SequenceViewIteratorCore;

        template <class TKey, class TView, class TMemIt>
        friend class details::MapViewIteratorCore;

    private:
        // 绑定了真实对象的视图数据
#define ZSIBOT_DETAILS_IMPL(_type_) , _type_
        std::variant<std::nullptr_t ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)> data_ = nullptr;
#undef ZSIBOT_DETAILS_IMPL
    };
}  // namespace zsibot::binding
