#pragma once

#include "zsibot/binding/object/type_base.hpp"
#include "zsibot/string_hash.h"

namespace zsibot::binding::details
{
    /**
     * @brief value base
     */
    class ValueBase : public TypeBase
    {
    protected:
        ValueBase() = default;

        ValueBase(const TypeInfo& info, ValueType type)
            : TypeBase(info),
              type_(type)
        {
        }

    public:
        [[nodiscard]] ValueType type() const
        {
            return type_;
        }

    protected:
        void setValueType(ValueType type)
        {
            type_ = type;
        }

    private:
        ValueType type_ = ValueType::Undefined;
    };
}  // namespace zsibot::binding::details

// 注册内置值类型
#define ZSIBOT_DETAILS_BINDING_INTERNAL_VALUE(_type_)                                                                                        \
    ZSIBOT_DETAILS_BINDING_REGISTER_TYPE_INFO(_type_)                                                                                        \
    ZSIBOT_DETAILS_BINDING_IMPL_IS_VALUE(_type_)

ZSIBOT_BINDING_INSTANTIATES_VALUE_TYPE(ZSIBOT_DETAILS_BINDING_INTERNAL_VALUE)
