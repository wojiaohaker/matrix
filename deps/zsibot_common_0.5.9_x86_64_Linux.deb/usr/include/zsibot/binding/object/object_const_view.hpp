#pragma once

#include <functional>
#include <variant>

#include "zsibot/container/iterator/view_iterator.hpp"
#include "zsibot/binding/object/object_mem.hpp"
#include "zsibot/binding/object/value_base.hpp"
#include "zsibot/utils.hpp"


namespace zsibot::binding
{
    namespace details
    {
        template <class TView, class TMemIt>
        class SequenceViewIteratorCore;

        template <class TKey, class TView, class TMemIt>
        class MapViewIteratorCore;
    }  // namespace details

    class ObjectView;

    class ObjectConstView : public details::TypeBase
    {
    public:
        /**
         * @brief 值类型视图
         */
        class Value : public details::ValueBase
        {
        public:
            explicit Value(const details::ObjectViewMeta& meta);

        public:
            /**
             * @brief 将本值视图的数据转换为给定类型，返回该数据的引用
             * @throw std::logic_error 若本值对象拥有的类型与给定类型冲突时，将抛出异常
             */
            template <class T>
            const T& as() const
            {
                static_assert(details::isValue<T>());

                if (not is<T>())
                    throw std::logic_error("wrong type");

                return *static_cast<const T*>(meta_.data);
            }

            /**
             * @brief 将本值视图的数据转换为给定类型，返回该数据的指针。
             * 若本值对象拥有的类型与给定类型冲突时，将返回空指针。
             */
            template <class T>
            const T* ptr() const
            {
                static_assert(details::isValue<T>());

                if (not is<T>())
                    return nullptr;
                else
                    return (const T*)meta_.data;
            }

            /**
             * @return 拷贝真实数据，放置到 std::any 中返回
             */
            [[nodiscard]] std::any getAny() const;

        protected:
            details::ObjectViewMeta meta_;
        };

        // /**
        //  * @brief 枚举类型视图
        //  */
        // class Enum : public details::EnumBase
        // {
        // public:
        //     explicit Enum(const details::ObjectViewMeta& meta);
        //
        // public:
        //     /**
        //      * @return 本视图指向的枚举变量的枚举值
        //      */
        //     [[nodiscard]] EnumNumber number() const final;
        //
        // private:
        //     void setNumber(EnumNumber) override
        //     {
        //         EON_UNREACHABLE_CODE();
        //     }
        //
        // public:
        //     /**
        //      * @brief 将本枚举值视图的数据转换为给定类型，返回该数据的引用
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     const E& as() const
        //     {
        //         static_assert(std::is_enum_v<E>);
        //
        //         if (not is<E>())
        //             throw std::logic_error("wrong type");
        //
        //         return *(const E*)(meta_.data);
        //     }
        //
        //     /**
        //      * @brief 将本枚举值视图的数据转换为给定类型，返回该数据的引用
        //      * @throw std::logic_error 若本枚举值对象拥有的类型与给定类型冲突时，将抛出异常
        //      */
        //     template <class E>
        //     const E* ptr() const
        //     {
        //         static_assert(std::is_enum_v<E>);
        //
        //         if (not is<E>())
        //             return nullptr;
        //         else
        //             return (const E*)meta_.data;
        //     }
        //
        // protected:
        //     details::ObjectViewMeta meta_;
        // };

    public:
        /**
         * @brief  链表型视图
         */
        class List
        {
        protected:
            using ConstIteratorCore = details::SequenceViewIteratorCore<ObjectConstView, details::ObjectMem::List::ConstIterator>;

        public:
            using ConstIterator = zsibot::iterator<ObjectConstView>;

        public:
            explicit List(const details::ObjectViewMeta& meta);

        public:
            /**
             * @return 头部元素的内存视图
             */
            [[nodiscard]] ObjectConstView front() const;

            /**
             * @return 尾部元素的内存视图
             */
            [[nodiscard]] ObjectConstView back() const;

            /**
             * @return 元素的个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 链表是否为空
             */
            [[nodiscard]] bool empty() const;

        public:
            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        protected:
            details::ObjectViewMeta meta_;
        };

    public:
        /**
         * @brief 动态数组类型视图
         */
        class Vector
        {
        protected:
            using ConstIteratorCore = details::SequenceViewIteratorCore<ObjectConstView, details::ObjectMem::Vector::ConstIterator>;

        public:
            using ConstIterator = zsibot::iterator<ObjectConstView>;

        public:
            explicit Vector(const details::ObjectViewMeta& meta);

        public:
            /**
             * @return 数组里第一个元素的内存视图
             */
            [[nodiscard]] ObjectConstView front() const;

            /**
             * @return 数组里最后一个元素的内存视图
             */
            [[nodiscard]] ObjectConstView back() const;

            /**
             * @brief 指定索引的元素的内存视图
             */
            [[nodiscard]] ObjectConstView operator[](std::size_t i) const;

            /**
             * @return 指定索引的元素的内存视图
             */
            [[nodiscard]] ObjectConstView at(std::size_t i) const;

            /**
             * @return 元素的个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 数组是否为空
             */
            [[nodiscard]] bool empty() const;

        public:
            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        protected:
            details::ObjectViewMeta meta_;
        };

    public:
        /**
         * @brief 字符串字典类型视图，仅支持 key 为 string 的情况
         */
        class StrDict
        {
        protected:
            using ConstIteratorCore =
                details::MapViewIteratorCore<std::string, ObjectConstView, details::ObjectMem::StrDict::ConstIterator>;

        public:
            using ConstDataType = std::pair<std::string, ObjectConstView>;
            using ConstIterator = zsibot::iterator<ConstDataType>;

        public:
            explicit StrDict(const details::ObjectViewMeta& meta);

        public:
            /**
             * @return 元素个数
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 字典是否为空
             */
            [[nodiscard]] bool empty() const;

            /**
             * @return 指定键值的元素的内存视图
             * @note 若指定键值的元素不存在时，将返回空视图
             */
            [[nodiscard]] ObjectConstView at(const std::string& key) const;

            /**
             * @brief 查找指定键值的元素
             * @return 该元素的迭代器，若不存在该元素时，返回 end()
             */
            [[nodiscard]] ConstIterator find(const std::string& key) const;

        public:
            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        protected:
            details::ObjectViewMeta meta_;
        };

    public:
        /**
         * @brief optional 类型视图
         */
        class Optional
        {
        public:
            explicit Optional(const details::ObjectViewMeta& meta);

        public:
            /**
             * @return 是否存在有效数据
             */
            [[nodiscard]] bool has_value() const;

            /**
             * @return 数据的内存视图
             */
            [[nodiscard]] ObjectConstView value() const;

        protected:
            details::ObjectViewMeta meta_;
        };

    public:
        /**
         * @brief 结构类型视图
         */
        class Struct
        {
        protected:
            using ConstIteratorCore = details::MapViewIteratorCore<std::string, ObjectConstView, details::ObjectMem::Struct::ConstIterator>;

        public:
            using ConstDataType = std::pair<std::string, ObjectConstView>;
            using ConstIterator = zsibot::iterator<ConstDataType>;

        public:
            explicit Struct(const details::ObjectViewMeta& meta);

        public:
            /**
             * @return 指定字段的内存视图
             * @note 若指定的字段不存在时，将返回空视图
             */
            [[nodiscard]] ObjectConstView get(const std::string& field_name) const;

            /**
             * @brief 查找指定名称的字段
             * @return 该字段的迭代器，若没有找到，将返回 end()
             */
            [[nodiscard]] ConstIterator find(const std::string& field_name) const;

            /**
             * @return 字段的数量
             */
            [[nodiscard]] std::size_t size() const;

            /**
             * @return 字段是否为空
             */
            [[nodiscard]] bool empty() const;

        public:
            [[nodiscard]] ConstIterator begin() const;

            [[nodiscard]] ConstIterator end() const;

        protected:
            details::ObjectViewMeta meta_;
        };

    public:
        ObjectConstView() = default;

    public:
        /**
         * @return 拥有的数据视图类型
         */
        [[nodiscard]] ObjectType type() const;

        [[nodiscard]] bool isUndefined() const;

#define ZSIBOT_DETAILS_IMPL(_type_)                                                                                                           \
    bool is##_type_() const;                                                                                                               \
                                                                                                                                           \
    _type_& as##_type_();                                                                                                                  \
                                                                                                                                           \
    const _type_& as##_type_() const;

        ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 绑定给定对象的内存视图
         */
        template <class T>
        void bind(const T& x)
        {
            //  创建内存结构信息
            details::ObjectViewMeta meta;
            meta.mem  = details::getObjectMem<T>();
            meta.data = utils::remove_const(&x);

            setTypeInfo(meta.mem->info());

            // 设置内存结构数据
            if constexpr (details::isValue<T>())
            {
                data_.emplace<Value>(meta);
            }
            // else if constexpr (std::is_enum_v<T>)
            // {
            //     data_.emplace<Enum>(meta);
            // }
            else
            {
                data_.emplace<Struct>(meta);
            }
        }

#define ZSIBOT_DETAILS_IMPL(_container_type_)                                                                                                \
    template <class T>                                                                                                                     \
    void bind(const ::zsibot::binding::details::_container_type_<T>& x)                                                                      \
    {                                                                                                                                      \
        details::ObjectViewMeta meta;                                                                                                      \
        meta.mem  = details::getObjectMem<T>();                                                                                            \
        meta.data = &x;                                                                                                                    \
                                                                                                                                           \
        setTypeInfo(meta.mem->info());                                                                                                     \
                                                                                                                                           \
        data_.emplace<_container_type_>(meta);                                                                                             \
    }

        ZSIBOT_DETAILS_BINDING_INSTANTIATES_CONTAINER_TYPE(ZSIBOT_DETAILS_IMPL)
#undef ZSIBOT_DETAILS_IMPL

        /**
         * @brief 去除对已有的内存视图绑定
         */
        void reset();

    private:
        ObjectConstView(const details::ObjectViewMeta& meta);

        friend class ObjectView;

        template <class TView, class TMemIt>
        friend class details::SequenceViewIteratorCore;

        template <class TKey, class TView, class TMemIt>
        friend class details::MapViewIteratorCore;

    private:
        // 绑定了真实对象的视图数据
#define ZSIBOT_DETAILS_IMPL(_type_) , _type_
        std::variant<std::nullptr_t ZSIBOT_BINDING_INSTANTIATES_OBJECT_TYPE(ZSIBOT_DETAILS_IMPL)> data_ = nullptr;
#undef ZSIBOT_DETAILS_IMPL
    };
}  // namespace zsibot::binding