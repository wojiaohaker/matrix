#pragma once

#include "zsibot/binding/object.hpp"

namespace zsibot::binding
{
    /**
     * @brief 创建者抽象基类
     */
    class ICreator
    {
    public:
        /**
         * @brief 下一个防需要创建的对象
         * @return 返回下一个需要创建的对象
         */
        virtual ObjectType next() = 0;

        /**
         * @brief 下一个待创建的对象类型为动态数组，可指定将要使用的
         * 元素个数，用于预分配内存。
         * @return 用于内存预分配的元素个数
         */
        virtual std::size_t nextVectorSize()
        {
            return 0;
        }

        /**
         * @brief 是否追加新的链表元素
         */
        virtual bool nextListItem(std::size_t current_size) = 0;

        /**
         * @brief 是否追加新的动态数组元素
         */
        virtual bool nextVectorItem(std::size_t current_size) = 0;

        /**
         * @brief 下一个字符串字典型数据的元素键值，若没有下一个元素，则为空
         */
        virtual std::optional<std::string> nextStrDictItem(std::size_t current_size) = 0;

        /**
         * @brief 是否为 optional 型数据创建值
         */
        virtual bool nextOptionalItem() = 0;

        /**
         * @brief 闭环 optional 值对象的创建，仅在 optional 存在值时、且在
         * 该值创建完毕后被调用
         */
        virtual void closeOptionalItem() = 0;

        /**
         * @brief 下一个字段的名称，若没有下一个字段，则为空
         */
        virtual std::optional<std::string> nextStructItem(std::size_t current_size) = 0;

        /**
         * @brief 初始化值类型对象
         */
        virtual void initValue(Object::Value& dst) = 0;

        /**
         * @brief 初始化枚举值类型对象
         */
        // virtual void initEnum(Object::Enum& dst) = 0;

    public:
        /**
         * @brief 默认虚虚构函数
         */
        virtual ~ICreator() = default;
    };

    /**
     * @brief 使用访问器的方式，构造一个对象
     */
    Object create(ICreator& creator);

    /**
     * @brief 使用访问器的方式，构造一个对象
     */
    Object create(ICreator&& creator);
}  // namespace zsibot::binding
