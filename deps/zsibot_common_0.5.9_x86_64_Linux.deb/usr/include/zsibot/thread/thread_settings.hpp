//
// Created by kanonwy on 2024/11/11
//

#pragma once

#include <cstdint>
#include <limits>

namespace zsibot
{


    /**
     * @brief 线程调度策略
     * @note ps -cT -p $(pidof programe_name)
     *       htop -p $(pidof progame_name)
     * @details doc:
     * https://docs.redhat.com/en/documentation/red_hat_enterprise_linux_for_real_time/9/html/understanding_rhel_for_real_time/assembly_scheduling-policies-for-rhel-for-real-time_understanding-rhel-for-real-time-core-concepts#assembly_scheduling-policies-for-rhel-for-real-time_understanding-RHEL-for-Real-Time-core-concepts
     *    1. -20 最高优先级，19 最低优先级，默认为 0. 范围为 40
     *  优先级   <---------------------------
     *  range   -20         0          19
     *  htop    0    10     20   30    39
     *  ps      39   29     19    9     0
     *  api    -20  -10     0   10     20
     *  设置 api 小于 0 则需要使用 sudo 才能运行
     *
     *    2. SCHED_FIFO uses a fixed priority between 1, which is the lowest and 99, which is the highest. A SCHED_FIFO thread with a
     * priority of 1 always schedules first over a SCHED_OTHER thread.
     *    3. The SCHED_RR policy is similar to the SCHED_FIFO policy. The threads of equal priority are scheduled in a round-robin fashion
     *    SCHED_FIFO and SCHED_RR threads run until one of the following events occurs
     *    (1) The thread goes to sleep or waits for an event.
     *    (2) A higher-priority real-time thread gets ready to run
     *
     *     range 1  -> 99
     *
     */
    enum class ThreadSchedPolicy : int
    {
        JS_SCHED_OTHER    = 0,  ///<<< NORMAL
        JS_SCHED_FIFO     = 1,  ///<<< FIFO
        JS_SCHED_RR       = 2,  ///<<< RR
        JS_SCHED_BATCH    = 3,
        JS_SCHED_ISO      = 4,
        JS_SCHED_IDLE     = 5,
        JS_SCHED_DEADLINE = 6,
    };

    /**
     * @brief 线程配置
     * @todo 根据普通线程和实时线程设置不同的检查规则
     */
    struct ThreadSettings
    {
        ThreadSchedPolicy scheduling_policy = ThreadSchedPolicy::JS_SCHED_OTHER;    ///<<< 调度策略
        int32_t           priority          = std::numeric_limits<int32_t>::min();  ///<<< 调度优先级
        uint64_t          affinity          = 0;                                    ///<<< 线程亲和性
        int32_t           stack_size        = -1;                                   ///<<< 线程栈大小

        /**
         * @brief 重载比较
         * @param rhs
         * @return
         */
        bool operator==(const ThreadSettings& rhs) const;

        /**
         * @brief 重载比较
         * @param rhs
         * @return
         */
        bool operator!=(const ThreadSettings& rhs) const;

        /**
         * @brief 设置线程的亲和性
         * @param affinity 将 affinity 转为二进制后从低位到高位决定绑定 CPU 核心数
         * @return
         * @details 设置亲性无需 root 权限
         * 查看制定进程的亲核性:\n
         *  taskset  -a -p $(pidof program_name)
         */
        ThreadSettings& set_affinity(uint64_t affinity)
        {
            this->affinity = affinity;
            return *this;
        }

        /**
         * @brief 设置线程调度策略
         * @param policy
         * @return
         */
        ThreadSettings& set_scheduling_policy(zsibot::ThreadSchedPolicy policy)
        {
            this->scheduling_policy = policy;
            return *this;
        }

        /**
         * @brief 设置线程的优先级
         * @param priority
         * @return
         * @details 入参详细描述
         *  - SCHED_OTHER:         [-20, 20]  -20 优先级最高，但是设置负数程序则需要使用 root，也即提升优先级别需要 root
         * 权限，及时失败也只会保存原来
         *  - SCHED_RR/SCHED_FIFO: [1,99]
         */
        ThreadSettings& set_priority(int32_t priority)
        {
            this->priority = priority;
            return *this;
        }
    };
}  // namespace zsibot
