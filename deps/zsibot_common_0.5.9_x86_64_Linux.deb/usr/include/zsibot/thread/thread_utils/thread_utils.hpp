//
// Created by kanonwy on 2024/11/11
//

#pragma once

#include <cstdint>
#include <optional>
#include <pthread.h>

namespace zsibot::thread_utils
{
    /**
     * @brief 获取指定线程 id 的 CPU 亲和性
     * @param tid
     */
    std::optional<cpu_set_t> get_thread_affinity(pthread_t tid);

    /**
     * @brief 设置指定线程 id 的 CPU 亲和性
     * @param tid
     * @param affinity_mask
     */
    bool set_thread_affinity(pthread_t tid, uint64_t affinity_mask);


}  // namespace zsibot::thread_utils
