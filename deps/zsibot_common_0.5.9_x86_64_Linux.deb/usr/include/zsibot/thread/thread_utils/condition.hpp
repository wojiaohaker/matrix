#pragma once

#include <condition_variable>
#include <functional>
#include <mutex>

#include <zsibot/unit/time.hpp>


/**
 * @brief eon 线程池条件变量等同步组件封装所在的命名空间
 */
namespace zsibot::thread_utils
{
    /**
     * @brief 线程条件类，对 mutex 与 condition_variable 的方便封装
     */
    class Condition
    {
    public:
        Condition(bool value = false);  // NOLINT(google-explicit-constructor)

        /**
         * @brief 析构时，将调用 fail() 函数，使其他正在等待条件变换的线程退出等待。
         */
        ~Condition();

        /**
         * @brief 设置当前条件的值；但是，即使设置为 true，也不会释放其它正在等待条件满足的线程。
         * @param value
         */
        void init(bool value = false);

        /**
         * @brief 等待条件成立。
         * @return 条件是否被满足；返回 false 只有一种可能：条件被标识为永远无法被满足（也即调用了 fail() 函数）。
         */
        bool wait() const;

        /**
         * @brief 在指定时间内，等待条件成立。
         * @param time
         * @return 返回超时之后，条件是否成立
         */
        bool wait(const zsibot::unit::Time& time) const;

        /**
         * @brief 批等待，用于将短期内一批条件成立事件一起消化。
         * @param batch_time
         * @return 条件是否被满足。
         */
        bool batchWait(const zsibot::unit::Time& batch_time) const;

        /**
         * @brief 在有限时间内，进行批等待。
         * @param batch_time
         * @param timeout
         * @return 条件是否被满足。
         */
        bool batchWait(const zsibot::unit::Time& batch_time, const zsibot::unit::Time& timeout) const;

        /**
         * @brief 使条件满足，将释放所有正在等待条件满足的线程。
         */
        void satisfy();

        /**
         * @brief 标识条件永远无法被满足，将释放所有正在等待条件满足的线程，并使他们返回 false.
         */
        void fail();

        /**
         * @return 本条件的值
         */
        operator bool() const;  // NOLINT(google-explicit-constructor)

    private:
        /**
         * @brief 在给定时间内，消化所有成立条件
         * @return 条件是否成立。
         */
        bool batchWaiting(const zsibot::unit::Time& time) const;

    private:
        mutable std::condition_variable condition_;
        mutable std::mutex              mutex_;
        bool                            value_  = false;  ///< 标识本条件的成立状态
        bool                            failed_ = false;  ///< 标识本条件是否无法被满足
    };
}  // namespace zsibot::thread_utils
