//
// Created by kanonwy on 2024/11/11
//

#pragma once

#include <pthread.h>
#include <stdexcept>
#include <system_error>
#include <thread>

namespace zsibot
{
    /**
     * @brief jszr support sched and prio
     */
    class thread
    {
    public:
        using native_handle_type = pthread_t;         ///<<< 原生线程处理句柄
        using id                 = pthread_t;         ///<<< 线程 id 类型
        using start_routine_type = void* (*)(void*);  ///<<< 默认线程处理函数类型

    private:
        /**
         * @brief static thread proxy class which call thread function.
         */
        template <typename CalleeType>
        static void* ThreadProxy(void* Ptr)
        {
            std::unique_ptr<CalleeType> Callee(static_cast<CalleeType*>(Ptr));
            (*Callee)();
            return nullptr;
        }

    public:
        thread()
            : thread_hnd_(native_handle_type())
        {
        }

        /**
         * @brief  线程构造函数，支持传入 stack_size
         * @tparam _Fn
         * @param stack_size
         * @param f
         */
        template <class _Fn>
        thread(int32_t stack_size, _Fn&& f)
        {
            using CalleeType = typename std::decay<_Fn>::type;
            std::unique_ptr<CalleeType> callee(new CalleeType(std::forward<_Fn>(f)));
            thread_hnd_ = start_thread_impl(stack_size, ThreadProxy<CalleeType>, callee.get());
            if (thread_hnd_ != native_handle_type())
            {
                callee.release();
            }
        }

        ~thread()
        {
            if (joinable())
            {
                std::terminate();
            }
        }

        /**
         * @brief 线程禁止拷贝
         */
        thread(const thread&) = delete;
        /**
         * @brief 线程禁止拷贝
         */
        thread& operator=(const thread&) = delete;

        /**
         * @brief 线程只移动
         */
        thread(thread&& other) noexcept
            : thread_hnd_(native_handle_type())
        {
            swap(other);
        }

        /**
         * @brief 线程只移动
         */
        thread& operator=(thread&& other) noexcept
        {
            if (joinable())
            {
                std::terminate();
            }
            thread_hnd_ = native_handle_type();
            swap(other);
            return *this;
        }

        /**
         * @brief 线程交换
         */
        void swap(thread& other) noexcept
        {
            std::swap(thread_hnd_, other.thread_hnd_);
        }

        /**
         * @brief 线程可汇入
         */
        inline bool joinable() const noexcept
        {
            return thread_hnd_ != native_handle_type();
        }

        /**
         * @brief 线程 id
         */
        inline id get_id() const noexcept
        {
            return get_thread_id_impl(thread_hnd_);
        }

        /**
         * @brief 线程原生句柄
         * @return
         */
        inline native_handle_type native_handle() const noexcept
        {
            return thread_hnd_;
        }

        /**
         * @brief 线程并发能力
         * @return
         */
        static unsigned hardware_concurrency()
        {
            return std::thread::hardware_concurrency();
        }

        /**
         * @brief 线程汇入
         */
        inline void join()
        {
            if (!joinable())
            {
                throw std::system_error(std::make_error_code(std::errc::invalid_argument));
            }

            if (is_calling_thread())
            {
                throw std::system_error(std::make_error_code(std::errc::resource_deadlock_would_occur));
            }

            join_thread_impl(thread_hnd_);
            thread_hnd_ = native_handle_type();
        }

        /**
         * @brief 线程分离
         */
        inline void detach()
        {
            detach_thread_impl(thread_hnd_);
            thread_hnd_ = native_handle_type();
        }

        /**
         * @brief 是否当前线程
         * @return
         */
        [[nodiscard]] inline bool is_calling_thread() const noexcept
        {
            return get_id() == get_current_thread_id_impl();
        }


    private:
        native_handle_type thread_hnd_;  ///<<< 线程原始句柄

        static native_handle_type start_thread_impl(int32_t stack_size, start_routine_type start, void* arg);
        static id                 get_thread_id_impl(native_handle_type hnd);
        static void               join_thread_impl(native_handle_type hnd);
        static void               detach_thread_impl(native_handle_type hnd);
        static id                 get_current_thread_id_impl();
    };

}  // namespace zsibot


namespace zsibot
{
    inline thread::native_handle_type thread::start_thread_impl(int32_t stack_size, thread::start_routine_type start, void* arg)
    {
        int err_num;

        // Construct the attributes object.
        pthread_attr_t attr;
        if ((err_num = ::pthread_attr_init(&attr)) != 0)
        {
            throw std::system_error(err_num, std::system_category(), "pthread_attr_init failed");
        }

        // Ensure the attributes object is destroyed
        auto attr_deleter = [](pthread_attr_t* a)
        {
            int err;
            if ((err = ::pthread_attr_destroy(a)) != 0)
            {
                throw std::system_error(err, std::system_category(), "pthread_attr_destroy failed");
            }
        };
        std::unique_ptr<pthread_attr_t, decltype(attr_deleter)> attr_scope_destroy(&attr, attr_deleter);

        // Set the requested stack size, if given.
        if (stack_size >= 0)
        {
            if (sizeof(unsigned) <= sizeof(int32_t) && stack_size > static_cast<int32_t>(std::numeric_limits<unsigned>::max() / 2))
            {
                throw std::invalid_argument("Cannot cast stack_size into unsigned");
            }

            if ((err_num = ::pthread_attr_setstacksize(&attr, stack_size)) != 0)
            {
                throw std::system_error(err_num, std::system_category(), "pthread_attr_setstacksize failed");
            }
        }

        // Construct and execute the thread.
        pthread_t hnd;
        if ((err_num = ::pthread_create(&hnd, &attr, start, arg)) != 0)
        {
            throw std::system_error(err_num, std::system_category(), "pthread_create failed");
        }

        return hnd;
    }

    inline thread::id thread::get_thread_id_impl(thread::native_handle_type hnd)
    {
        return hnd;
    }

    inline void thread::join_thread_impl(thread::native_handle_type hnd)
    {
        int err_num;
        if ((err_num = ::pthread_join(hnd, nullptr)) != 0)
        {
            throw std::system_error(std::make_error_code(std::errc::no_such_process), "pthread_join failed");
        }
    }

    inline void thread::detach_thread_impl(thread::native_handle_type hnd)
    {

        if (int err_num; (err_num = ::pthread_detach(hnd)) != 0)
        {
            throw std::system_error(err_num, std::system_category(), "pthread_detach failed");
        }
    }

    inline thread::id thread::get_current_thread_id_impl()
    {
        return ::pthread_self();
    }
}  // namespace jszr
