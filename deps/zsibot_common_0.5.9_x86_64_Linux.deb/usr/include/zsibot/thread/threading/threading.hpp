//
// Created by kanonwy on 2024/11/11
//

#pragma once

#include <array>
#include <iostream>
#include <unistd.h>

#include "zsibot/thread/thread_impl/thread_impl.hpp"
#include "zsibot/thread/thread_settings.hpp"

#include <functional>

namespace zsibot
{
    struct ThreadSettings;

    /**
     * @brief set current thread name
     */
    void set_name_to_current_thread(std::array<char, 16>& thread_name_buffer, const char* name);

    /**
     * @brief set current thread name
     * @param thread_name_buffer
     * @param fmt
     * @param arg
     */
    void set_name_to_current_thread(std::array<char, 16>& thread_name_buffer, const char* fmt, uint32_t arg);

    /**
     * @brief set current thread name
     * @param thread_name_buffer
     * @param fmt
     * @param arg1
     * @param arg2
     */
    void set_name_to_current_thread(std::array<char, 16>& thread_name_buffer, const char* fmt, uint32_t arg1, uint32_t arg2);

    /**
     * @brief apply thread setting to current thread.
     */
    void apply_thread_settings_to_current_thread(const char* thread_name, const zsibot::ThreadSettings& settings);

    /**
     * @brief get current thread name
     * @return name of thread which has 16 char.
     */
    std::string get_current_thread_name();

    /**
     * @brief get current thread affinity
     * @return
     */
    cpu_set_t get_current_thread_affinity();


    /**
     * @brief create thread
     */
    template <typename Functor, typename... Args>
    zsibot::thread create_thread(Functor func, const zsibot::ThreadSettings& settings, const char* name, Args... args)
    {
        return zsibot::thread(settings.stack_size,
            [=]()
            {
                std::array<char, 16> thread_name_buffer{};
                set_name_to_current_thread(thread_name_buffer, name, args...);
                apply_thread_settings_to_current_thread(thread_name_buffer.data(), settings);
                std::cout << "[JSZR THREAD] => Pid       = " << getpid() << std::endl;
                std::cout << "[JSZR THREAD] => Thread id = " << pthread_self() << std::endl;
                func();
            });
    }

    /**
     * @brief 使用线程配置构建一个命名的线程（Linux Only）
     * @tparam Functor 函数类型
     * @tparam Args 格式化名称的闭包
     * @param func 函数（包括闭包，全局函数，成员函数）
     * @param settings 线程的配置
     * @param name 线程的名称
     * @param args 格式化线程名称的参数
     * @return
     */
    template <typename Functor, typename... Args>
    zsibot::thread build_thread(Functor func, const zsibot::ThreadSettings& settings, const char* name, Args... args)
    {
        return zsibot::thread(settings.stack_size,
            [=]()
            {
                std::array<char, 16> thread_name_buffer{};
                set_name_to_current_thread(thread_name_buffer, name, args...);
                apply_thread_settings_to_current_thread(thread_name_buffer.data(), settings);
                std::invoke(func);
            });
    }


}  // namespace zsibot
