#pragma once

#include <memory>
#include <type_traits>

#include "zsibot/utils/is.hpp"


namespace zsibot::vartype_dict
{

    template <typename T>
    struct Identity_
    {
        using type = T;
    };

    template <bool cur, typename TNext>
    constexpr static bool OrValue = true;

    template <typename TNext>
    constexpr static bool OrValue<false, TNext> = TNext::value;

    template <bool cur, typename TNext>
    constexpr static bool AndValue = false;

    template <typename TNext>
    constexpr static bool AndValue<true, TNext> = TNext::value;

    template <typename TArray>
    struct IsArrayEmpty_;

    template <template <typename...> class Cont, typename T1, typename... T2>
    struct IsArrayEmpty_<Cont<T1, T2...>>
    {
        constexpr static bool value = false;
    };

    template <template <typename...> class Cont>
    struct IsArrayEmpty_<Cont<>>
    {
        constexpr static bool value = true;
    };

    template <typename TArray>
    constexpr static bool IsArrayEmpty = IsArrayEmpty_<TArray>::value;

    template <typename TArray>
    struct ArraySize_;

    template <template <typename...> class Cont, typename... T>
    struct ArraySize_<Cont<T...>>
    {
        constexpr static size_t value = sizeof...(T);
    };

    template <typename TArray>
    constexpr static size_t ArraySize = ArraySize_<TArray>::value;

    template <typename TSeqCont>
    struct SeqHead_;

    template <template <typename...> class Container, typename TH, typename... TCases>
    struct SeqHead_<Container<TH, TCases...>>
    {
        using type = TH;
    };

    template <typename TSeqCont>
    using SeqHead = typename SeqHead_<TSeqCont>::type;

    template <typename TSeqCont>
    struct SeqTail_;

    template <template <typename...> class Container, typename TH, typename... TCases>
    struct SeqTail_<Container<TH, TCases...>>
    {
        using type = Container<TCases...>;
    };

    template <typename TSeqCont>
    using SeqTail = typename SeqTail_<TSeqCont>::type;

    template <typename T>
    constexpr static bool DependencyFalse = false;

    template <typename T>
    using RemConstRef = std::remove_cv_t<std::remove_reference_t<T>>;

    struct NullParameter
    {
    };


    template <typename TFindTag, size_t N, typename TCurTag, typename... TTags>
    struct Tag2ID_
    {
        constexpr static size_t value = Tag2ID_<TFindTag, N + 1, TTags...>::value;
    };

    template <typename TFindTag, size_t N, typename... TTags>
    struct Tag2ID_<TFindTag, N, TFindTag, TTags...>
    {
        constexpr static size_t value = N;
    };


    template <typename TFindTag, typename... TTags>
    constexpr size_t Tag2ID = Tag2ID_<TFindTag, 0, TTags...>::value;


    template <typename TVal, size_t N, size_t M, typename TProcessedTypes, typename... TRemainTypes>
    struct NewTupleType_;


    template <typename TVal, size_t N, size_t M, template <typename...> class TCont, typename... TModifiedType, typename TCurType,
        typename... TRemainTypes>
    struct NewTupleType_<TVal, N, M, TCont<TModifiedType...>, TCurType, TRemainTypes...>
    {
        using type = typename NewTupleType_<TVal, N, M + 1, TCont<TModifiedType..., TCurType>, TRemainTypes...>::type;
    };

    template <typename TVal, size_t N, template <typename...> class TCont, typename... TModifiedTypes, typename TCurType,
        typename... TRemainTypes>
    struct NewTupleType_<TVal, N, N, TCont<TModifiedTypes...>, TCurType, TRemainTypes...>
    {
        using type = TCont<TModifiedTypes..., TVal, TRemainTypes...>;
    };


    template <typename TVal, size_t TagPos, typename TCont, typename... TRemainTypes>
    using NewTupleType = typename NewTupleType_<TVal, TagPos, 0, TCont, TRemainTypes...>::type;


    template <size_t Pos, typename... TTags>
    struct Pos2Type_
    {
        static_assert((Pos != 0), "Invalid position.");
    };

    template <size_t Pos, typename TCur, typename... TTags>
    struct Pos2Type_<Pos, TCur, TTags...>
    {
        using type = typename std::conditional_t<(Pos == 0), Identity_<TCur>, Pos2Type_<Pos - 1, TTags...>>::type;
    };

    template <size_t Pos, typename... TTags>
    using Pos2Type = typename Pos2Type_<Pos, TTags...>::type;

    template <std::size_t N, template <typename...> class TCont, typename... T>
    struct Create_
    {
        using type = typename Create_<N - 1, TCont, NullParameter, T...>::type;
    };

    template <template <typename...> class TCont, typename... T>
    struct Create_<0, TCont, T...>
    {
        using type = TCont<T...>;
    };


    /**
     * @brief 异类字典，用于存储类型不同的参数
     * @tparam TParameters 不同类型的参数
     */
    template <typename... TParameters>
    struct VarTypeDict
    {
        // 确保类型不一致
        static_assert(zsibot::utils::is_all_unique_v<TParameters...>, "VarTypeDict's TParameters must be unique.");

        template <typename... TTypes>
        struct Values
        {
            Values() = default;

            explicit Values(std::shared_ptr<void> (&&input)[sizeof...(TTypes)])
            {
                for (std::size_t i = 0; i < sizeof...(TTypes); ++i)
                {
                    m_tuple[i] = std::move(input[i]);
                }
            }

            /**
             * @brief 设置指定类型的参数
             * @tparam TTag 参数类型
             * @tparam TVal 参数值类型
             * @param val
             * @return
             */
            template <typename TTag, typename TVal>
            auto Set(TVal&& val) &&
            {
                using namespace zsibot::vartype_dict;
                constexpr static size_t TagPos = Tag2ID<TTag, TParameters...>;

                using rawVal    = std::decay_t<TVal>;
                auto* tmp       = new rawVal(std::forward<TVal>(val));
                m_tuple[TagPos] = std::shared_ptr<void>(tmp,
                    [](void* ptr)
                    {
                        auto* nptr = static_cast<rawVal*>(ptr);
                        delete nptr;
                    });
                using new_type  = NewTupleType<rawVal, TagPos, Values<>, TTypes...>;
                return new_type(std::move(m_tuple));
            }

            /**
             * @brief 获取制定 TTag 类型的参数引用
             * @tparam TTag
             * @return
             */
            template <typename TTag>
            const auto& Get() const
            {
                using namespace zsibot::vartype_dict;
                constexpr static size_t TagPos = Tag2ID<TTag, TParameters...>;
                using AimType                  = Pos2Type<TagPos, TTypes...>;
                void* tmp                      = m_tuple[TagPos].get();
                auto* res                      = static_cast<AimType*>(tmp);
                return *res;
            }

            template <typename TTag>
            using ValueType = zsibot::vartype_dict::Pos2Type<zsibot::vartype_dict::Tag2ID<TTag, TParameters...>, TTypes...>;


        private:
            std::shared_ptr<void> m_tuple[sizeof...(TTypes)];
        };

        static auto Create()
        {

            using namespace zsibot::vartype_dict;
            using type = typename Create_<sizeof...(TParameters), Values>::type;
            return type{};
        }
    };

}  // namespace zsibot::vartype_dict
