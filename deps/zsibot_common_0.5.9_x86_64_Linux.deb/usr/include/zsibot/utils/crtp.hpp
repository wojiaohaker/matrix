//
// Created by kanonwy on 2025/04/14
//

#pragma once

#include <atomic>
#include <stdexcept>

namespace zsibot::utils
{
    /**
     * @brief 用来限制单例的实例化次数
     * @tparam T
     * @tparam N
     */
    template <typename T, std::size_t N>
    struct LimitInstance
    {
        inline static std::atomic<std::size_t> count = 0;

        LimitInstance()
        {
            if (count >= N)
                throw std::runtime_error("LimitInstance::LimitInstance(): count >= N");
            ++count;
        }
        ~LimitInstance()
        {
            --count;
        }
    };
}  // namespace zsibot::utils
