#pragma once

#include "zsibot/macro/never.hpp"


#include <zsibot/macro/base_macro.hpp>
#include <zsibot/macro/construct_declare.hpp>
#include <zsibot/utils/func_traits.hpp>
#include <zsibot/utils/md5.hpp>

#include <cstdint>
#include <exception>
#include <functional>
#include <stdexcept>
#include <string>
#include <unordered_map>

namespace zsibot::utils
{

    enum class FuncRouteError
    {
        OK,
        NO_SUCH_FUNC,
        HAS_EXCEPTION,
        UNKNOW,
    };

    struct FuncRouteResult
    {
        FuncRouteError ec = FuncRouteError::UNKNOW;
        std::string    result;
    };


    /**
     * @brief  function router
     * @tparam FuncType
     */
    template <typename FuncType>
    class FuncRouter
    {
    public:
        using RouterInvokeFunc = FuncType;
        using FuncRouterTraits = FunctionTraits<FuncType>;

        static_assert(FuncRouterTraits::arity <= 4, "function size must less equal 4");

        ZSIBOT_DECLARE_FORBIDDEN_COPY_MOVE(FuncRouter);
        FuncRouter() = default;

        RouterInvokeFunc& operator[](const std::string& funcName)
        {
            const uint32_t key = zsibot::utils::MD5::MD5Hash32(funcName.data(), funcName.size());
            if (const auto it = map_invokers_.find(key); it != map_invokers_.end())
            {
                return it->second;
            }
            throw std::invalid_argument("funcName not exists");
        }
        /**
         * @brief 注册状态的处理函数
         */
        template <typename F>
        void register_handler(const std::string& state_name, F f)
        {
            if (uint32_t key = zsibot::utils::MD5::MD5Hash32(state_name.data()); key2func_name_.find(key) != key2func_name_.end())
            {
                throw std::invalid_argument("duplicate registration key !");
            }
            else
            {
                key2func_name_.emplace(key, state_name);
                return register_nonmember_func(key, f);
            }
        }


        /**
         * @brief 注册基于成员函数的状态处理函数
         */
        template <typename F, typename Self>
        void register_handler(const std::string& state_name, const F& f, Self* self)
        {

            if (uint32_t key = zsibot::utils::MD5::MD5Hash32(state_name.data()); key2func_name_.find(key) != key2func_name_.end())
            {
                throw std::invalid_argument("duplicate registration key !");
            }
            else
            {
                key2func_name_.emplace(key, state_name);
                return register_member_func(key, f, self);
            }
        }


        /**
         * @brief 移除某一个函数的处理
         */
        void remove_handler(const std::string& name)
        {
            const uint32_t key = zsibot::utils::MD5::MD5Hash32(name.data());
            this->map_invokers_.erase(key);
            key2func_name_.erase(key);
        }

        /**
         * @brief 根据 key 映射出状态名
         */
        std::string get_name_by_key(uint32_t key)
        {
            if (const auto it = key2func_name_.find(key); it != key2func_name_.end())
            {
                return it->second;
            }
            return std::to_string(key);
        }


        FuncRouteResult route(uint32_t key)
        {
            FuncRouteResult fsm_func_route_result{};
            std::string     result;
            try
            {
                if (auto it = map_invokers_.find(key); it == map_invokers_.end())
                {
                    result                   = "unknow function: " + get_name_by_key(key);
                    fsm_func_route_result.ec = FuncRouteError::NO_SUCH_FUNC;
                }
                else
                {
                    it->second();
                    fsm_func_route_result.ec = FuncRouteError::OK;
                }
            }
            catch (...)
            {
                result                   = "call: " + get_name_by_key(key) + "error";
                fsm_func_route_result.ec = FuncRouteError::HAS_EXCEPTION;
            }

            fsm_func_route_result.result = std::move(result);
            return fsm_func_route_result;
        }


    private:
#define ARGS_HELPER_0(x) (GetType<x, typename FuncRouterTraits::args_type_list> member##x)

#define ARGS_HELPER_1(x, y)                                                                                                                \
    (GetType<x, typename FuncRouterTraits::args_type_list> member##x, GetType<y, typename FuncRouterTraits::args_type_list> member##y)
#define ARGS_HELPER_2(x, y, z)                                                                                                             \
    (GetType<x, typename FuncRouterTraits::args_type_list> member##x, GetType<y, typename FuncRouterTraits::args_type_list> member##y,     \
        GetType<z, typename FuncRouterTraits::args_type_list> member##z)

#define ARGS_HELPER_3(x, y, z, w)                                                                                                          \
    (GetType<x, typename FuncRouterTraits::args_type_list> member##x, GetType<y, typename FuncRouterTraits::args_type_list> member##y,     \
        GetType<z, typename FuncRouterTraits::args_type_list> member##z, GetType<w, typename FuncRouterTraits::args_type_list> member##w)


#define GET_MACRO(_0, _1, _2, _3, NAME, ...) NAME
#define ARGS_HELPER(...)                     GET_MACRO(__VA_ARGS__, ARGS_HELPER_3, ARGS_HELPER_2, ARGS_HELPER_1, ARGS_HELPER_0)(__VA_ARGS__)

#define INVOKE_HELPER_0(x) std::invoke(f, member##x)

#define INVOKE_HELPER_1(x, y) std::invoke(f, member##x, member##y)

#define INVOKE_HELPER_2(x, y, z) std::invoke(f, member##x, member##y, member##z)

#define INVOKE_HELPER_3(x, y, z, w) std::invoke(f, member##x, member##y, member##z, member##w)


#define INVOKE_HELP(...) GET_MACRO(__VA_ARGS__, INVOKE_HELPER_3, INVOKE_HELPER_2, INVOKE_HELPER_1, INVOKE_HELPER_0)(__VA_ARGS__)


#define INVOKE_MEMBER_HELPER_0(x) std::invoke(f, self, member##x)

#define INVOKE_MEMBER_HELPER_1(x, y) std::invoke(f, self, member##x, member##y)

#define INVOKE_MEMBER_HELPER_2(x, y, z) std::invoke(f, self, member##x, member##y, member##z)

#define INVOKE_MEMBER_HELPER_3(x, y, z, w) std::invoke(f, self, member##x, member##y, member##z, member##w)


#define INVOKE_MEMBER_HELP(...)                                                                                                            \
    GET_MACRO(__VA_ARGS__, INVOKE_MEMBER_HELPER_3, INVOKE_MEMBER_HELPER_2, INVOKE_MEMBER_HELPER_1, INVOKE_MEMBER_HELPER_0)(__VA_ARGS__)


#define REGISTER_NONMEMBER_FUNC(...)                                                                                                       \
    template <typename F>                                                                                                                  \
    std::enable_if_t<length_v<typename FuncRouterTraits::args_type_list> == ZSIBOT_COUNT_ARGS(__VA_ARGS__)> register_nonmember_func(       \
        uint32_t key, F f)                                                                                                                 \
    {                                                                                                                                      \
        this->map_invokers_[key] = [f] ARGS_HELPER(__VA_ARGS__)                                                                            \
        {                                                                                                                                  \
            INVOKE_HELP(__VA_ARGS__);                                                                                                      \
        };                                                                                                                                 \
    }

        template <typename F>
        void register_nonmember_func(uint32_t key, F f)
        {
            if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 1)
            {
                this->map_invokers_[key] = [f] ARGS_HELPER(0)
                {
                    INVOKE_HELP(0);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 2)
            {
                this->map_invokers_[key] = [f] ARGS_HELPER(0, 1)
                {
                    INVOKE_HELP(0, 1);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 3)
            {
                this->map_invokers_[key] = [f] ARGS_HELPER(0, 1, 2)
                {
                    INVOKE_HELP(0, 1, 2);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 4)
            {
                this->map_invokers_[key] = [f] ARGS_HELPER(0, 1, 2, 3)
                {
                    INVOKE_HELP(0, 1, 2, 3);
                };
            }
            else
            {
                ZSIBOT_UNREACHABLE_CODE("register not ok!");
            }
        }


#define REGISTER_MEMBER_FUNC(...)                                                                                                          \
    template <typename F, typename Self>                                                                                                   \
    std::enable_if_t<length_v<typename FuncRouterTraits::args_type_list> == ZSIBOT_COUNT_ARGS(__VA_ARGS__)> register_member_func(          \
        uint32_t key, const F& f, Self* self)                                                                                              \
    {                                                                                                                                      \
        this->map_invokers_[key] = [f, self] ARGS_HELPER(__VA_ARGS__)                                                                      \
        {                                                                                                                                  \
            INVOKE_MEMBER_HELP(__VA_ARGS__);                                                                                               \
        };                                                                                                                                 \
    }

        template <typename F, typename Self>
        void register_member_func(uint32_t key, const F& f, Self* self)
        {
            if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 1)
            {
                this->map_invokers_[key] = [f, self] ARGS_HELPER(0)
                {
                    INVOKE_MEMBER_HELP(0);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 2)
            {
                this->map_invokers_[key] = [f, self] ARGS_HELPER(0, 1)
                {
                    INVOKE_MEMBER_HELP(0, 1);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 3)
            {
                this->map_invokers_[key] = [f, self] ARGS_HELPER(0, 1, 2)
                {
                    INVOKE_MEMBER_HELP(0, 1, 2);
                };
            }
            else if constexpr (length_v<typename FuncRouterTraits::args_type_list> == 4)
            {
                this->map_invokers_[key] = [f, self] ARGS_HELPER(0, 1, 2, 3)
                {
                    INVOKE_MEMBER_HELP(0, 1, 2, 3);
                };
            }
            else
            {
                ZSIBOT_UNREACHABLE_CODE("register not ok!");
            }
        }


        // REGISTER_NONMEMBER_FUNC(0)
        // REGISTER_NONMEMBER_FUNC(0, 1)
        // REGISTER_NONMEMBER_FUNC(0, 1, 2)
        // REGISTER_NONMEMBER_FUNC(0, 1, 3, 4)
        // REGISTER_MEMBER_FUNC(0)
        // REGISTER_MEMBER_FUNC(0, 1)
        // REGISTER_MEMBER_FUNC(0, 1, 2)
        // REGISTER_MEMBER_FUNC(0, 1, 3, 4)

        std::unordered_map<uint32_t, RouterInvokeFunc> map_invokers_;
        std::unordered_map<uint32_t, std::string>      key2func_name_;
    };
}  // namespace zsibot::utils