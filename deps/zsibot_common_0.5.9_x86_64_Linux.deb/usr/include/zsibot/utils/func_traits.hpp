#pragma once

#include <functional>
#include <memory>
#include <tuple>

#include <zsibot/utils/typelist.hpp>

namespace zsibot::utils
{
    template <typename T>
    struct tuple_tail;

    template <typename Head, typename... Tail>
    struct tuple_tail<std::tuple<Head, Tail...>>
    {
        using type = std::tuple<Tail...>;
    };


    template <typename FunctionT>
    struct function_traits
    {
        using arguments = typename tuple_tail<typename function_traits<decltype(&FunctionT::operator())>::arguments>::type;
        static constexpr std::size_t arity = std::tuple_size_v<arguments>;
        template <std::size_t N>
        using argument_type = std::tuple_element_t<N, arguments>;

        using return_type = typename function_traits<decltype(&FunctionT::operator())>::return_type;
    };

    template <typename ReturnTypeT, typename... Args>
    struct function_traits<ReturnTypeT(Args...)>
    {
        using arguments = std::tuple<Args...>;

        static constexpr std::size_t arity = std::tuple_size_v<arguments>;

        template <std::size_t N>
        using argument_type = std::tuple_element_t<N, arguments>;

        using return_type = ReturnTypeT;
    };


    template <typename ReturnTypeT, typename... Args>
    struct function_traits<ReturnTypeT (*)(Args...)> : function_traits<ReturnTypeT(Args...)>
    {
    };


    template <typename ClassT, typename ReturnTypeT, typename... Args, typename... FArgs>
#if defined _LIBCPP_VERSION
    struct function_traits<std::__bind<ReturnTypeT (ClassT::*)(Args...), FArgs...>>
#elif defined _GLIBCXX_RELEASE
    struct function_traits<std::_Bind<ReturnTypeT (ClassT::*(FArgs...))(Args...)>>
#elif defined __GLIBCXX__
    struct function_traits<std::_Bind<std::_Mem_fn<ReturnTypeT (ClassT::*)(Args...)>(FArgs...)>>
#else
#error "Unsupported C++ compiler / standard library"
#endif
        : function_traits<ReturnTypeT(Args...)>
    {
    };


    template <typename ClassT, typename ReturnTypeT, typename... Args, typename... FArgs>
#if defined _LIBCPP_VERSION  // libc++ (Clang)
    struct function_traits<std::__bind<ReturnTypeT (ClassT::*)(Args...) const, FArgs...>>
#elif defined _GLIBCXX_RELEASE  // glibc++ (GNU C++ >= 7.1)
    struct function_traits<std::_Bind<ReturnTypeT (ClassT::*(FArgs...))(Args...) const>>
#elif defined __GLIBCXX__       // glibc++ (GNU C++)
    struct function_traits<std::_Bind<std::_Mem_fn<ReturnTypeT (ClassT::*)(Args...) const>(FArgs...)>>
#endif
        : function_traits<ReturnTypeT(Args...)>
    {
    };


    // std::bind for free functions
    template <typename ReturnTypeT, typename... Args, typename... FArgs>
#if defined DOXYGEN_ONLY
    struct function_traits<std::bind<ReturnTypeT (&)(Args...), FArgs...>>
#elif defined _LIBCPP_VERSION  // libc++ (Clang)
    struct function_traits<std::__bind<ReturnTypeT (&)(Args...), FArgs...>>
#elif defined __GLIBCXX__      // glibc++ (GNU C++)
    struct function_traits<std::_Bind<ReturnTypeT (*(FArgs...))(Args...)>>
#else
#error "Unsupported C++ compiler / standard library"
#endif
        : function_traits<ReturnTypeT(Args...)>
    {
    };


    template <typename ClassT, typename ReturnTypeT, typename... Args>
    struct function_traits<ReturnTypeT (ClassT::*)(Args...) const> : function_traits<ReturnTypeT(ClassT&, Args...)>
    {
    };

    template <typename FunctionT>
    struct function_traits<FunctionT&> : function_traits<FunctionT>
    {
    };

    template <typename FunctionT>
    struct function_traits<FunctionT&&> : function_traits<FunctionT>
    {
    };


    template <std::size_t Arity, typename FunctorT>
    struct arity_comparator : std::integral_constant<bool, (Arity == function_traits<FunctorT>::arity)>
    {
    };

    template <typename FunctorT, typename... Args>
    struct check_arguments : std::is_same<typename function_traits<FunctorT>::arguments, std::tuple<Args...>>
    {
    };

    template <typename FunctorAT, typename FunctorBT>
    struct same_arguments : std::is_same<typename function_traits<FunctorAT>::arguments, typename function_traits<FunctorBT>::arguments>
    {
    };

    template <typename ReturnTypeT, typename... Args>
    struct as_std_function_helper;

    template <typename ReturnTypeT, typename... Args>
    struct as_std_function_helper<ReturnTypeT, std::tuple<Args...>>
    {
        using type = std::function<ReturnTypeT(Args...)>;
    };

    template <typename FunctorT, typename FunctionTraits = function_traits<FunctorT>>
    struct as_std_function
    {
        using type = typename as_std_function_helper<typename FunctionTraits::return_type, typename FunctionTraits::arguments>::type;
    };

}  // namespace zsibot::utils


namespace zsibot::utils
{
    template <typename T>
    struct FunctionTraits;
    template <typename T>
    struct FunctionTraits : FunctionTraits<std::remove_cv_t<std::remove_reference_t<T>>>
    {
    };


    /**
     * @brief  for std::function traits
     * @tparam R
     * @tparam Args
     */
    template <typename R, typename... Args>
    struct FunctionTraits<std::function<R(Args...)>>
    {
        using return_type                  = R;
        using args_tuple                   = std::tuple<Args...>;
        using args_type_list =       TypeList<Args...>;
        static constexpr std::size_t arity = sizeof...(Args);
    };

}  // namespace zsibot::utils