//
// Created by kanonwy on 2024/12/24
//

#pragma once

#include <type_traits>

/**
 * @brief 常用的类型萃取工具所在的命名空间
 */
namespace zsibot::utils
{
    /**
     * @brief 类型列表
     */
    template <typename... T>
    struct TypeList
    {
    };

    namespace details
    {
        template <typename TL>
        struct length;

        template <template <typename...> typename TL, typename... Ts>
        struct length<TL<Ts...>>
        {
            using type = std::integral_constant<std::size_t, sizeof...(Ts)>;
        };

        template <typename TL>
        using length_t = typename length<TL>::type;
    }  // namespace details

    /**
     * @brief 类型列表的长度
     */
    template <typename TL>
    constexpr std::size_t length_v = details::length_t<TL>::value;

    namespace details
    {
        // 递归模板：获取TypeList中的第N个类型
        template <std::size_t N, typename T>
        struct GetTypeImpl;  // 默认情况下不做任何事情，避免匹配错误

        // 特化版本：当N为0时，返回第一个类型
        template <typename First, typename... Rest>
        struct GetTypeImpl<0, TypeList<First, Rest...>>
        {
            using type = First;
        };

        // 递归特化版本：返回下一个类型
        template <std::size_t N, typename First, typename... Rest>
        struct GetTypeImpl<N, TypeList<First, Rest...>>
        {
            using type = typename GetTypeImpl<N - 1, TypeList<Rest...>>::type;
        };
    }  // namespace details

    template <std::size_t N, typename TL>
    using GetType = typename details::GetTypeImpl<N, TL>::type;

}  // namespace zsibot::utils
