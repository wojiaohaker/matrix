//
// Created by kanonwy on 2025/04/24
//

#pragma once

#include <assert.h>
#include <stdint.h>
#include <time.h>

class Timer
{
public:
    explicit Timer()
    {
        start();
    }

    void start()
    {
        clock_gettime(CLOCK_MONOTONIC, &startTime_);
    }

    double getMs() const
    {
        return static_cast<double>(getNs()) / 1.e6;
    }

    int64_t getNs() const
    {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        return static_cast<int64_t>(now.tv_nsec - startTime_.tv_nsec) + 1000000000 * (now.tv_sec - startTime_.tv_sec);
    }

    double getSeconds() const
    {
        return static_cast<double>(getNs()) / 1.e9;
    }
    timespec startTime_;
};

inline double getSysTimeNowMs()
{
    timespec systime;
    clock_gettime(CLOCK_MONOTONIC, &systime);
    const double now_time = static_cast<double>(static_cast<int>(systime.tv_nsec) + 1000000000 * systime.tv_sec) / 1.e6;
    return now_time;
}
