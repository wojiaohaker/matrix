#pragma once

#include <type_traits>
#include <zsibot/macro.hpp>
#include <zsibot/utils.hpp>


/**
 * @brief jszr 基础工具所在的命名空间
 * ## Desc
 * 该命名空间内包含一些基础的模板工具类
 */
namespace zsibot::utils
{
    namespace details
    {
        template <class TSignature>
        struct FunctionTypeHelper;

        template <class TRes, class... TArgs>
        struct FunctionTypeHelper<TRes(TArgs...)>
        {
            using ReturnType = TRes;
        };
    }  // namespace details

    template <typename T>
    using original_type = std::remove_cv_t<std::remove_reference_t<T>>;

    template <typename T>
    using intrinsic_type = std::remove_pointer_t<std::remove_all_extents_t<original_type<T>>>;

    template <typename F, typename... P>
    using function_return_type = decltype(ZSIBOT_DECLVALUE(F)(ZSIBOT_DECLVALUE(P)...));

    template <class TSignature>
    using signature_return_type = typename details::FunctionTypeHelper<TSignature>::ReturnType;

    /**
     * @brief 取出迭代器维护的值的类型
     */
    template <typename TIterator>
    using iterator_type = decltype(*ZSIBOT_DECLVALUE(TIterator));

    /**
     * @brief 取出迭代器维护的值的原始类型
     */
    template <typename TIterator>
    using original_iterator_type = std::remove_reference_t<iterator_type<TIterator>>;  // original_type<iterator_type<TIterator>>;

    namespace details
    {
        template <template <class...> class TPack, class... TLhs>
        auto mergePackTrait(TPack<TLhs...>, TPack<>)
        {
            return TPack<TLhs...>();
        }

        template <template <class...> class TPack, class... TLhs, class TRhsFirst, class... TRhsRest>
        auto mergePackTrait(TPack<TLhs...>, TPack<TRhsFirst, TRhsRest...>)
        {
            if constexpr (zsibot::utils::is_different_from_v<TRhsFirst, TLhs...>)
            {
                return mergePackTrait(TPack<TLhs..., TRhsFirst>(), TPack<TRhsRest...>());
            }
            else
            {
                return mergePackTrait(TPack<TLhs...>(), TPack<TRhsRest...>());
            }
        }
    }  // namespace details

    /**
     * @brief 合并两个多模板参数的类类型，保持左边多模板参数的排序，
     * 去除右边多模板参数中的重复参数，追加不重复的参数
     */
    template <class TPackLhs, class TPackRhs>
    using merged_pack_type = decltype(details::mergePackTrait(ZSIBOT_DECLVALUE(TPackLhs), ZSIBOT_DECLVALUE(TPackRhs)));
}  // namespace zsibot::utils
