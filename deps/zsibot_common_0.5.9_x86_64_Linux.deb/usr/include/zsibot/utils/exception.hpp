#pragma once

#include <stdexcept>

namespace zsibot
{

    class Exception : public std::exception

    {
    public:
        Exception(const std::string& msg, int code = 0);

        Exception(const std::string& msg, const std::string& arg, int code = 0);

        Exception(const std::string& msg, const Exception& nested, int code = 0);


        Exception(const Exception& exc);

        ~Exception() noexcept;

        Exception& operator=(const Exception& exc);

        virtual const char* name() const noexcept;

        virtual const char* className() const noexcept;

        virtual const char* what() const noexcept;

        const Exception* nested() const;

        const std::string& message() const;

        int code() const;

        std::string displayText() const;

        virtual Exception* clone() const;

        virtual void rethrow() const;

    protected:
        Exception(int code = 0);

        void message(const std::string& msg);

        void extendedMessage(const std::string& arg);

    private:
        std::string _msg;
        Exception*  _pNested;
        int         _code;
    };
}  // namespace zsibot
