//
// Created by kanonwy on 25-01-20.
//

#pragma once

namespace zsibot::utils
{
    template <class T>
    constexpr decltype(auto) remove_const(const T& x)
    {
        return const_cast<T&>(x);
    }

    template <class T>
    constexpr decltype(auto) remove_const(const T* x)
    {
        return const_cast<T*>(x);
    }

    template <class T>
    constexpr decltype(auto) add_const(T& x)
    {
        return const_cast<const T&>(x);
    }

    template <class T>
    constexpr decltype(auto) add_const(T* x)
    {
        return const_cast<const T*>(x);
    }
}  // namespace zsibot::utils
