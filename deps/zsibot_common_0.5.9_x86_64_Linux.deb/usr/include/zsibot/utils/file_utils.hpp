//
// Created by kanonwy on 25-09-09.
//

#pragma once

#include <filesystem>
#include <string>

#define let auto

namespace zsibot::utils
{

    /**
     * @brief check dir and use pattern to match all file current dir and maintain num of input
     * @param dir
     * @param maintain_num
     */
    bool check_and_clean_file_by_last_modify_time(const std::string& dir, int maintain_num);


    /**
     * @brief check dir and use pattern to match all file current dir and maintain num of input
     * @param dir
     * @param maintain_num
     * @return
     */
    bool check_and_clean_file_by_name(const std::string& dir, int maintain_num);

    /**
     * @brief get
     * @param p
     * @return
     */
    int64_t get_file_last_write_time_stamp_ms(const std::filesystem::path& p);

    int64_t get_file_last_write_time_stamp_sec(const std::filesystem::path& p);


}  // namespace zsibot::utils
