#pragma once

#include <atomic>

namespace zsibot
{

    template <typename Callable>
    class ScopeExit
    {
    public:
        explicit ScopeExit(Callable callable)
            : callable_(callable),
              exec_(true)
        {
        }

        ~ScopeExit()
        {
            if (exec_)
            {
                callable_();
            }
        }

        void cancle()
        {
            exec_ = false;
        }

    private:
        Callable         callable_;
        std::atomic_bool exec_;
    };


    template <typename Callable>
    ScopeExit<Callable> make_scope_exit(Callable callable)
    {
        return ScopeExit<Callable>(callable);
    }
}  // namespace zsibot
