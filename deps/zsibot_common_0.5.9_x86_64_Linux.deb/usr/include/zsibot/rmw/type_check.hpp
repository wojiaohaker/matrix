//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <zsibot/macro/fancier.hpp>
#include <string>
#include <type_traits>

namespace google::protobuf
{
    class MessageLite;
}

namespace zsibot::rmw::details
{
    /**
     * @brief 类型判断
     * @tparam T
     * @tparam U
     */
    template <typename T, typename U = void>
    struct is_protocol_buffer
    {
        static constexpr bool value = false;  ///<<<
    };

    /**
     * @brief 类型判断
     * @tparam T
     */
    template <typename T>
    struct is_protocol_buffer<T, std::enable_if_t<std::is_base_of_v<::google::protobuf::MessageLite, T>>>
    {
        static constexpr bool value = true;  ///<<<
    };


    /**
     * @brief 判断类型 T 是否是 protobuf msg
     */
    template <typename T>
    constexpr static bool is_protocol_buffer_v = is_protocol_buffer<T>::value;


    /**
     *@brief protobuf 消息类型的概念
     */
    template <typename T>
    using PROTOBUF_CONCEPT = ZSIBOT_CONCEPT((is_protocol_buffer_v<T>));


    /**
     * @brief 获取数据类型名
     * @tparam _TType_ 类型
     */
    template <typename _TType_>
    std::string getDataTypeName()
    {
        std::string type_name;
        if constexpr (std::is_same_v<_TType_, std::string>)
        {
            type_name += "std::string: ";
        }
        else if constexpr (std::is_base_of_v<::google::protobuf::MessageLite, _TType_>)
        {
            type_name += "ProtocolBuffer: ";
        }
        else
        {
            type_name += "customize: ";
        }

        const std::string name  = __PRETTY_FUNCTION__;
        const auto        begin = name.find("with _TType_ = ");
        if (const auto end = name.find("; std::string =", begin); begin != std::string::npos && end != std::string::npos)
        {
            type_name += name.substr(begin + 15, end - begin - 15);
        }
        return type_name;
    }


}  // namespace jszr::rmw::details
