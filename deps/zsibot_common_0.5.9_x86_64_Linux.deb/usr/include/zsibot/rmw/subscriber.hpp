//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include "zsibot/macro/construct_declare.hpp"
#include "zsibot/macro/fancier.hpp"
#include "zsibot/rmw/abstract/i_callback_policy.hpp"
#include "zsibot/rmw/abstract/i_interface.hpp"
#include "zsibot/rmw/base/message.hpp"
#include "zsibot/rmw/subscription.hpp"
#include "zsibot/rmw/topic.hpp"
#include "policy/direct_policy.hpp"

#include <atomic>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>

namespace zsibot::rmw
{
    namespace details
    {
        /**
         * @brief 订阅器抽象设备, 用于隔离 Topic 话题类型与 CallbackPolicy 策略类型
         * @tparam T 订阅的消息类型
         */
        template <typename T>
        class ISubscriberBase
        {
        public:
            virtual ~ISubscriberBase() = default;
            /**
             * @brief 初始化抽象接口
             * @return
             */
            virtual bool init() = 0;

            /**
             * @brief 初始化抽象接口
             * @param topic_name
             * @return
             */
            virtual bool init(const std::string& topic_name) = 0;

            /**
             * @brief 重置抽象接口
             */
            virtual void reset() = 0;

            /**
             * @brief 话题名抽象接口
             * @return
             */
            [[nodiscard]] virtual std::string topicName() const = 0;

            /**
             * @brief 取消订阅抽象接口
             * @param subscription
             */
            virtual void unsubscribe(const Subscription& subscription) = 0;

            /**
             * @brief 取消所有订阅抽象接口
             */
            virtual void unsubscribeAll() = 0;

            /**
             * @brief 订阅抽象接口
             * @param cb
             * @return
             */
            virtual Subscription subscribe(MessageCallback<T> cb) = 0;
            /**
             * @brief 订阅抽象接口
             * @param topic_name
             * @param cb
             * @return
             */
            virtual Subscription subscribe(const std::string& topic_name, MessageCallback<T> cb) = 0;
        };

    }  // namespace details

    /**
     * @brief 订阅器上下行转换的抽象接口类
     */
    class SubscriberBase
    {
    public:
        virtual ~SubscriberBase() = default;

        /**
         *@brief 取消订阅抽象接口
         */
        virtual void unsubscribe(const Subscription& subscription) = 0;

        /**
         * @brief 重置抽象接口
         */
        virtual void reset() = 0;

        /**
         * @brief 订阅接口
         * @tparam DT
         * @param cb
         * @return
         */
        template <class DT>
        Subscription subscribe(MessageCallback<DT> cb)
        {
            if (auto* ptr = dynamic_cast<zsibot::rmw::details::ISubscriberBase<DT>*>(this); ptr != nullptr)
            {
                return ptr->subscribe(std::move(cb));
            }
            std::cerr << "SubscriberBase::subscribe: subscribe failed" << std::endl;
            return {};
        }

        /**
         * @brief 订阅接口
         * @tparam DT
         * @param topic_name
         * @param cb
         * @return
         */
        template <class DT>
        Subscription subscribe(const std::string& topic_name, MessageCallback<DT> cb)
        {
            if (auto* ptr = dynamic_cast<zsibot::rmw::details::ISubscriberBase<DT>*>(this); ptr != nullptr)
            {
                return ptr->subscribe(topic_name, std::move(cb));
            }
            std::cerr << "SubscriberBase::subscribe: subscribe failed" << std::endl;
            return {};
        }
    };


    /**
     * @brief  订阅器
     * @tparam TTopic 订阅器对应的话题类型
     * @tparam TCallbackPolicy 订阅器的回调策略
     * @details 目前订阅器仅支持直接回调策略
     * @todo 增加更多的回调策略
     */
    template <typename TTopic, template <class> class TCallbackPolicy = DirectCallbackPolicy>
    class Subscriber : public SubscriberBase, public details::ISubscriberBase<typename TTopic::DataType>
    {
    public:
        using DataType        = typename TTopic::DataType;               ///<<< 消息数据类型
        using MessagePtr      = ::zsibot::rmw::MessagePtr<DataType>;       ///<<< 消息指针
        using CallbackPolicy  = TCallbackPolicy<MessagePtr>;             ///<<< 回调策略
        using MessageCallback = ::zsibot::rmw::MessageCallback<DataType>;  ///<<< 消息回调类型

        static_assert(zsibot::is<details::TopicClass, TTopic>, "TTopic must be type of topic");
        static_assert(zsibot::is<details::CallbackPolicyClass, CallbackPolicy>, "CallbackPolicy must be type of CallbackPolicy");

        /**
         * @brief 默认拷贝
         */
        ZSIBOT_DECLARE_DEFAULT_MOVE(Subscriber);

        /**
         * @brief 禁止移动
         */
        ZSIBOT_DECLARE_FORBIDDEN_COPY(Subscriber);

    public:
        Subscriber()
            : context_ptr_(std::make_unique<SubscriberContext>())
        {
        }
        ~Subscriber() override
        {
            reset();
        }

        /**
         * @brief 初始化
         * @return
         * @note 必须处理返回值
         */
        [[nodiscard]] bool init() override
        {
            return init(TTopic::name);
        }

        /**
         * @brief  初始化订阅器
         * @param topic_name 订阅器对应的话题名
         * @return
         */
        [[nodiscard]] bool init(const std::string& topic_name) override
        {
            return tryInit(topic_name, true);
        }

        /**
         * @brief 重置
         */
        void reset() override
        {
            if (context_ptr_ == nullptr)
                is_init_ = false;
            return;
            {
                std::unique_lock lk(mt_);
                context_ptr_->impl_ptr = nullptr;
            }
        }

        /**
         * @brief 订阅
         * @param cb
         * @return
         */
        Subscription subscribe(MessageCallback cb) override
        {
            return subscribe(TTopic::name, std::move(cb));
        }

        /**
         * @brief 订阅
         * @param topic_name
         * @param cb
         * @return
         */
        Subscription subscribe(const std::string& topic_name, MessageCallback cb) override
        {
            if (not tryInit(topic_name, false))
            {
                return {};
            }
            return context_ptr_->callback_policy.subscribe(std::move(cb));
        }


        /**
         * @brief 订阅器话题名
         * @return
         */
        [[nodiscard]] std::string topicName() const override
        {
            std::unique_lock lk(mt_);
            return context_ptr_->topic_name;
        }

        /**
         * @brief 取消指定回调
         */
        void unsubscribe(const Subscription& subscription) override
        {
            context_ptr_->callback_policy.unSubscribe(subscription);
        }

        /**
         * @brief 取消所有的回调类型
         * @todo: Need add lock for all policy operate?
         */
        void unsubscribeAll() override
        {
            context_ptr_->callback_policy.unSubscribeAll();
        }


        /**
         * @brief 回调策略
         * @return
         */
        CallbackPolicy& callbackPolicy()
        {
            return context_ptr_->callback_policy;
        }

        /**
         * @brief 回调策略
         * @return
         */
        const CallbackPolicy& callbackPolicy() const
        {
            return context_ptr_->callback_policy;
        }


    private:
        bool tryInit(const std::string& topic_name, bool is_reset)
        {
            if (is_init_ and not is_reset)
            {
                return true;
            }
            {
                // TODO: this need lock? maybe use release and acquire to make it better.
                std::unique_lock lk(mt_);

                context_ptr_->impl_ptr   = nullptr;
                context_ptr_->topic_name = {};
                if (topic_name.empty())
                {
                    return false;
                }
                // create actual subscriber instance
                context_ptr_->impl_ptr = details::createSubscriber<TTopic>(topic_name);
                if (nullptr == context_ptr_->impl_ptr)
                {
                    return false;
                }
                context_ptr_->topic_name = topic_name;
                // register callback
                is_init_ = context_ptr_->impl_ptr->subscribe(
                    [this](MessagePtr msg_ptr)
                    {
                        if (nullptr != msg_ptr)
                        {
                            // This is sp move
                            // This is a lock. because of can use multi callback
                            // TODO: remove the lock and move msg to function.
                            context_ptr_->callback_policy.call(std::move(msg_ptr));
                        }
                    });
                return is_init_;
            }
        }

        struct SubscriberContext
        {
            std::string                      topic_name;       ///<<< 当前订阅器订阅的话题
            CallbackPolicy                   callback_policy;  ///<<< 回调策略器
            details::SubscriberPtr<DataType> impl_ptr;         ///<<< 真正实现接收器的实例
        };

        std::atomic_bool                   is_init_ = false;  ///<<< 订阅器是否已经初始化
        std::unique_ptr<SubscriberContext> context_ptr_;
        mutable std::mutex                 mt_;
    };


}  // namespace zsibot::rmw
