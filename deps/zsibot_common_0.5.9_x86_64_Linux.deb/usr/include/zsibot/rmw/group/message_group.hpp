#pragma once

#include <zsibot/rmw/base/message.hpp>
#include <zsibot/utils.hpp>

#include <vector>

namespace zsibot::rmw
{
    namespace details
    {

        /**
         * @brief MessageGroupBase may contain multi message vector.
         * @tparam Types
         */
        template <class... Types>
        struct MessageGroupBase;

        template <class T>
        struct MessageGroupBase<T>
        {
            std::vector<MessagePtr<T>> msgs;  ///<<< 消息存储指针
        };

        template <class TFirst, class... TRest>
        struct MessageGroupBase<TFirst, TRest...> : MessageGroupBase<TFirst>, MessageGroupBase<TRest...>
        {
        };

        template <class... Types>
        class SyncContext;
    }  // namespace details


    /**
     * @brief container which store multi type's msg vector
     * @tparam Types msg variant template class
     */
    template <class... Types>
    class MessageGroup : details::MessageGroupBase<Types...>
    {
        static_assert(zsibot::utils::is_all_unique_v<Types...>);

    public:
        /**
         * @brief get special type msg.
         * @tparam T message type
         * @return
         */
        template <class T>
        const std::vector<MessagePtr<T>>& get() const
        {
            static_assert(not zsibot::utils::is_different_from_v<T, Types...>);
            return static_cast<const details::MessageGroupBase<T>*>(this)->msgs;
        }

    private:
        friend class details::SyncContext<Types...>;

        /**
         * @brief  get mutable special msg vector
         * @tparam T msg type
         * @return
         */
        template <class T>
        std::vector<MessagePtr<T>>& mutableGet()
        {
            static_assert(not zsibot::utils::is_different_from_v<T, Types...>);
            return static_cast<details::MessageGroupBase<T>*>(this)->msgs;
        }
    };

    //  sp to msg container
    template <class... Types>
    using MessageGroupPtr = std::shared_ptr<MessageGroup<Types...>>;

    // msg callback function
    template <class... Types>
    using MessageGroupCallback = std::function<void(MessageGroupPtr<Types...>)>;
}  // namespace zsibot::rmw
