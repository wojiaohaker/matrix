#pragma once

#include "zsibot/container/timeliness.hpp"
#include "message_group.hpp"

namespace zsibot::rmw
{
    namespace details
    {
        template <class... Types>
        struct ObservableTrait;

        template <class T>
        struct ObservableTrait<T>
        {
            using Type = zsibotc::timeliness<MessagePtr<T>>;
        };

        template <class... Types>
        struct ObservableTrait
        {
            using Type = zsibotc::timeliness<MessageGroupPtr<Types...>>;
        };
    }  // namespace details

    /**
     * @brief 可用于订阅的、可等待的类型，用户可通过它订阅消息，但在
     * 用户线程内等待、或检查消息的到来。
     */
    template <class... Types>
    using Observable = typename details::ObservableTrait<Types...>::Type;
}  // namespace jszr::comm
