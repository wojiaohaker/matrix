#pragma once

#include <map>
#include <memory>
#include <optional>

#include "zsibot/rmw/subscriber.hpp"
#include "zsibot/unit.hpp"
#include "message_group.hpp"

namespace zsibot::rmw::details
{

    /**
     * @brief   同步订阅器信息
     * @tparam T msg_type
     * @tparam MAX_TIME_DIFF_SET
     * @tparam BUFFER_SIZE_SET
     */
    template <class T, bool MAX_TIME_DIFF_SET = true, bool BUFFER_SIZE_SET = true>
    struct SyncSubInfo
    {
        std::shared_ptr<ISubscriberBase<T>> sub_ptr = nullptr;
        unit::Time                          max_time_diff;
        std::size_t                         buffer_size = 1;
        bool                                is_optional = false;
    };

    /**
     * @brief  同步基础类，用于存储订阅信息指针和订阅信息
     * @tparam Types 消息类型
     */
    template <class... Types>
    struct SyncBase;

    template <>
    struct SyncBase<>
    {
    };

    template <class T>
    struct SyncBase<T>
    {
        using SubPtr = std::shared_ptr<ISubscriberBase<T>>;

        std::map<SubPtr, SyncSubInfo<T>> sub_info;

        void merge(const SyncBase<T>& other)
        {
            sub_info.insert(other.sub_info.begin(), other.sub_info.end());
        }
    };

    template <class TFirst, class... TRest>
    struct SyncBase<TFirst, TRest...> : public SyncBase<TFirst>, public SyncBase<TRest...>
    {
    };

    template <class... Types>
    class SyncContext;

    template <class T>
    auto makeSharedSubPtr(ISubscriberBase<T>& existed_subscriber)
    {
        return std::shared_ptr<details::ISubscriberBase<T>>(&existed_subscriber, [](auto) {});
    }

    template <class TTopic, template <class> class TCallbackPolicy>
    auto makeNewSubPtr(const TopicTrait<TTopic, TCallbackPolicy>& topic_trait)
    {
        static_assert(zsibot::is<TopicClass, TTopic>);
        using DataType       = typename TTopic::DataType;
        using CallbackPolicy = TCallbackPolicy<DataType>;

        std::shared_ptr<details::ISubscriberBase<DataType>> ptr;

        if constexpr (std::is_same_v<CallbackPolicy, DefaultCallbackPolicy<DataType>>)
            ptr = std::make_shared<Subscriber<TTopic>>();
        else
        {
            static_assert(zsibot::is<CallbackPolicyClass, CallbackPolicy>);
            ptr = std::make_shared<Subscriber<TTopic, TCallbackPolicy>>();
        }

        ptr->init(topic_trait.name);
        return ptr;
    }

    template <template <class...> class TPack, class... TLhs, class... TRhs>
    constexpr bool isPackContainingTrait(TPack<TLhs...>, TPack<TRhs...>)
    {
        return (not zsibot::utils::is_different_from_v<TRhs, TLhs...> and ...);
    }

    template <class TLhsPack, class TRhsPack>
    static constexpr bool is_pack_containing = isPackContainingTrait(ZSIBOT_DECLVALUE(TLhsPack), ZSIBOT_DECLVALUE(TRhsPack));
}  // namespace zsibot::rmw::details

template <class T>
auto operator|(const zsibot::unit::Time& max_time_diff, zsibot::rmw::details::ISubscriberBase<T>& existed_subscriber)
{
    zsibot::rmw::details::SyncSubInfo<T, true, false> info;
    info.sub_ptr       = zsibot::rmw::details::makeSharedSubPtr(existed_subscriber);
    info.max_time_diff = max_time_diff;
    return info;
}

template <class TTopic, template <class> class TCallbackPolicy>
auto operator|(const zsibot::unit::Time& max_time_diff, const zsibot::rmw::details::TopicTrait<TTopic, TCallbackPolicy>& topic_trait)
{
    zsibot::rmw::details::SyncSubInfo<typename TTopic::DataType, true, false> info;
    info.sub_ptr       = zsibot::rmw::details::makeNewSubPtr(topic_trait);
    info.max_time_diff = max_time_diff;
    return info;
}

template <class T>
auto operator|(zsibot::rmw::details::ISubscriberBase<T>& existed_subscriber, std::size_t buffer_size)
{
    zsibot::rmw::details::SyncSubInfo<T, false, true> info;
    info.sub_ptr     = zsibot::rmw::details::makeSharedSubPtr(existed_subscriber);
    info.buffer_size = buffer_size;
    return info;
}

template <class TTopic, template <class> class TCallbackPolicy>
auto operator|(const zsibot::rmw::details::TopicTrait<TTopic, TCallbackPolicy>& topic_trait, std::size_t buffer_size)
{
    zsibot::rmw::details::SyncSubInfo<typename TTopic::DataType, false, true> info;
    info.sub_ptr     = zsibot::rmw::details::makeNewSubPtr(topic_trait);
    info.buffer_size = buffer_size;
    return info;
}

template <class T>
auto operator|(const zsibot::rmw::details::SyncSubInfo<T, true, false>& part_sub_info, std::size_t buffer_size)
{
    zsibot::rmw::details::SyncSubInfo<T, true, true> info;
    info.sub_ptr       = part_sub_info.sub_ptr;
    info.max_time_diff = part_sub_info.max_time_diff;
    info.buffer_size   = buffer_size;
    return info;
}

template <class T>
auto operator|(const zsibot::unit::Time& max_time_diff, const zsibot::rmw::details::SyncSubInfo<T, false, true>& part_sub_info)
{
    zsibot::rmw::details::SyncSubInfo<T, true, true> info;
    info.sub_ptr       = part_sub_info.sub_ptr;
    info.max_time_diff = max_time_diff;
    info.buffer_size   = part_sub_info.buffer_size;
    return info;
}

namespace zsibot::rmw
{
    template <class... Types>
    class Sync : public details::SyncBase<Types...>
    {
        static_assert(zsibot::utils::is_all_unique_v<Types...>);

    public:
        explicit Sync(std::size_t msgs_buffer_size = 10)
            : msgs_buffer_size_(msgs_buffer_size)
        {
        }

        explicit Sync(const zsibot::unit::Time& max_time_diff, std::size_t msgs_buffer_size = 10)
            : max_time_diff_(max_time_diff),
              msgs_buffer_size_(msgs_buffer_size)
        {
        }

        /**
         * @brief final call
         * @tparam TSubscribable 可订阅的类型
         * @param subscribable
         * @return
         */
        template <class TSubscribable>
        Sync& addRequired(TSubscribable&& subscribable)
        {
            add(makeSubInfo(std::forward<TSubscribable>(subscribable)), false);
            return *this;
        }

        template <class TSubscribable>
        Sync& addRequired(TSubscribable&& subscribable, const zsibot::unit::Time& max_time_diff)
        {
            auto sub_info          = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.max_time_diff = max_time_diff;
            return addRequired(std::move(sub_info));
        }

        template <class TSubscribable>
        Sync& addRequired(TSubscribable&& subscribable, std::size_t buffer_size)
        {
            auto sub_info        = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.buffer_size = buffer_size;
            return addRequired(std::move(sub_info));
        }

        template <class TSubscribable>
        Sync& addRequired(TSubscribable&& subscribable, const zsibot::unit::Time& max_time_diff, std::size_t buffer_size)
        {
            auto sub_info          = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.max_time_diff = max_time_diff;
            sub_info.buffer_size   = buffer_size;
            return addRequired(std::move(sub_info));
        }

        template <class TSubscribable>
        Sync& addOptional(TSubscribable&& subscribable)
        {
            add(makeSubInfo(std::forward<TSubscribable>(subscribable)), true);
            return *this;
        }


        template <class TSubscribable>
        Sync& addOptional(TSubscribable&& subscribable, const zsibot::unit::Time& max_time_diff)
        {
            auto sub_info          = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.max_time_diff = max_time_diff;
            return addOptional(std::move(sub_info));
        }


        template <class TSubscribable>
        Sync& addOptional(TSubscribable&& subscribable, std::size_t buffer_size)
        {
            auto sub_info        = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.buffer_size = buffer_size;
            return addOptional(std::move(sub_info));
        }


        template <class TSubscribable>
        Sync& addOptional(TSubscribable&& subscribable, const zsibot::unit::Time& max_time_diff, std::size_t buffer_size)
        {
            auto sub_info          = makeSubInfo(std::forward<TSubscribable>(subscribable));
            sub_info.max_time_diff = max_time_diff;
            sub_info.buffer_size   = buffer_size;
            return addOptional(std::move(sub_info));
        }

        template <class... AnotherTypes>
        Sync& operator+=(const Sync<AnotherTypes...>& other)
        {
            // 要求本类的所有模板参数包含给定的、需要被合并的另外一个 Sync 对象
            static_assert((not zsibot::utils::is_different_from_v<AnotherTypes, Types...> and ...),
                "this class should contain all template arguments from other class !");

            if (static_cast<std::size_t>(this) == static_cast<std::size_t>(&other))
                return *this;

            (getBase<AnotherTypes>().merge(other.template getBase<AnotherTypes>()), ...);

            return *this;
        }

        template <class... AnotherTypes>
        auto operator+(const Sync<AnotherTypes...>& other) const
        {
            // 合并为新的 Sync 类型（包含本对象以及 other 对象的所有类型）
            using MergedSync = zsibot::utils::merged_pack_type<Sync<Types...>, Sync<AnotherTypes...>>;
            MergedSync result;

            result += (*this);
            result += other;

            return result;
        }

    private:
        template <class T>
        auto makeSubInfo(details::ISubscriberBase<T>& existed_subscriber) const
        {
            return max_time_diff_ | existed_subscriber | msgs_buffer_size_;
        }

        template <class TTopic, template <class> class TCallbackPolicy>
        auto makeSubInfo(const details::TopicTrait<TTopic, TCallbackPolicy>& topic_trait) const
        {
            return max_time_diff_ | topic_trait | msgs_buffer_size_;
        }

        template <class T, bool MAX_TIME_DIFF_SET, bool BUFFER_SIZE_SET>
        auto makeSubInfo(details::SyncSubInfo<T, MAX_TIME_DIFF_SET, BUFFER_SIZE_SET> sub_info) const
        {
            if constexpr (MAX_TIME_DIFF_SET and BUFFER_SIZE_SET)
                return std::move(sub_info);
            else
            {
                details::SyncSubInfo<T> final_sub_info;
                final_sub_info.sub_ptr = std::move(sub_info.sub_ptr);

                // 设置一些策略，仅新传入的订阅信息无设置时设置它。
                if constexpr (not MAX_TIME_DIFF_SET)
                    final_sub_info.max_time_diff = max_time_diff_;
                else
                    final_sub_info.max_time_diff = sub_info.max_time_diff;

                if constexpr (not BUFFER_SIZE_SET)
                    final_sub_info.buffer_size = msgs_buffer_size_;
                else
                    final_sub_info.buffer_size = sub_info.buffer_size;

                return final_sub_info;
            }
        }

        template <class T>
        void add(details::SyncSubInfo<T> sub_info, bool is_optional)
        {
            static_assert(not zsibot::utils::is_different_from_v<T, Types...>);
            ZSIBOT_ASSERT(sub_info.sub_ptr != nullptr);

            // 设置是否必须
            sub_info.is_optional = is_optional;

            // 添加该订阅信息至对应类型的列表中
            auto key = sub_info.sub_ptr;
            getBase<T>().sub_info.insert_or_assign(key, std::move(sub_info));
        }

        /**
         * @return 指定类型的基类
         */
        template <class T>
        details::SyncBase<T>& getBase()
        {
            return *static_cast<details::SyncBase<T>*>(this);
        }

        template <class T>
        const details::SyncBase<T>& getBase() const
        {
            return *static_cast<details::SyncBase<T>*>(this);
        }

        // 对本类的其他签名特化可见
        template <class... AnotherTypes>
        friend class Sync;

        // 任由 SyncContext 对本类任意访问，以进行它的初始化
        template <class... AnotherTypes>
        friend class details::SyncContext;

        // 统一的最大可接受的时差（用于构造新同步策略）
        unit::Time max_time_diff_ = zsibotu::sec(-1);

        // 统一的历史队列大小（用于构造新同步策略）
        std::size_t msgs_buffer_size_ = 10;  // 默认为 10
    };
}  // namespace zsibot::rmw
