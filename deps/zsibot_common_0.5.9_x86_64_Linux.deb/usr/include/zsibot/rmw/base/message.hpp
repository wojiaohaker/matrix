//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <functional>
#include <memory>

#include "zsibot/rmw/base/header.hpp"


namespace zsibot::rmw
{
    struct MessageBase
    {
        // 消息头，描述该消息的来源、时间戳等信息
        Header header;
    };

    template <class T>
    struct Message : public MessageBase
    {
        // 数据实体
        T data;
        Message() = default;

        Message(T&& t)
            : T(std::move(t))
        {
        }
    };

    using MessageBasePtr = std::shared_ptr<MessageBase>;

    template <class T>
    using MessagePtr = std::shared_ptr<Message<T>>;

    template <class T>
    using MessageCallback = std::function<void(MessagePtr<T>)>;
}  // namespace zsibot::rmw
