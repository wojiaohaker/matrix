//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <chrono>
#include <cstdint>
#include <string>

/**
 * @brief  jszr rmw 所在在命名空间，包含了通信相关的操作
 */
namespace zsibot::rmw
{

    /**
     * @brief Msg header wrapper
     */
    struct Header
    {
        std::string                                        creator_name;  ///<<< 当前消息的创建者
        std::chrono::time_point<std::chrono::system_clock> timestamp;     ///<<< 消息创建的时间戳
        uint64_t                                           sequence = 0;  ///<<< 序号
        std::string                                        channel_name;  ///<<< 通道名称
    };

}  // namespace jszr::rmw
