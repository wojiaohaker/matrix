//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <cstdint>
#include <string>
#include <type_traits>
#include <typeinfo>

#include "zsibot/macro/fancier.hpp"

namespace zsibot::rmw
{

    namespace details
    {
        template <class>
        struct DefaultCallbackPolicy
        {
        };

        /**
         * @brief 创建临时订阅器的辅助类
         */
        template <class TTopic, template <class> class TCallbackPolicy>
        struct TopicTrait
        {
            std::string name;  ///<<< name
        };

        /**
         * @brief 用于萃取话题类型
         * @tparam TId
         * @tparam IS_CLASS
         */
        template <class TId, bool IS_CLASS = std::is_class_v<TId>>
        struct TopicIdTypeTrait
        {
            using Type = TId;  ///<<< 话题类型
        };

        /**
         * @brief 用于萃取话题类型
         * @tparam TId
         */
        template <class TId>
        struct TopicIdTypeTrait<TId, true>
        {
            using Type = TId*;  ///<<< 指针类型
        };

        /**
         *@brief 话题 ID 类型
         */
        template <typename TId>
        using TopicIdType = typename TopicIdTypeTrait<TId>::Type;


        /**
         * @brief 话题实现的模板封装
         * @tparam T 话题数据类型
         * @tparam TId 通道 ID 类型
         * @tparam ID_VALUE 通道 ID 值
         */
        template <class T, typename TId, TopicIdType<TId> ID_VALUE = TopicIdType<TId>()>
        struct TopicImpl
        {
            using DataType                         = T;                                           ///<<< 通道信息类型
            using IdType                           = TId;                                         ///<<< 通道 ID 类型
            constexpr static TopicIdType<TId> ID   = ID_VALUE;                                    ///<<< 通道 ID 值
            inline static std::string         name = typeid(TopicImpl<T, TId, ID_VALUE>).name();  ///<<< 本通道的统一名称

            /**
             * @brief 创建 ID 类型的 topic
             */
            template <class TAnotherId, TopicIdType<TAnotherId> AUTHOR_ID_VALUE = TopicIdType<TAnotherId>()>
            using As = TopicImpl<T, TAnotherId, AUTHOR_ID_VALUE>;

            /**
             * @brief 辅助订阅
             * @tparam TCallbackPolicy
             * @param local_name
             * @return
             */
            template <template <class> class TCallbackPolicy = DefaultCallbackPolicy>
            static auto sub(const std::string& local_name = name)
            {
                TopicTrait<TopicImpl, TCallbackPolicy> trait;
                trait.name = std::move(local_name);
                return trait;
            }
        };

    }  // namespace details


    /**
     * @brief 标识一个消息
     */
    template <class T, uint64_t ID_VALUE = 0>
    using Topic = details::TopicImpl<T, uint64_t, ID_VALUE>;

    namespace details
    {
        /**
         * @brief 概念： T 是一个 topic 类型
         */
        template <class T>
        using TopicClass = ZSIBOT_CONCEPT((std::is_same_v<T, TopicImpl<typename T::DataType, typename T::IdType, T::ID>>));


    }  // namespace details

}  // namespace zsibot::rmw

/**
 * @brief 定义一个 Topic 类型
 * @param _data_type_ Topic 的数据类型
 * @param _topic_type_ Topic 的实际类型名，同时为其产生一个标签，使之成为唯一类型
 */
#define ZSIBOT_TOPIC(_data_type_, _topic_type_)                                                                                            \
    namespace zsibot::topic::details                                                                                                       \
    {                                                                                                                                      \
        class JszrTopicTag##_topic_type_                                                                                                   \
        {                                                                                                                                  \
        };                                                                                                                                 \
    }                                                                                                                                      \
    using _topic_type_ = ::zsibot::rmw::Topic<_data_type_>::As<zsibot::topic::details::JszrTopicTag##_topic_type_>;
