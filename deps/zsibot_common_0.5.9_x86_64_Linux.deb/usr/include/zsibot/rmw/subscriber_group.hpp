#pragma once

#include <any>

#include "zsibot/container/timeliness.hpp"
#include "zsibot/macro.hpp"
#include "zsibot/rmw/abstract/i_sync_context.hpp"
#include "zsibot/rmw/group/observable.hpp"
#include "zsibot/thread_lock.hpp"

#include "zsibot/rmw/policy/direct_policy.hpp"
#include "zsibot/rmw/policy/latest_policy.hpp"
#include "zsibot/rmw/policy/optimal_policy.hpp"
#include "zsibot/rmw/policy/pool_policy.hpp"

namespace zsibot::rmw
{
    namespace details
    {
        /**
         * @brief 订阅组实现
         * @tparam TSyncPolicy 数据同步策略
         * @tparam TCallbackPolicy 回调策略
         * @tparam Types 订阅组消息类型
         */
        template <class TSyncPolicy, template <class> class TCallbackPolicy, class... Types>
        class SubscriberGroupImpl final : public zsibot::thread_lock::MutexLock
        {
            // 回调策略器
            using CallbackPolicy = TCallbackPolicy<MessageGroupPtr<Types...>>;

            // 同步策略器
            using SyncPolicy = TSyncPolicy;

            static_assert(zsibot::is<CallbackPolicyClass, CallbackPolicy>);
            static_assert(zsibot::is<SyncPolicyClass, SyncPolicy>);

            // 同步信息上下文
            using SyncContext = ::zsibot::rmw::details::SyncContext<Types...>;

        public:
            /**
             * @brief 用于创建别的策略的订阅组
             */
            template <class TAnotherSyncPolicy, template <class> class TAnotherCallbackPolicy = TCallbackPolicy>
            using With = SubscriberGroupImpl<TAnotherSyncPolicy, TAnotherCallbackPolicy, Types...>;

            template <class TAnotherSyncPolicy>
            using WithSyncPolicy = SubscriberGroupImpl<TAnotherSyncPolicy, TCallbackPolicy, Types...>;

            template <template <class> class TAnotherCallbackPolicy>
            using WithCallbackPolicy = SubscriberGroupImpl<TSyncPolicy, TAnotherCallbackPolicy, Types...>;

            SubscriberGroupImpl()
                : context_ptr_(std::make_unique<Context>())
            {
            }

            ZSIBOT_DECLARE_DEFAULT_MOVE(SubscriberGroupImpl);
            ZSIBOT_DECLARE_FORBIDDEN_COPY(SubscriberGroupImpl);

            /**
             * @brief 使用同步策略，初始化本订阅组的同步流程，但不会影响用户已经设置的回调。
             */
            template <class... SyncTypes>
            void init(Sync<SyncTypes...> sync)
            {
                ZSIBOT_SYNCHRONIZED(context_ptr_->sync_context)
                {
                    context_ptr_->sync_context.reset();
                    context_ptr_->sync_context.init(std::move(sync));
                }
            }

            /**
             * @brief 重置本订阅组的同步流程，但不会影响用户已经设置的回调。
             */
            void reset()
            {
                ZSIBOT_SYNCHRONIZED(context_ptr_->sync_context)
                {
                    context_ptr_->sync_context.reset();
                }
            }

            /**
             * @brief 注册一个回调。
             * @return 该回调的订阅信息，可以反向注销它。
             */
            Subscription subscribe(MessageGroupCallback<Types...> cb)
            {
                if (cb == nullptr)
                    return {};
                return context_ptr_->callback_policy.subscribe(std::move(cb));
            }

            /**
             * @brief 通过一个时效性容器，注册一个回调。
             * @return 该回调的订阅信息，可以反向注销它。
             */
            Subscription subscribe(Observable<Types...>& observable)
            {
                return subscribe(
                    [&observable](MessageGroupPtr<Types...> msg_group_ptr)
                    {
                        observable.write(std::move(msg_group_ptr));
                    });
            }

            /**
             * @brief 初始化本回调组，同时注册一个回调（也可以使用 Observable）。
             * @return 该回调的订阅信息，可以反向注销它。
             */
            template <class... SyncTypes, class TCallback>
            Subscription subscribe(Sync<SyncTypes...> sync, TCallback&& cb)
            {
                init(std::move(sync));
                return subscribe(std::forward<TCallback>(cb));
            }

            /**
             * @brief 注销指定回调
             */
            void unsubscribe(const Subscription& subscription)
            {
                context_ptr_->callback_policy.unsubscribe(subscription);
            }

            /**
             * @brief 取消全部回调，但不会重置监听器
             */
            void unsubscribeAll()
            {
                context_ptr_->callback_policy.unsubscribeAll();
            }

            CallbackPolicy& callbackPolicy()
            {
                return context_ptr_->callback_policy;
            }

            const CallbackPolicy& callbackPolicy() const
            {
                return context_ptr_->callback_policy;
            }

            SyncPolicy& syncPolicy()
            {
                return context_ptr_->sync_policy;
            }

            const SyncPolicy& syncPolicy() const
            {
                return context_ptr_->callback_policy;
            }

        private:

            struct Context
            {
                CallbackPolicy callback_policy;
                SyncPolicy sync_policy;
                // 同步上下文（订阅器及其回调函数）
                zsibot::thread_lock::MutexLockable<SyncContext> sync_context;

                Context()
                    : sync_context(&sync_policy, &callback_policy)
                {
                }

                ~Context()
                {
                    callback_policy.unSubscribeAll();
                }
            };
            // 上下文信息
            std::unique_ptr<Context> context_ptr_;
        };
    }  // namespace details

    /**
     * @brief 组合订阅器
     * @tparam Types 多种消息的类型
     * @note 可以使用 SubscriberGroup<...>::With< SyncPolicy, CallbackPolicy > 指定策略。
     */
    template <class... Types>
    using SubscriberGroup = details::SubscriberGroupImpl<optimal_policy, DirectCallbackPolicy, Types...>;
}  // namespace zsibot::rmw
