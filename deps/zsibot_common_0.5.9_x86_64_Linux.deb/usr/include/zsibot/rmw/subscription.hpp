//
// Created by kanonwy on 2024/12/16
//

#pragma once

#include <cstdint>
#include <sys/types.h>

namespace zsibot::rmw
{
    namespace details
    {
        class CallbackPolicyBase;
    }

    /**
     * @brief  订阅描述
     * @details 该类由回调策略控制生成
     */
    class Subscription
    {
    public:
        Subscription() = default;

        /**
         * @brief 获取策略 ID
         * @return
         */
        [[nodiscard]] uint64_t getPolicyId() const;

        /**
         * @brief 获取回调 ID
         * @return
         */
        [[nodiscard]] uint64_t getCallbackId() const;

        /**
         * @brief 订阅描述就绪
         * @return
         */
        [[nodiscard]] bool good() const;

        /**
         * @brief 订阅描述未就绪
         * @return
         */
        [[nodiscard]] bool bad() const;


    private:
        Subscription(uint64_t policy_id, uint64_t callback_id);
        friend class details::CallbackPolicyBase;

        uint64_t policy_id_   = 0;  ///<<< 策略 ID
        uint64_t callback_id_ = 0;  ///<<< 回调 ID
    };


}  // namespace jszr::rmw
