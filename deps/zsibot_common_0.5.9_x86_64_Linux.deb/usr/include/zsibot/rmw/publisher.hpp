//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>

#include "zsibot/macro/construct_declare.hpp"
#include "zsibot/macro/fancier.hpp"
#include "zsibot/rmw/abstract/i_interface.hpp"
#include "zsibot/rmw/base/header.hpp"
#include "zsibot/rmw/rmw_base.hpp"
#include "zsibot/rmw/topic.hpp"

namespace zsibot::rmw
{
    namespace details
    {

        /**
         * @brief 发布器抽象接口类
         */
        template <class DT>
        class IPublisherSender
        {
        public:
            virtual ~IPublisherSender() = default;
            /**
             * @brief 发布抽象接口
             * @param data
             * @return
             */
            virtual bool publish(const DT& data) = 0;

            /**
             * @brief 发布抽象接口
             * @param data
             * @param timestamp
             * @return
             */
            virtual bool publish(const DT& data, const std::chrono::time_point<std::chrono::system_clock>& timestamp) = 0;
        };
    }  // namespace details

    /**
     * @brief 发布器上下行转换的抽象接口类
     */
    class PublisherBase
    {
    public:
        virtual ~PublisherBase() = default;
        /**
         * @brief  初始化虚函数接口
         * @return
         */
        [[nodiscard]] virtual bool init() = 0;
        /**
         * @brief  初始化虚函数接口
         * @param topic_name
         * @return
         */
        [[nodiscard]] virtual bool init(const std::string& topic_name) = 0;

        /**
         * @brief 重置虚函数接口
         */
        virtual void reset() = 0;


        /**
         * @brief 发布接口
         * @tparam DT
         * @param data
         * @return
         */
        template <class DT>
        bool publish(const DT& data)
        {
            if (auto* ptr = dynamic_cast<details::IPublisherSender<DT>*>(this); nullptr != ptr)
            {
                return ptr->publish(data);
            }
            return false;
        }

        /**
         * @brief 发布接口
         * @tparam DT
         * @param data
         * @param timestamp
         * @return
         */
        template <class DT>
        bool publish(const DT& data, const std::chrono::time_point<std::chrono::system_clock>& timestamp)
        {
            if (auto* ptr = dynamic_cast<details::IPublisherSender<DT>*>(this); nullptr != ptr)
            {
                return ptr->publish(data, timestamp);
            }
            return false;
        }
    };


    /**
     * @brief  发布器
     * @tparam TTopic topic 的范型
     */
    template <class TTopic>
    class Publisher : public PublisherBase, public details::IPublisherSender<typename TTopic::DataType>
    {
    public:
        using DataType = typename TTopic::DataType;  ///<<< 发布器数据类型
        static_assert(zsibot::is<details::TopicClass, TTopic>, "TTopic must be type of TTopic");

        Publisher()
            : context_ptr_(std::make_unique<PublisherContext>())
        {
        }

        ~Publisher() override
        {
            reset();
        }

        /**
         * @brief 默认移动
         */
        ZSIBOT_DECLARE_DEFAULT_MOVE(Publisher);
        /**
         * @brief 禁止拷贝
         */
        ZSIBOT_DECLARE_FORBIDDEN_COPY(Publisher);

        /**
         * @brief 初始化
         * @return
         */
        [[nodiscard]] bool init() final
        {
            return init(TTopic::name);
        }

        /**
         * @brief 发布器初始化
         * @param topic_name
         * @return
         * @details 返回值必须被处理
         */
        [[nodiscard]] bool init(const std::string& topic_name) final
        {
            return tryInit(topic_name, true);
        }

        /**
         * @brief 重置实现
         */
        void reset() final
        {
            is_init_ = false;
            if (!context_ptr_)
                return;
            {
                std::unique_lock lk(mt_);
                context_ptr_->impl_ptr   = nullptr;
                context_ptr_->topic_name = {};
            }
        }

        /**
         * @brief 设置通信方式
         * @param mode 通信方式枚举
         */
        void setMode(zsibot::rmw::CommunicationMode mode)
        {
            context_ptr_->impl_ptr->setmode(mode);
        }

        /**
         * @brief 发布数据
         * @param data 需要发布的数据类型
         */
        bool publish(const DataType& data) final
        {
            // TODO: call tryInit is to heavy. maybe use atomic can reduce
            if (!tryInit(TTopic::name, false))
            {
                return false;
            }
            // TODO: 多个线程发布是否线程安全
            return context_ptr_->impl_ptr->publish(context_ptr_->topic_name, newHeader(), data);
        }

        /**
         * @brief 发布数据
         * @todo 这里有很多优化的空间，如果能够做到到底层的 DDS 没有性能损失就更好了
         */
        bool publish(const DataType& data, const std::chrono::time_point<std::chrono::system_clock>& timestamp) final
        {

            if (!tryInit(TTopic::name, false))
            {
                return false;
            }

            return context_ptr_->impl_ptr->publish(context_ptr_->topic_name, newHeader(timestamp), data);
        }


    private:
        /**
         * @brief 构建应用层消息头
         * @param timestamp 支持传入时间戳
         * @return
         */
        Header newHeader(std::chrono::time_point<std::chrono::system_clock> timestamp)
        {
            return { .creator_name = "", .timestamp = timestamp, .sequence = ++context_ptr_->sequence, .channel_name = "" };
        }

        Header newHeader()
        {
            return {
                .creator_name = "", .timestamp = std::chrono::system_clock::now(), .sequence = ++context_ptr_->sequence, .channel_name = ""
            };
        }


        bool tryInit(const std::string& topic_name, bool is_reset)
        {
            if (is_init_ and not is_reset)
            {
                return true;
            }
            {
                // TODO: use lock
                std::unique_lock lk(mt_);
                context_ptr_->impl_ptr = nullptr;
                if (topic_name.empty())
                    return false;
                context_ptr_->impl_ptr = details::createPublisher<TTopic>(topic_name);
                if (nullptr == context_ptr_->impl_ptr)
                {
                    return false;
                }
                context_ptr_->topic_name = topic_name;
                is_init_                 = true;
            }
            return is_init_;
        }


        struct PublisherContext
        {
            std::string                     topic_name{};
            std::atomic<uint64_t>           sequence{ 0 };
            details::PublisherPtr<DataType> impl_ptr;
        };

        std::atomic_bool                  is_init_ = false;
        std::unique_ptr<PublisherContext> context_ptr_;
        mutable std::mutex                mt_;
    };


}  // namespace zsibot::rmw
//
