//
// Created by kanonwy on 2024/12/16
//

#pragma once

/**
 * @brief 创建发布器的特化函数的实现
 * @param _topic_ 话题类型
 * @param _method_ 发布器的底层实现方式 eCAL/ROS2/FastDDS
 */
#define ZSIBOT_IMPL_TOPIC_PUB(_topic_, _method_)                                                                                             \
    namespace zsibot::rmw::details                                                                                                           \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        PublisherPtr<_topic_::DataType> createPublisher<_topic_>(const std::string& topic_name)                                            \
        {                                                                                                                                  \
            return zsibot::rmw::_method_::createPublisher<_topic_::DataType>(topic_name);                                                    \
        }                                                                                                                                  \
    }

/**
 * @brief 创建订阅器的特化函数的实现
 * @param _topic_ 话题类型
 * @param _method_ 订阅器的底层实现方式 eCAL/ROS2/FastDDS
 */
#define ZSIBOT_IMPL_TOPIC_SUB(_topic_, _method_)                                                                                             \
    namespace zsibot::rmw::details                                                                                                           \
    {                                                                                                                                      \
        template <>                                                                                                                        \
        SubscriberPtr<_topic_::DataType> createSubscriber<_topic_>(const std::string& topic_name)                                          \
        {                                                                                                                                  \
            return zsibot::rmw::_method_::createSubscriber<_topic_::DataType>(topic_name);                                                   \
        }                                                                                                                                  \
    }


/**
 * @brief 创建对应话题订阅器和发布器的特化函数实现
 * @param _topic_ 话题类型
 * @param _method_ 发布器和订阅器的底层实现 eCAL/ROS2
 */
#define ZSIBOT_IMPL_TOPIC(_topic_, _method_)                                                                                                 \
    ZSIBOT_IMPL_TOPIC_SUB(_topic_, _method_)                                                                                                 \
    ZSIBOT_IMPL_TOPIC_PUB(_topic_, _method_)
