//
// Created by kanonwy on 2025/04/14
//

#pragma once

namespace zenoh
{
    class Session;
}

namespace zsibot::rmw
{

    /**
     * @brief 中间件上下文，用于保存一些中间件的配置状态和句柄
     */
    struct RmwContext
    {
        virtual ~RmwContext() = default;
        virtual void initialize() {}

        virtual ::zenoh::Session* session()
        {
            return nullptr;
        }
        virtual void finalize() {}
    };
}  // namespace jszr::rmw