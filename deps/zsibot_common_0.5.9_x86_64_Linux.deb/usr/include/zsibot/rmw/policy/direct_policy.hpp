//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <cstdint>
#include <functional>
#include <map>
#include <mutex>

#include "zsibot/rmw/abstract/i_callback_policy.hpp"

namespace zsibot::rmw
{

    /**
     * @brief 直接调用策略
     * @tparam T 消息类型
     * @details 如果底层 DDS 支持多线程，以及回调线程不会阻塞接收的情况下可直接使用该策略
     *       此策略也是默认的订阅策略
     */
    template <typename T>
    class DirectCallbackPolicy final : public details::ICallbackPolicy<T>
    {
    public:
        /**
         * @brief 取消所有订阅
         */
        void unSubscribeAll() override
        {
            std::unique_lock lk(mt_);
            callback_funcs_.clear();
        }

        /**
         * @brief 直接执行所有的回调函数
         * @note
         *    多个回调函数之间会相互阻塞
         */
        void call(T msg) override
        {
            std::unique_lock lk(mt_);
            for (auto& [id, cb] : callback_funcs_)
            {
                cb(msg);
            }
        }

        Subscription onSubscribe(std::function<void(T)> cb) override
        {
            std::unique_lock lk(mt_);
            uint64_t         id = ++call_back_id_;
            callback_funcs_.insert_or_assign(id, std::move(cb));
            return details::CallbackPolicyBase::createSubscription(id);
        }

        void onUnSubscribe(const Subscription& subscription) override
        {
            std::unique_lock lk(mt_);
            callback_funcs_.erase(subscription.getPolicyId());
        }


    private:
        mutable std::mutex                         mt_;
        uint64_t                                   call_back_id_ = 0;
        std::map<uint64_t, std::function<void(T)>> callback_funcs_;
    };


}  // namespace jszr::rmw
