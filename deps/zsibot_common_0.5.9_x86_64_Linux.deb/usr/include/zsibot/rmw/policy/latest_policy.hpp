#pragma once

#include "zsibot/container/expected.hpp"
#include "zsibot/rmw/abstract/i_sync_policy.hpp"
#include "zsibot/thread_lock.hpp"

namespace zsibot::rmw
{
    class LatestPolicy : public details::ISyncPolicy, public zsibot::thread_lock::MutexLock
    {
    public:
        bool beginSync(const MessageBasePtr&) override;

        zsibotc::expected<MessageBasePtr> syncOne(const MessageBasePtr& new_msg, Data& data) override;

        details::SyncResult endSync(bool sync_status, const MessageBasePtr&) override;
    };
}  // namespace jszr::rmw
