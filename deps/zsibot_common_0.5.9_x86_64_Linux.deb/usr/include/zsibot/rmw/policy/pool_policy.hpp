#pragma once

#include "zsibot/rmw/abstract/i_callback_policy.hpp"
#include "zsibot/rmw/policy/thread_pool.hpp"

namespace zsibot::rmw
{

    /**
     * @brief 池回调策略
     * @tparam T 消息类型
     */
    template <class T>
    class PoolCallbackPolicy final : public details::ICallbackPolicy<T>, public zsibot::thread_lock::MutexLock
    {
    public:
        PoolCallbackPolicy()
        {
            pool_ = std::make_unique<ThreadPool>();
        }

        void unSubscribeAll() override
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                callbacks_.clear();
            }
        }


        void call(T msg_ptr) override
        {
            if ((buffer_size_ != static_cast<std::size_t>(-1)) && (getBufferSize() >= buffer_size_))
            {
                return;
            }

            try
            {
                ZSIBOT_SYNCHRONIZED(this)
                {
                    for (auto& [id, cb] : callbacks_)
                    {
                        (void)id;
                        pool_->add(
                            [cp_cb = cb, msg_ptr]()
                            {
                                cp_cb(msg_ptr);
                            });
                    }
                }
            }
            catch (std::exception& e)
            {
                std::cerr << "PoolPolicy::call exception: " << e.what() << std::endl;
            }
        }

        void setCoreThreads(std::size_t core_threads) const
        {
            pool_->setCoreThreadSize(core_threads);
        }

        void setMaxThreads(std::size_t max_threads) const
        {
            pool_->setMaxThreadSize(max_threads);
        }

        // 设置池中队列的大小，要注意如果存在多个订阅者的情况，这个值会被多个订阅者共享
        void setBufferSize(std::size_t size)
        {
            buffer_size_ = size;
        }

        std::size_t getCoreThreads() const
        {
            return pool_->getCoreThreadSize();
        }

        std::size_t getMaxThreads() const
        {
            return pool_->getMaxThreadSize();
        }

        // 获取池中队列的大小
        std::size_t getBufferSize() const
        {
            return pool_->getCurrentQueueSize();
        }

    protected:
        Subscription onSubscribe(std::function<void(T)> cb) override
        {
            uint64_t id = ++callback_id_;
            ZSIBOT_SYNCHRONIZED(this)
            {
                callbacks_.insert_or_assign(id, std::move(cb));
            }
            return details::CallbackPolicyBase::createSubscription(id);
        }

        void onUnSubscribe(const Subscription& subscription) override
        {
            ZSIBOT_SYNCHRONIZED(this)
            {
                callbacks_.erase(subscription.getCallbackId());
            }
        }

    private:
        // 用户设置的buffer大小，这个buffer是用限制放入线程池的任务数量，不至于线程池队列任务爆满，默认为-1，表示不限制
        std::size_t buffer_size_ = -1;

        // 线程池
        std::unique_ptr<ThreadPool> pool_;

        // 递增的回调者 id
        std::atomic<uint64_t> callback_id_ = 0;

        // 由回调者 id 索引的所有回调函数
        std::map<uint64_t, std::function<void(T)>> callbacks_;
    };
}  // namespace zsibot::rmw
