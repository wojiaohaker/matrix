#pragma once

#include "zsibot/container/expected.hpp"
#include "zsibot/rmw/abstract/i_sync_policy.hpp"
#include "zsibot/thread_lock.hpp"
#include "zsibot/unit/time.hpp"

namespace zsibot::rmw
{
    /**
     * @brief  most optimal policy
     */
    class optimal_policy final : public details::ISyncPolicy, public zsibot::thread_lock::MutexLock
    {
    public:
        void beginInit() override;

        void initOne(const Data& data) override;

        void endInit() override;

        bool beginSync(const MessageBasePtr& new_msg) override;

        zsibotc::expected<MessageBasePtr> syncOne(const MessageBasePtr& new_msg, Data& data) override;

        details::SyncResult endSync(bool sync_status, const MessageBasePtr& new_msg) override;

        bool setMainTopic(const std::string& topic);

        std::string getMainTopic() const;

        bool setMaxTimeDiff(const zsibot::unit::Time& max_time_diff);

        zsibot::unit::Time getMaxTimeDiff() const;

    private:
        std::string                                        main_topic_;
        zsibot::unit::Time                                   max_time_diff_ = zsibotu::sec(-1);  // 可接受的时差（为负时，认为不再检查时差）
        std::atomic<bool>                                  init_state_{ false };             // 是否初始化完成
        std::atomic<bool>                                  begin_sync_{ false };       // 是否开始同步，当主传感器数据到来时，才开始同步
        std::atomic<bool>                                  wait_other_{ false };       // 等待其他必要的topic
        std::atomic<bool>                                  new_msg_arrives_{ false };  // 在同步过程中是否有新消息到来
        std::chrono::time_point<std::chrono::system_clock> wait_time_;                 // 等待其他topic开始的时间
    };
}  // namespace zsibot::rmw
