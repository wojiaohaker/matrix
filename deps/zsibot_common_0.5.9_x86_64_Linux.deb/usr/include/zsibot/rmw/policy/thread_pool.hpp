#pragma once

#include <algorithm>
#include <functional>
#include <future>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <unordered_map>

namespace zsibot::rmw
{

    class ThreadPool
    {
        using task        = std::function<void()>;
        using threads_map = std::unordered_map<std::thread::id, std::thread>;
        bool                    shutdown_;
        std::size_t             max_threads_;
        std::size_t             core_threads_;
        std::size_t             queue_pending_;
        std::size_t             queue_max_size_ = -1;
        std::atomic<int>        idle_threads_{ 0 };
        std::atomic<uint32_t>   threads_id_{ 0 };
        std::condition_variable cv_;
        std::mutex              queue_mutex_;
        std::mutex              threads_mutex_;
        std::queue<task>        queue_;
        threads_map             threads_;

        void create()
        {
            auto thread = std::thread(
                [this]()
                {
                    while (true)
                    {
                        std::unique_lock<std::mutex> lock(queue_mutex_);
                        cv_.wait(lock,
                            [this]()
                            {
                                return ((shutdown_) || (!queue_.empty()) || ((size_t)idle_threads_ >= core_threads_));
                            });
                        if (shutdown_ && queue_.empty())
                        {
                            return;
                        }

                        if (queue_.empty())
                        {
                            /* task queue is empty , and idle thread is too much, need to destroy */
                            if (((size_t)idle_threads_ >= core_threads_) && (!shutdown_))
                            {
                                destroy(std::this_thread::get_id());
                                return;
                            }
                        }

                        /* the task is about to start working, consuming an idle thread, if idle_threads_ > 0 */
                        if (idle_threads_ > 0)
                            --idle_threads_;

                        auto task = queue_.front();
                        queue_.pop();
                        lock.unlock();   // unlock queue mutex
                        task();          /* do work, the task pointer will be destroyed when the work is completed */
                        ++idle_threads_; /* task has been completed, get a idle thread */
                    }
                });

            /* set affinity */
            cpu_set_t cpu_set;
            CPU_ZERO(&cpu_set);
            CPU_SET((threads_id_ % std::thread::hardware_concurrency()), &cpu_set);
            pthread_setaffinity_np(thread.native_handle(), sizeof(cpu_set_t), &cpu_set);
            ++threads_id_;

            /* once the thread is created, the idle_threads_ variable will be incremented by 1 */
            ++idle_threads_;
            threads_[thread.get_id()] = std::move(thread);
        }

        void destroy(std::thread::id id)
        {
            queue_.emplace(
                [this, id]()
                {
                    if (!shutdown_)
                    {
                        /* destroy the worker thread, and reduce the idle_threads_ variable by 1 */
                        std::lock_guard<std::mutex> lock(threads_mutex_);
                        if (threads_[id].joinable())
                        {
                            threads_[id].join();
                        }
                        threads_.erase(id);
                        if (idle_threads_ > 0)
                            --idle_threads_;
                    }
                });
        }

    public:
        explicit ThreadPool(std::size_t max_sz        = 1 + std::thread::hardware_concurrency(),
            std::size_t        core_size     = std::thread::hardware_concurrency() / 2,
            std::size_t        queue_pending = std::thread::hardware_concurrency())
            : shutdown_(false),
              max_threads_(max_sz),
              core_threads_(core_size),
              queue_pending_(queue_pending)
        {
            if (core_threads_ > max_threads_ || max_threads_ == 0)
            {
                throw std::logic_error("please make sure: core_size <= max_size && max_sz > 0\n");
            }
        }

        ~ThreadPool()
        {
            shutdown_ = true;
            cv_.notify_all();
            std::for_each(threads_.begin(), threads_.end(),
                [](threads_map::value_type& x)
                {
                    if ((x.second).joinable())
                    {
                        (x.second).join();
                    }
                });

            // clear queue_
            std::queue<task> empty;
            std::swap(queue_, empty);
        }

        void setCoreThreadSize(std::size_t size)
        {
            if (size > max_threads_)
            {
                core_threads_ = max_threads_;
            }

            core_threads_ = size;
        }

        void setMaxThreadSize(std::size_t size)
        {
            if (max_threads_ >= 1 + std::thread::hardware_concurrency())
            {
                max_threads_ = 1 + std::thread::hardware_concurrency();
            }
            max_threads_ = size;
        }

        void setMaxQueueSize(std::size_t size)
        {
            queue_max_size_ = size;
        }

        void setQueuePendingSize(std::size_t size)
        {

            if ((queue_max_size_ != (std::size_t)-1) && (size > queue_max_size_))
            {
                queue_pending_ = queue_max_size_;
            }

            queue_pending_ = size;
        }

        std::size_t getCoreThreadSize() const
        {
            return core_threads_;
        }

        std::size_t getMaxThreadSize() const
        {
            return max_threads_;
        }

        std::size_t getMaxQueueSize() const
        {
            return queue_max_size_;
        }

        std::size_t getQueuePendingSize() const
        {
            return queue_pending_;
        }

        std::size_t getIdleThreadSize() const
        {
            return idle_threads_;
        }

        std::size_t getCurrentQueueSize() const
        {
            return queue_.size();
        }

        std::size_t getCurrentThreadSize() const
        {
            return threads_.size();
        }


        template <typename Func, typename... Args>
        auto add(Func&& f, Args&&... args) -> std::future<decltype(f(args...))>
        {
            if ((shutdown_) || ((queue_max_size_ != (std::size_t)-1) && (queue_.size() > queue_max_size_)))
            {
                throw std::runtime_error("thread pool has been shutdown or the task queue is full\n");
            }

            std::function<decltype(f(args...))()> func = std::bind(std::forward<Func>(f), std::forward<Args>(args)...);
            // encapsulate it into a shared ptr in order to be able to copy construct / assign
            auto task   = std::make_shared<std::packaged_task<decltype(f(args...))()>>(func);
            auto result = task->get_future();
            {
                std::lock_guard<std::mutex> lock(queue_mutex_);
                queue_.emplace(
                    [task]()
                    {
                        (*task)();
                    });
            }

            if ((idle_threads_ == 0) && (threads_.size() < max_threads_)
                && ((threads_.size() <= core_threads_) || (queue_.size() > queue_pending_)))
            {
                create();
                if (idle_threads_ > 0)
                    --idle_threads_;
            }

            cv_.notify_one(); /* notify a thread do work */
            return result;
        }

        void info() const
        {
            std::cout << "----------------------------------------\n"
                      << "\t queue size:" << queue_.size() << '\n'
                      << "\t thread size:" << threads_.size() << '\n'
                      << "\t idle threads:" << idle_threads_ << std::endl;
        }
    };

}  // namespace jszr::rmw
