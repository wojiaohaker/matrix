//
// Created by kanonwy on 2024/12/16
//

#pragma once

#include <type_traits>

#include "zsibot/macro/base_macro.hpp"

namespace zsibot::rmw::ecal::details
{

    /**
     * @brief  使用模板编程来实现部分的 concept 能力
     * @tparam Default
     * @tparam AlwaysVoid
     * @tparam Op
     * @tparam Args
     */
    template <class Default, class AlwaysVoid, template <class...> class Op, class... Args>
    struct Detector
    {
        using value = std::false_type;
        using type  = Default;
    };

    /**
     * @brief  使用模板编程来实现部分的 concept 能力
     * @tparam Default
     * @tparam Op
     * @tparam Args
     */
    template <class Default, template <class...> class Op, class... Args>
    struct Detector<Default, std::void_t<Op<Args...>>, Op, Args...>
    {
        using value = std::true_type;
        using type  = Op<Args...>;
    };

    /**
     * @brief 辅助类
     */
    struct NoSuch
    {
        ~NoSuch()                        = delete;
        NoSuch(const NoSuch&)            = delete;
        NoSuch& operator=(const NoSuch&) = delete;
    };

    template <template <class...> class Op, class... Args>
    using is_detected = typename Detector<NoSuch, void, Op, Args...>::value;


/**
 * @brief 生成检查指定函数是否存在的模版推导
 */
#define CHECK_FUNC(_func_name_)                                                                                                            \
    template <typename T>                                                                                                                  \
    using Has##_func_name_ = decltype(std::declval<T>()._func_name_())

/**
 * @brief 生成检查指定函数的下层调用是否存在
 */
#define CHECK_FUNC_LAY_1(_lay_name_, _member_name_)                                                                                        \
    template <typename T>                                                                                                                  \
    using Has##_member_name_ = decltype(std::declval<T>()._lay_name_()._member_name_())


    /**
     * @brief header 函数存在性辅助
     */
    struct HeaderDetector
    {
        CHECK_FUNC(header);
        CHECK_FUNC_LAY_1(header, channel_name);
        CHECK_FUNC_LAY_1(header, creator_name);
        CHECK_FUNC_LAY_1(header, sec);
        CHECK_FUNC_LAY_1(header, nsec);
        CHECK_FUNC_LAY_1(header, sequence);
    };

#define HAS_MEMBER(_member_)                                                                                                               \
    template <typename T>                                                                                                                  \
    constexpr bool static Has##_member_##_v = is_detected<HeaderDetector::Has##_member_, T>::value

    HAS_MEMBER(header);
    HAS_MEMBER(channel_name);
    HAS_MEMBER(creator_name);
    HAS_MEMBER(sec);
    HAS_MEMBER(nsec);
    HAS_MEMBER(sequence);

}  // namespace jszr::rmw::ecal::details
