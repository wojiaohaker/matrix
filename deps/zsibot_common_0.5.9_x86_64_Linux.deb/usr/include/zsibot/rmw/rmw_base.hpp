#pragma once

namespace zsibot::rmw
{
    /**
     * @brief 通信方式枚举
     */
    enum class CommunicationMode
    {
        // UDP 广播
        UDP_MC,
        // TCP
        TCP,
        // 进程内
        IN_PROC,
        // 共享内存
        SHM,
    };
}  // namespace jszr::rmw