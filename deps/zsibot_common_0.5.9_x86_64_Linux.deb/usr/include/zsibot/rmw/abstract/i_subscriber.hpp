//
// Created by kanonwy on 2024/12/13
//
#pragma once

#include "zsibot/rmw/base/message.hpp"

namespace zsibot::rmw::details
{
    /**
     * @brief  订阅器抽象基类
     * @tparam T 当前订阅器对应的消息类型
     */
    template <typename T>
    class ISubscriber
    {
    public:
        /**
         * @brief 订阅抽象接口
         * @param cb
         * @return
         */
        virtual bool subscribe(MessageCallback<T> cb) = 0;
        virtual ~ISubscriber()                        = default;
    };
}  // namespace jszr::rmw::details
