//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <type_traits>

#include "zsibot/macro.hpp"
#include "zsibot/rmw/subscription.hpp"

namespace zsibot::rmw::details
{

    class CallbackPolicyBase
    {
    public:
        CallbackPolicyBase();

    protected:
        /**
         * @brief 创建订阅器描述
         * @param callback_id
         * @return
         */
        [[nodiscard]] Subscription createSubscription(uint64_t callback_id) const;

        /**
         * @brief 给定的回调订阅是否有本策略产生
         */
        [[nodiscard]] bool isMatched(const Subscription& subscription) const;


    private:
        const uint64_t                     policy_id_;             ///<<< 回调策略 ID
        inline static std::atomic_uint64_t global_policy_id_ = 0;  ///<<< 全局回调策略 ID，用于控制策略 ID 生成
    };

    /**
     * @brief 消息回调处理策略的抽象接口
     * @tparam T 当前策略处理的消息类型
     * @details 回调策略需要实现该类中的抽象接口
     */
    template <typename T>
    class ICallbackPolicy : public CallbackPolicyBase
    {
    public:
        using MessageType = T;

        virtual ~ICallbackPolicy() = default;
        /**
         * @brief 订阅
         */
        Subscription subscribe(std::function<void(T)> cb)
        {
            if (nullptr == cb)
            {
                return {};
            }
            return onSubscribe(std::move(cb));
        }

        /**
         * @brief 取消订阅
         */
        void unSubscribe(const Subscription& subscription)
        {
            if (not isMatched(subscription))
                return;
            onUnSubscribe(subscription);
        }

        virtual void call(T msg) = 0;

        virtual void unSubscribeAll() = 0;

    protected:
        /**
         * @brief  订阅抽象接口
         * @param cb
         * @return
         */
        virtual Subscription onSubscribe(std::function<void(T)> cb) = 0;

        /**
         * @brief  取消订阅抽象接口
         * @param subscription 订阅描述
         */
        virtual void onUnSubscribe(const Subscription& subscription) = 0;
    };

    /**
     * @brief 概念, T 是一个 call back policy
     */
    template <typename T>
    using CallbackPolicyClass = ZSIBOT_CONCEPT((std::is_base_of_v<ICallbackPolicy<typename T::MessageType>, T>));

}  // namespace jszr::rmw::details
