#pragma once

#include <type_traits>

#include "zsibot/container/buffer.hpp"
#include "zsibot/container/expected.hpp"
#include "zsibot/macro.hpp"
#include "zsibot/rmw/base/message.hpp"
#include "zsibot/unit.hpp"

namespace zsibot::rmw::details
{
    /**
     * @brief 同步策略上下文的前置声明
     */
    template <class... Types>
    class SyncContext;

    /**
     * @brief 同步结果
     */
    enum class SyncResult
    {
        Failure,    ///<<< 同步失败
        Success,    ///<<< 同步成功
        Retry,      ///<<< 需要重新同步
        Ignorable,  ///<<< 同步失败，但是可以忽略
    };


    /**
     * @brief 同步策略抽象类
     */
    class ISyncPolicy
    {
    public:
        struct Data
        {
            std::string topic_name;
            // 可接受的时差（为负时，认为不再检查时差）
            zsibot::unit::Time max_time_diff;
            // 消息缓存大小
            std::size_t buffer_size = 1;
            // 本消息是否可选
            bool is_optional = false;
            // 接收到的消息队列
            zsibotc::buffer<MessageBasePtr> msgs;
        };

        /**
         * @brief 通知初始化开始，将逐一初始化每一个消息来源
         * @note 在同一个订阅组内的同步策略可以保证同时只有一个初始化流程在进行，并与重置流程互斥。
         */
        virtual void beginInit() {}

        /**
         * @brief 初始化一个消息来源
         * @param data 该消息来源的可分析数据
         */
        virtual void initOne(const Data& data)
        {
            ZSIBOT_UNUSED(data);
        }

        /**
         * @brief 通知初始化结束
         */
        virtual void endInit() {}

        /**
         * @brief 通知重置开始，将逐一重置每一个消息来源
         * @note 在同一个订阅组内的同步策略可以保证同时只有一个重置流程在进行，并与初始化流程互斥。
         */
        virtual void beginReset() {}

        /**
         * @brief 重置一个消息来源
         * @param data 该消息来源的可分析数据
         */
        virtual void resetOne(const Data& data)
        {
            ZSIBOT_UNUSED(data);
        }

        /**
         * @brief 通知重置结束
         */
        virtual void endReset() {}

        /**
         * @brief 通知新消息到达，询问是否进行同步
         * @param new_msg 触发本次查询的、新接收到的消息
         * @return
         *   @retval true 开始进行同步
         *   @retval false 当前不同步
         */
        virtual bool beginSync(const MessageBasePtr& new_msg) = 0;

        /**
         * @brief 分析给定的数据，得出符合条件的消息，或者产生错误，
         * 若返回错误，将停止同步过程。
         * @param new_msg 触发本次同步的、新接收到的消息
         * @param data 某个来源的、可分析的数据
         * @return
         *   @retval jszrc::expected_value<MessageBasePtr> 被选中的消息，也可以是空指针（代表没有命中，但不至于终止同步）
         *   @retval jszrc::expected_error<> 同步终止
         */
        virtual zsibotc::expected<MessageBasePtr> syncOne(const MessageBasePtr& new_msg, Data& data) = 0;

        virtual SyncResult endSync(bool sync_status, const MessageBasePtr& new_msg) = 0;

        virtual ~ISyncPolicy() = default;

    protected:
        /**
         * @brief 手动触发同步过程，将在该函数中，执行同步流程
         * @param fake_new_msg 假装是新接收到的消息，将传入到同步流程中使用
         * @note 子类实现需要处理好线程安全、锁等相关问题
         */
        void manualSync(MessageBasePtr fake_new_msg = {}) const;

    private:
        template <class... Types>
        friend class details::SyncContext;

        /**
         * @brief 由 SyncContext 调用的，设置用于触发它同步过程的接口
         */
        void setManualSyncHandler(std::function<void(MessageBasePtr)> handler);

        // 用于主动触发同步
        std::function<void(MessageBasePtr)> manual_sync_handler_;
    };

    /**
     * @brief 概念：类型 T 是一个 sync policy 类型
     * @tparam T
     */
    template <class T>
    using SyncPolicyClass = ZSIBOT_CONCEPT((std::is_base_of_v<ISyncPolicy, T>));
}  // namespace jszr::rmw::details
