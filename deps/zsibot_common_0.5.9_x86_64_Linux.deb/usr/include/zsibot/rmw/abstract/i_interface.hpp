//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include "zsibot/rmw/abstract/i_publisher.hpp"
#include "zsibot/rmw/abstract/i_subscriber.hpp"
#include "zsibot/rmw/rmw_context.hpp"

#include <memory>

/**
 * @brief jszr rmw 模板的一些实现细节
 */
namespace zsibot::rmw::details
{
    /**
     * @brief 发布器基类指针
     */
    template <typename T>
    using PublisherPtr = std::unique_ptr<IPublisher<T>>;


    /**
     * @brief 订阅器基类指针
     */
    template <typename T>
    using SubscriberPtr = std::unique_ptr<ISubscriber<T>>;


    /**
     * @brief 创建指定类型发布器
     * @tparam TTopic 具体的 topic 类型
     * @param topic_name 构建该发布器的通道名称
     * @note
     *      此为外部模板，实际实现在别处
     */
    template <typename TTopic>
    extern PublisherPtr<typename TTopic::DataType> createPublisher(const std::string& topic_name);



    /**
     * @brief 创建指定类型的订阅器
     * @tparam TTopic 具体的 topic 类型
     * @param topic_name 构建该订阅器的通道类型
     * @note
     *      此为外部模板，实际实现在别处
     */
    template <typename TTopic>
    extern SubscriberPtr<typename TTopic::DataType> createSubscriber(const std::string& topic_name);


    template <typename T>
    extern PublisherPtr<T> createPublisher(const std::string& topic_name, zsibot::rmw::RmwContext* ctx);


    template <typename T>
    extern SubscriberPtr<T> createSubscriber(const std::string& topic_name, zsibot::rmw::RmwContext* ctx);

}  // namespace zsibot::rmw::details
