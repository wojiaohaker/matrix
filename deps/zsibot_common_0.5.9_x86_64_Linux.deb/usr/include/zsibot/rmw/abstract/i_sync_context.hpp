#pragma once

#include <list>
#include <vector>

#include "zsibot/container/buffer.hpp"
#include "zsibot/container/expected.hpp"
#include "zsibot/rmw/abstract/i_sync_policy.hpp"
#include "zsibot/rmw/base/message.hpp"
#include "zsibot/rmw/group/sync.hpp"
#include "zsibot/thread_lock.hpp"
#include "zsibot/utils.hpp"

namespace zsibot::rmw::details
{


    /**
     * @brief 上下文存储
     * @tparam Types
     * @TODO 支持 Types 的类型重复
     */
    template <class... Types>
    class SyncContextBase;

    template <class T>
    class SyncContextBase<T>
    {
    public:
        /**
         * @brief 订阅器信息
         */
        struct SubInfo final : ISyncPolicy::Data, zsibot::thread_lock::MutexLock
        {
            std::shared_ptr<ISubscriberBase<T>> sub_ptr = nullptr;
            Subscription                        subscription;
        };

        SyncContextBase() = default;
        ZSIBOT_DECLARE_FORBIDDEN_COPY_MOVE(SyncContextBase);

        /**
         * @brief 负责注册制定消息类型的回调处理函数
         * @param sync_base
         * @param on_msg_received_handler
         */
        void setup(SyncBase<T>& sync_base, std::function<void(MessageBasePtr)> on_msg_received_handler)
        {
            ZSIBOT_ASSERT(on_msg_received_handler != nullptr);
            on_msg_received_handler_ = std::move(on_msg_received_handler);
            for (auto& [_, raw_info] : sync_base.sub_info)
            {
                // 新建新的监听
                SubInfo& new_info = sub_info_.emplace_back();

                // 设置原始的订阅信息
                new_info.max_time_diff = raw_info.max_time_diff;
                new_info.buffer_size   = raw_info.buffer_size;
                new_info.is_optional   = raw_info.is_optional;
                new_info.sub_ptr       = std::move(raw_info.sub_ptr);
                ZSIBOT_ASSERT(new_info.sub_ptr != nullptr);

                // 初始化消息队列
                new_info.msgs.resize(new_info.buffer_size);

                // 向该订阅器注册本同步器的回调
                new_info.subscription = new_info.sub_ptr->subscribe(
                    [&](const MessagePtr<T>& msg_ptr)
                    {
                        ZSIBOT_SYNCHRONIZED(new_info)
                        new_info.msgs.push(msg_ptr);
                        on_msg_received_handler_(msg_ptr);
                    });

                // 设置最终订阅的话题名
                new_info.topic_name = new_info.sub_ptr->topicName();
            }
        }

        void shutdown()
        {
            while (not sub_info_.empty())
            {
                SubInfo& sub_info = *sub_info_.begin();
                sub_info.sub_ptr->unsubscribe(sub_info.subscription);
                sub_info_.erase(sub_info_.begin());
            }
        }

        std::list<SubInfo>& getAllSubInfo()
        {
            return sub_info_;
        }

    private:
        //  消息处理函数指针
        std::function<void(MessageBasePtr)> on_msg_received_handler_;
        //   订阅信息列表
        std::list<SubInfo> sub_info_;
    };

    template <class TFirst, class... TRest>
    class SyncContextBase<TFirst, TRest...> : public SyncContextBase<TFirst>, public SyncContextBase<TRest...>
    {
    };


    /**
     * @brief N 个不同类型的上下问的信息
     * @tparam Types 消息的类型列表
     */
    template <class... Types>
    class SyncContext : protected SyncContextBase<Types...>
    {
        static_assert(zsibot::utils::is_all_unique_v<Types...>);

        // 消息同步策略
        using SyncPolicy = ISyncPolicy;

        // 处理用户回调的处理策略
        using CallbackPolicy = ICallbackPolicy<MessageGroupPtr<Types...>>;

    public:
        /**
         * @brief 基于同步策略和回调调策略指针构造上下文
         * @param sync_policy_ptr 同步策略指针
         * @param callback_policy_ptr 回调策略指针
         */
        SyncContext(SyncPolicy* sync_policy_ptr, CallbackPolicy* callback_policy_ptr)
            : sync_policy_ptr_(sync_policy_ptr),
              callback_policy_ptr_(callback_policy_ptr)
        {
            ZSIBOT_ASSERT(sync_policy_ptr_ != nullptr);
            ZSIBOT_ASSERT(callback_policy_ptr_ != nullptr);

            sync_policy_ptr_->setManualSyncHandler(zsibot::utils::bind_<1>(&SyncContext::onNewMessageReceived, this));
        }

        ZSIBOT_DECLARE_FORBIDDEN_COPY_MOVE(SyncContext);

        ~SyncContext()
        {
            reset();
        }

        /**
         * @brief 同步上下文初始化
         * @tparam AnotherTypes
         * @param sync
         */
        template <class... AnotherTypes>
        void init(Sync<AnotherTypes...> sync)
        {
            // 要求传入的 Sync 与 Callback 的类型完全一致，但顺序可以不一致
            static_assert((not zsibot::utils::is_different_from_v<AnotherTypes, Types...> and ...)
                              and (not zsibot::utils::is_different_from_v<Types, AnotherTypes...> and ...),
                "sync should have the same template arguments as subscribers' group has ! (order doesn't matter.)");

            // 逐类型初始化所有的消息监听
            (getBase<Types>().setup(sync.template getBase<Types>(), zsibot::utils::bind_<1>(&SyncContext::onNewMessageReceived, this)), ...);

            // 通知同步策略器进行初始化
            sync_policy_ptr_->beginInit();

            // 逐类型通知同步策略进行初始化
            (initSync<Types>(), ...);

            // 通知同步策略器结束初始化
            sync_policy_ptr_->endInit();
        }

        void reset()
        {
            // 通知同步策略器进行重置
            sync_policy_ptr_->beginReset();

            // 逐类型通知同步策略器进行重置
            (resetSync<Types>(), ...);

            // 通知同步策略器结束重置
            sync_policy_ptr_->endReset();

            // 逐类型取消订阅
            (getBase<Types>().shutdown(), ...);
        }

    private:
        template <class T>
        SyncContextBase<T>& getBase()
        {
            return *static_cast<SyncContextBase<T>*>(this);
        }

        /**
         * @brief 初始化给定类型的订阅消息来源
         */
        template <class T>
        void initSync()
        {
            using SubInfo = typename SyncContextBase<T>::SubInfo;

            // 初始化本类型所有的订阅信息
            for (const SubInfo& sub_info : getBase<T>().getAllSubInfo())
            {
                sync_policy_ptr_->initOne(sub_info);
            }
        }

        template <class T>
        void resetSync()
        {
            using SubInfo = typename SyncContextBase<T>::SubInfo;

            for (const SubInfo& sub_info : getBase<T>().getAllSubInfo())
            {
                sync_policy_ptr_->resetOne(sub_info);
            }
        }


        /**
         * @brief 处理任意消息来源的回调函数，所有注册的回调函数将会在此触发
         * @param new_msg_ptr 指定类型的消息指针
         */
        void onNewMessageReceived(const MessageBasePtr& new_msg_ptr)
        {
            bool begin_sync{ false };
            do
            {
                begin_sync = false;
                std::unique_lock locker(group_mutex);

                if (not sync_policy_ptr_->beginSync(new_msg_ptr))
                    return;
                if (nullptr == msg_group_ptr_)
                {
                    msg_group_ptr_ = std::make_shared<MessageGroup<Types...>>();
                }
                const bool sync_status = (trySync<Types>(new_msg_ptr, *msg_group_ptr_) and ...);

                if (const auto sync_ret = sync_policy_ptr_->endSync(sync_status, new_msg_ptr); sync_ret == SyncResult::Success)
                {
                    callback_policy_ptr_->call(std::move(msg_group_ptr_));
                    msg_group_ptr_ = nullptr;
                }
                else if (sync_ret == SyncResult::Retry)
                {
                    begin_sync = true;
                }
            }
            while (begin_sync);
        }

        /**
         * @brief 尝试对其中一种类型的数据进行同步分析，并将结果设置到消息组中
         * @return 是否同步成功，返回 false 将终止同步
         */
        template <class T>
        bool trySync(const MessageBasePtr& new_msg, MessageGroup<Types...>& msg_group)
        {
            using SubInfo = typename SyncContextBase<T>::SubInfo;

            // 本类型所有的订阅信息
            std::list<SubInfo>& all_sub_info = getBase<T>().getAllSubInfo();

            // 本类型消息组容器
            std::vector<MessagePtr<T>>& msgs_container = msg_group.template mutableGet<T>();

            // 预分配内存
            msgs_container.reserve(all_sub_info.size());
            msgs_container.clear();

            // 遍历所有的订阅信息，进行同步分析
            for (SubInfo& sub_info : all_sub_info)
            {
                ZSIBOT_SYNCHRONIZED(sub_info)
                {
                    // 对该订阅消息进行同步分析
                    zsibotc::expected<MessageBasePtr> opt = sync_policy_ptr_->syncOne(new_msg, sub_info);

                    // 若发生错误，则终止同步
                    if (opt.hasError())
                        return false;

                    // 若处理成功，则分析其是否存在数据，若存在数据，则将其添加到消息组中
                    if (MessageBasePtr& msg_base_ptr = opt.value().ref(); msg_base_ptr != nullptr)
                    {
                        MessagePtr<T> msg_ptr = std::static_pointer_cast<Message<T>>(msg_base_ptr);
                        ZSIBOT_ASSERT(msg_ptr != nullptr);

                        msgs_container.emplace_back(std::move(msg_ptr));
                    }
                }
            }
            return true;
        }

        std::mutex                group_mutex;
        MessageGroupPtr<Types...> msg_group_ptr_;
        SyncPolicy*               sync_policy_ptr_     = nullptr;
        CallbackPolicy*           callback_policy_ptr_ = nullptr;
    };
}  // namespace zsibot::rmw::details
