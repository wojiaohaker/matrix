//
// Created by kanonwy on 2024/12/13
//
#pragma once

#include "zsibot/macro/unused.hpp"
#include "zsibot/rmw/base/message.hpp"
#include "zsibot/rmw/rmw_base.hpp"

namespace zsibot::rmw::details
{

    /**
     * @brief  发布器抽象接口
     * @tparam T 该发布器对应的消息类型
     */
    template <typename T>
    class IPublisher
    {
    public:
        IPublisher()          = default;
        virtual ~IPublisher() = default;

        /**
         * @brief 发布抽象接口
         * @param msg
         * @return
         */
        virtual bool publish(Message<T>& msg) = 0;

        /**
         * @brief 发送协议底层实现
         * @todo
         *   使用完美转发特化更多的版本，支持多种值转发
         */
        virtual bool publish(const std::string& topic_name, Header header, const T& data)
        {
            ZSIBOT_UNUSED(topic_name);
            Message<T> msg;
            msg.header = std::move(header);
            msg.header.channel_name = topic_name;
            msg.data   = data;
            return publish(msg);
        }

        /**
         * @brief 设置通信方式
         * @param mode 通县方式枚举
         */
        virtual void setmode(zsibot::rmw::CommunicationMode mode)
        {
            ZSIBOT_UNUSED(mode);
        }
    };


}  // namespace jszr::rmw::details
