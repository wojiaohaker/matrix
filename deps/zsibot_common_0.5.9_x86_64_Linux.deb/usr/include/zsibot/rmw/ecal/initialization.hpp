//
// Created by kanonwy on 2024/12/16
//
#pragma once

namespace zsibot::rmw::ecal::details
{
    /**
     * @brief eCAL 框架初始化
     * @details 该函数只会被执行一次
     */
    bool eCALInitialization();

}  // namespace jszr::rmw::ecal::details
