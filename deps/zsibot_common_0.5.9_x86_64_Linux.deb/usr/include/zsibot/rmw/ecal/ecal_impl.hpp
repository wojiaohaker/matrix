//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <memory>
#include <string>

#include "zsibot/rmw/ecal/ecal_publisher.hpp"
#include "zsibot/rmw/ecal/ecal_subscriber.hpp"
#include "zsibot/rmw/type_check.hpp"


namespace zsibot::rmw
{

    /**
     * @brief jszr rmw 中 ecal_pb 底层实现所在的命名空间
     */
    namespace ecal
    {
    }
    /**
     * @brief  用于创建 ecal_pb 顶层实现的工厂结构体
     */
    struct Ecal
    {
        /**
         * @brief  工厂函数，用于创建指定话题名，指定消息类型的 eCAL 发布器
         * @tparam T 底层消息类型
         * @param topic_name 话题类型
         * @return
         */
        template <typename T>
        static auto createPublisher(const std::string& topic_name)
        {
            static_assert(zsibot::rmw::details::is_protocol_buffer_v<T>, "T must be a protocol buffer type");
            return std::make_unique<zsibot::rmw::details::ECALPublisher<T>>(topic_name);
        }

        /**
         * @brief 工厂函数，用于创建指定话题名，指定消息类型的 eCAL 订阅器
         * @tparam T 底层消息类型
         * @param topic_name 话题类型
         * @return
         */
        template <typename T>
        static auto createSubscriber(const std::string& topic_name)
        {
            static_assert(zsibot::rmw::details::is_protocol_buffer_v<T>, "T must be a protocol buffer type");
            return std::make_unique<zsibot::rmw::details::ECALSubscriber<T>>(topic_name);
        }
    };


}  // namespace zsibot::rmw
