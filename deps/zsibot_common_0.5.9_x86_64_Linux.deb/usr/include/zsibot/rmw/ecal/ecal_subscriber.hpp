//
// Created by kanonwy on 2024/12/17
//
#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <string>

#include <ecal/ecal.h>
#include <ecal/msg/protobuf/subscriber.h>

#include "zsibot/macro/unused.hpp"
#include "zsibot/rmw/abstract/i_subscriber.hpp"
#include "zsibot/rmw/base/message.hpp"
#include "zsibot/rmw/detect.hpp"
#include "zsibot/rmw/type_check.hpp"

namespace zsibot::rmw::ecal::details
{
    /**
     * @brief eCAL 订阅器信息基类
     * @details 存储了订阅器需要关注的一些信息
     */
    class ECALSubscriberBase
    {
    public:
        /**
         * @brief eCAL 订阅基类构造
         * @param topic_name
         * @param data_type_name
         */
        ECALSubscriberBase(std::string topic_name, std::string data_type_name);

        virtual ~ECALSubscriberBase() = default;

    protected:
        std::string      topic_name_;              ///<<< 话题类型
        std::string      data_type_;               ///<<< 数据类型（字符串）
        std::string      creator_name_;            ///<<< 创建者
        std::atomic_bool is_subscriber_{ false };  ///<<< 是否订阅（未实现）
    };
}  // namespace zsibot::rmw::ecal::details

namespace zsibot::rmw::details
{
    template <typename T>
    class ECALSubscriber;


    /**
     * @brief eCAL 订阅器的范型实现
     * @tparam T 用户层自定义的 protobuf 消息类型
     */
    template <typename T>
    class ECALSubscriber final : public zsibot::rmw::ecal::details::ECALSubscriberBase, public ISubscriber<T>
    {
    public:
        /**
         * @brief eCAL 订阅器显式构造
         * @param topic_name
         */
        explicit ECALSubscriber(const std::string& topic_name)
            : zsibot::rmw::ecal::details::ECALSubscriberBase(topic_name, getDataTypeName<T>())
        {
            subscriber_ = std::make_unique<::eCAL::protobuf::CSubscriber<T>>(topic_name_.c_str());
        }

        bool subscribe(MessageCallback<T> cb) override
        {
            callback_ = std::move(cb);
            subscriber_->AddReceiveCallback(
                [this](const char* topic_name, const T& msg, const long long time, const long long clock, const long long id)
                {
                    ZSIBOT_UNUSED(topic_name, time, clock, id);
                    if (not callback_)
                    {
                        return;
                    }
                    // TODO: 使用消息池，而不频繁创建消息对象，或者使用类中的缓存消息来处理
                    MessagePtr<T> message = std::make_shared<Message<T>>();
                    message->data         = std::move(msg);
                    message->header.channel_name = topic_name_;
                    if constexpr (zsibot::rmw::ecal::details::Hasheader_v<T>)
                    {
                        headerInit(message);
                    }
                    callback_(message);
                });
            return true;
        }

    private:
        /**
         * @brief  填充消息应用层的 header 头部
         * @details
         */
        void headerInit(MessagePtr<T> msg)
        {
            if constexpr (zsibot::rmw::ecal::details::Haschannel_name_v<T>)
            {
                std::cout << "channel_name = " <<msg->header.channel_name << std::endl;
                msg->header.channel_name = msg->data.mutable_header().channel_name();
            }
            if constexpr (zsibot::rmw::ecal::details::Hascreator_name_v<T>)
            {
                msg->header.creator_name = msg->data.mutable_header()->creator_name();
            }
            if constexpr (zsibot::rmw::ecal::details::Hassequence_v<T>)
            {
                msg->header.sequence = msg->data.mutable_header()->sequence();
            }
            if constexpr (zsibot::rmw::ecal::details::Hassec_v<T> and zsibot::rmw::ecal::details::Hasnsec_v<T>)
            {
                msg->header.timestamp = std::chrono::time_point<std::chrono::system_clock>(
                    std::chrono::seconds(msg->data.header().sec()) + std::chrono::nanoseconds(msg->data.header().nsec()));
            }
        }

    private:
        MessageCallback<T>                                callback_{};  ///<<< 底层回调函数
        std::unique_ptr<::eCAL::protobuf::CSubscriber<T>> subscriber_;  ///<<< 实际底层订阅器
    };

}  // namespace zsibot::rmw::details
