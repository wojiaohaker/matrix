//
// Created by kanonwy on 2024/12/16
//
#pragma once

#include <chrono>
#include <memory>
#include <string>

#include <ecal/ecal.h>
#include <ecal/msg/protobuf/publisher.h>

#include "zsibot/rmw/abstract/i_publisher.hpp"
#include "zsibot/rmw/detect.hpp"
#include "zsibot/rmw/type_check.hpp"

namespace zsibot::rmw::ecal::details
{
    /**
     * @brief eCAL 发布器基类
     * @todo: 节点发现机制
     */
    class ECALPublisherBase
    {
    public:
        /**
         * @brief 发布器基类构造函数
         * @param topic_name
         * @param data_type
         */
        ECALPublisherBase(std::string topic_name, std::string data_type);

        virtual ~ECALPublisherBase() = default;

    protected:
        std::string data_type_;     ///<<< 数据类型
        std::string topic_name_;    ///<<< 话题名称
        std::string creator_name_;  ///<<< 创建者名称
    };
}  // namespace zsibot::rmw::ecal::details


namespace zsibot::rmw::details
{
    /**
     * @brief  eCAL 顶层订阅器的声明
     * @tparam T
     */
    template <typename T>
    class ECALPublisher;

    inline eCAL::TLayer::eTransportLayer getEcalLayer(zsibot::rmw::CommunicationMode mode)
    {
        switch (mode)
        {
            using namespace zsibot::rmw;
            case CommunicationMode::IN_PROC: {
                return eCAL::TLayer::tlayer_inproc;
            }
            case CommunicationMode::SHM: {
                return eCAL::TLayer::tlayer_shm;
            }
            case CommunicationMode::TCP: {
                return eCAL::TLayer::tlayer_tcp;
            }
            case CommunicationMode::UDP_MC: {
                return eCAL::TLayer::tlayer_udp_mc;
            }
            default:
                return eCAL::TLayer::tlayer_all;
        }
    }


    /**
     * @brief eCAL 发布器的范性实现
     * @param T 任意类型的 Protobuf::Message 类型的数据
     * @todo 使用零拷贝实现
     */
    template <class T>
    class ECALPublisher final : public zsibot::rmw::ecal::details::ECALPublisherBase, public IPublisher<T>
    {
    public:
        /**
         * @brief Ecal 发布器显式构造函数
         * @param topic_name
         */
        explicit ECALPublisher(const std::string& topic_name)
            : zsibot::rmw::ecal::details::ECALPublisherBase(topic_name, getDataTypeName<T>())
        {
            publisher_ = std::make_unique<::eCAL::protobuf::CPublisher<T>>(topic_name.c_str());
        }

        ~ECALPublisher() override = default;


        /**
         * @brief ecal 支持设置通信方式
         * @param mode
         */
        void setmode(zsibot::rmw::CommunicationMode mode) override
        {
            publisher_->SetLayerMode(eCAL::TLayer::tlayer_all, eCAL::TLayer::smode_off);
            publisher_->SetLayerMode(getEcalLayer(mode), eCAL::TLayer::smode_on);
        }
        /**
         * @brief  发送函数
         * @param msg
         * @return
         */
        bool publish(Message<T>& msg) override
        {
            if constexpr (zsibot::rmw::ecal::details::Hasheader_v<T>)
            {
                headerInit(msg);
            }
            // TODO: 使用 likely 优化此逻辑
            if (publisher_)
            {
                publisher_->Send(msg.data);
                return true;
            }
            return false;
        }

    private:
        /**
         * @brief 使用 header 中的数据填充 protobuf msg 中的数据
         * @todo 也许有性能损失
         */
        void headerInit(Message<T>& msg)
        {
            auto header = msg.data.mutable_header();
            if constexpr (zsibot::rmw::ecal::details::Haschannel_name_v<T>)
            {
                header->set_channel_name(msg.header.channel_name);
            }
            if constexpr (zsibot::rmw::ecal::details::Hassec_v<T>)
            {
                header->set_sec(std::chrono::duration_cast<std::chrono::seconds>(msg.header.timestamp.time_since_epoch()).count());
            }
            if constexpr (zsibot::rmw::ecal::details::Hasnsec_v<T>)
            {
                auto time_total = msg.header.timestamp.time_since_epoch();
                auto time_sec   = std::chrono::duration_cast<std::chrono::seconds>(time_total);
                auto time_nsec  = std::chrono::duration_cast<std::chrono::nanoseconds>(time_total - time_sec);
                header->set_nsec(time_nsec.count());
            }
            if constexpr (zsibot::rmw::ecal::details::Hassequence_v<T>)
            {
                if (!header->sequence())
                {
                    header->set_sequence(msg.header.sequence);
                }
            }
        }

        std::unique_ptr<::eCAL::protobuf::CPublisher<T>> publisher_;  ///<<< 底层 eCAL 发布器
    };

}  // namespace zsibot::rmw::details
