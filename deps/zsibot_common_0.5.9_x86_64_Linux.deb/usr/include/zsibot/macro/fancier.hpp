//
// Created by kanonwy on 2024/11/8
//

#pragma once

#include <type_traits>

#include "zsibot/macro/arguments.hpp"

namespace zsibot::details::type_traits
{
    /**
     * @brief 用于检查给定的模板实例化是否合法
     * @tparam TDummy 辅助模版
     * @tparam TOp 被检查的模板
     * @tparam TArgs 用于实例化该模板的类型参数
     */
    template <class TDummy, template <class...> class TOp, class... TArgs>
    struct detector
    {
        constexpr static bool enable = false;  ///<<< enable
    };

    /**
     * @brief 用于检查给定的模板实例化是否合法的特化版本
     * @tparam TOp
     * @tparam TArgs
     */
    template <template <class...> class TOp, class... TArgs>
    struct detector<std::void_t<TOp<TArgs...>>, TOp, TArgs...>
    {
        constexpr static bool enable = true;  ///<<< enable
    };

    /**
     * @brief 通过实例化的方式，检查给定条件是否成立
     * @tparam CON 非类型模板 bool 类型
     */
    template <bool CON>
    struct checker
    {
        constexpr static bool value = true;  ///<<< enable
    };

    template <>
    struct checker<false>
    {
    };
}  // namespace zsibot::details::type_traits

/**
 * @brief 模拟其他语言的行内函数，放在函数后推导的位置。
 */
#define ZSIBOT_EVAL(...)                                                                                                                   \
    decltype(auto)                                                                                                                         \
    {                                                                                                                                      \
        return (__VA_ARGS__);                                                                                                              \
    }


namespace zsibot
{
    /**
     * @brief 用于检查指定模板的实例化是否合法，也即是否符合某种 concept
     * @tparam TOp 被检查的模板
     * @tparam TArgs 实例化该模板的类型参数
     */
    template <template <class...> class TOp, class... TArgs>
    constexpr static bool is = details::type_traits::detector<void, TOp, TArgs...>::enable;

    /**
     * @brief 用于检查给定两个参数的类型是否相同，仅能在 concept 中使用
     */
    template <class Lhs, class Rhs>
    constexpr auto same_as(Lhs, Rhs) -> ZSIBOT_EVAL(details::type_traits::checker<std::is_same_v<Lhs, Rhs>>::value)
}  // namespace zsibot

namespace zsibot
{

    /**
     * @brief 用于检查给定的参数是否符合指定的类型，仅能在 concept 中使用
     * @tparam TargetType 指定的类型
     * @tparam CheckedType 被检查的类型
     */
    template <class TargetType, class CheckedType>
    constexpr auto same_as(CheckedType) -> ZSIBOT_EVAL(details::type_traits::checker<std::is_same_v<TargetType, CheckedType>>::value)
}  // namespace zsibot


/**
 * @brief 模拟实现 c++ 20 requires 语法，静态推断类型，可用于模板参数列表或函数参数列表中。
 * 其中，括号内参数为一个编译时期可进行判断的表达式或 bool 值。
 **/
#define ZSIBOT_REQUIRES(...) typename std::enable_if<(__VA_ARGS__), int>::type = 0


#define ZSIBOT_CONCEPT(...) decltype(ZSIBOT_CONCAT(ZSIBOT_DETAILS_CONCEPT_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__))


/**
 * @brief 用于修饰函数或类，静态推断它是否应该被使用。
 */
#define ZSIBOT_ENABLE_IF(...) template <typename Dummy = std::true_type, ZSIBOT_REQUIRES(Dummy::value and (__VA_ARGS__))>


/**
 * @brief 检查给定类型是否能够进行某种操作
 */
#define ZSIBOT_DETECTS(_type_, ...)                                                                                                        \
    (std::is_same_v<ZSIBOT_DETAILS_DETECTS(_type_, __VA_ARGS__), ZSIBOT_DETAILS_DETECTS(_type_, __VA_ARGS__)>)


/**
 * @brief 检查给定类型是否能够进行某种操作，并获得指定类型的结果
 */
#define ZSIBOT_DETECTS_AS(_result_type_, _type_, ...) (std::is_same_v<_result_type_, ZSIBOT_DETAILS_DETECTS(_type_, __VA_ARGS__)>)


/// 对指定类型进行实例化操作，并获取操作的结果类型
#define ZSIBOT_DETAILS_DETECTS(_type_, ...) decltype(ZSIBOT_DECLVALUE(_type_) __VA_ARGS__)


/**
 * @brief 检查给定的表达式是否合法
 */
#define ZSIBOT_TESTS(...) (std::is_same_v<ZSIBOT_DETAILS_TESTS(__VA_ARGS__), ZSIBOT_DETAILS_TESTS(__VA_ARGS__)>)


/**
 * @brief 检查给定的表达式是否合法，且其返回值与给定的类型相符
 */
#define ZSIBOT_TESTS_AS(_result_type_, ...) (std::is_same_v<_result_type_, ZSIBOT_DETAILS_TESTS(__VA_ARGS__)>)


/// 运行表达式，并获取表达式的结果
#define ZSIBOT_DETAILS_TESTS(...) decltype(__VA_ARGS__)

/// 检查指定表达式是否成立
#define ZSIBOT_DETAILS_CONCEPT_CHECKS(...) ::zsibot::details::type_traits::checker<__VA_ARGS__>::value

/// 用于 ZSIBOT_CONCEPT 中条件检查的宏，需要分成使用两层宏实现，确保宏参数正确展开
#define ZSIBOT_DETAILS_CONCEPT_1(...)  ZSIBOT_DETAILS_CONCEPT_1_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_2(...)  ZSIBOT_DETAILS_CONCEPT_2_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_3(...)  ZSIBOT_DETAILS_CONCEPT_3_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_4(...)  ZSIBOT_DETAILS_CONCEPT_4_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_5(...)  ZSIBOT_DETAILS_CONCEPT_5_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_6(...)  ZSIBOT_DETAILS_CONCEPT_6_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_7(...)  ZSIBOT_DETAILS_CONCEPT_7_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_8(...)  ZSIBOT_DETAILS_CONCEPT_8_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_9(...)  ZSIBOT_DETAILS_CONCEPT_9_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_10(...) ZSIBOT_DETAILS_CONCEPT_10_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_11(...) ZSIBOT_DETAILS_CONCEPT_11_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_12(...) ZSIBOT_DETAILS_CONCEPT_12_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_13(...) ZSIBOT_DETAILS_CONCEPT_13_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_14(...) ZSIBOT_DETAILS_CONCEPT_14_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_15(...) ZSIBOT_DETAILS_CONCEPT_15_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_16(...) ZSIBOT_DETAILS_CONCEPT_16_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_17(...) ZSIBOT_DETAILS_CONCEPT_17_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_18(...) ZSIBOT_DETAILS_CONCEPT_18_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_19(...) ZSIBOT_DETAILS_CONCEPT_19_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_20(...) ZSIBOT_DETAILS_CONCEPT_20_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_21(...) ZSIBOT_DETAILS_CONCEPT_21_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_22(...) ZSIBOT_DETAILS_CONCEPT_22_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_23(...) ZSIBOT_DETAILS_CONCEPT_23_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_24(...) ZSIBOT_DETAILS_CONCEPT_24_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_25(...) ZSIBOT_DETAILS_CONCEPT_25_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_26(...) ZSIBOT_DETAILS_CONCEPT_26_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_27(...) ZSIBOT_DETAILS_CONCEPT_27_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_28(...) ZSIBOT_DETAILS_CONCEPT_28_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_29(...) ZSIBOT_DETAILS_CONCEPT_29_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_30(...) ZSIBOT_DETAILS_CONCEPT_30_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_31(...) ZSIBOT_DETAILS_CONCEPT_31_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_32(...) ZSIBOT_DETAILS_CONCEPT_32_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_33(...) ZSIBOT_DETAILS_CONCEPT_33_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_34(...) ZSIBOT_DETAILS_CONCEPT_34_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_35(...) ZSIBOT_DETAILS_CONCEPT_35_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_36(...) ZSIBOT_DETAILS_CONCEPT_36_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_37(...) ZSIBOT_DETAILS_CONCEPT_37_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_38(...) ZSIBOT_DETAILS_CONCEPT_38_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_39(...) ZSIBOT_DETAILS_CONCEPT_39_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_40(...) ZSIBOT_DETAILS_CONCEPT_40_DO(__VA_ARGS__)

#define ZSIBOT_DETAILS_CONCEPT_1_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_
#define ZSIBOT_DETAILS_CONCEPT_2_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_1_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_3_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_2_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_4_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_3_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_5_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_4_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_6_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_5_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_7_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_6_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_8_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_7_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_9_DO(_con_, ...)  ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_8_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_10_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_9_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_11_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_10_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_12_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_11_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_13_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_12_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_14_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_13_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_15_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_14_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_16_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_15_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_17_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_16_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_18_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_17_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_19_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_18_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_20_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_19_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_21_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_20_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_22_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_21_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_23_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_22_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_24_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_23_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_25_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_24_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_26_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_25_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_27_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_26_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_28_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_27_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_29_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_28_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_30_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_29_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_31_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_30_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_32_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_31_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_33_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_32_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_34_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_33_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_35_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_34_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_36_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_35_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_37_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_36_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_38_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_37_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_39_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_38_DO(__VA_ARGS__)
#define ZSIBOT_DETAILS_CONCEPT_40_DO(_con_, ...) ZSIBOT_DETAILS_CONCEPT_CHECKS _con_, ZSIBOT_DETAILS_CONCEPT_39_DO(__VA_ARGS__)
