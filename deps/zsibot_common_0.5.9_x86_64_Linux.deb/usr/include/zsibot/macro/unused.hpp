//
// Created by kanonwy on 2024/11/8
//

#pragma once

#include "zsibot/macro/base_macro.hpp"

namespace zsibot::discard
{
/**
 * @brief 标识一些参数不会被使用，使编译器不要产生警告。
 */
#define ZSIBOT_UNUSED(...) ZSIBOT_CONCAT(ZSIBOT_DETAILS_UNUSED_, ZSIBOT_COUNT_ARGS(__VA_ARGS__))(__VA_ARGS__)

#define ZSIBOT_DETAILS_UNUSED_1(x)                                                                                                           \
    (void)x;                                                                                                                               \
    void(0)
#define ZSIBOT_DETAILS_UNUSED_2(x, y)                                                                                                        \
    (void)x;                                                                                                                               \
    (void)y;                                                                                                                               \
    void(0)
#define ZSIBOT_DETAILS_UNUSED_3(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_2(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_4(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_3(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_5(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_4(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_6(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_5(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_7(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_6(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_8(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_7(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_9(x, ...)                                                                                                      \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_8(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_10(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_9(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_11(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_10(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_12(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_11(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_13(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_12(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_14(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_13(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_15(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_14(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_16(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_15(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_17(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_16(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_18(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_17(__VA_ARGS__)
#define ZSIBOT_DETAILS_UNUSED_19(x, ...)                                                                                                     \
    (void)x;                                                                                                                               \
    ZSIBOT_DETAILS_UNUSED_18(__VA_ARGS__)

}  // namespace jszr::discard
