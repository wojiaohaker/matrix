#pragma once

/**
 * @brief 取出指定类型中，指定成员的地址偏移量；第一个参数为类型，第二个参数为成员（不能包含逗号，但可以级联）
 * @note C++ 内置有 offsetof 宏，本宏能处理更复杂的参数，比它更加强大一些。
 * @example 偏移宏示例
 * @code{.cpp}
 * template<class T, class E>
 * struct Data
 * {
 *     T a;
 *     E b;
 * };
 * static auto offset = ZSIBOT_OFFSETOF(Data<int, Data<float, bool>>, b.a);
 * @endcode
 *
 */
#define ZSIBOT_OFFSETOF(...) ((std::size_t)(&(((ZSIBOT_ARGS_EXCEPT_LAST(1, __VA_ARGS__)*)nullptr)->ZSIBOT_ARGS_THE_LAST(1, __VA_ARGS__))))
