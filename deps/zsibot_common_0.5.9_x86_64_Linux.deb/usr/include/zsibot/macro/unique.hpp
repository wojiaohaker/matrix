//
// Created by kanonwy on 2024/12/25
//

#pragma once

/**
 * @brief 使用 __COUNTER__ 或 __LINE__ ，创建唯一的命名
 */

#pragma once

#include "zsibot/macro/concat.hpp"

/**
 * @brief 创建出现次数唯一命名（同一份文件内）
 * @example 单文件内唯一命名宏
 * @code{.cpp}
 * int ZSIBOT_COUNTER_UNIQUE(a) = 1;
 * int ZSIBOT_COUNTER_UNIQUE(a) = 2;
 * int ZSIBOT_COUNTER_UNIQUE(a) = 3;
 * @endcode
 */
#define ZSIBOT_COUNTER_UNIQUE(_x_) ZSIBOT_CONCAT(_x_, _COUNTER_UNIQUE_, __COUNTER__)


/**
 * @brief 创建代码行内唯一命名
 * @example 代码行内唯一命名宏
 * @code{.cpp}
 * int ZSIBOT_LINE_UNIQUE(a) = 1; ZSIBOT_LINE_UNIQUE(a) = -1;
 * int ZSIBOT_LINE_UNIQUE(a) = 2; ZSIBOT_LINE_UNIQUE(a) = -2;
 * @endcode
 */
#define ZSIBOT_LINE_UNIQUE(_x_) ZSIBOT_CONCAT(_x_, _LINE_UNIQUE_, __LINE__)
