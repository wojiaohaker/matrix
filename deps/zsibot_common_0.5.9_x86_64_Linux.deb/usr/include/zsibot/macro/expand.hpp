//
// Created by kanonwy on 2024/12/25
//

#pragma once

/// 宏展开辅助函数，确保宏参数x得以充分展开
#define ZSIBOT_MACRO_EXPAND(...) __VA_ARGS__