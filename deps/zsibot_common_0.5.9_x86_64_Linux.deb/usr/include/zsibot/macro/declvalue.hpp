//
// Created by kanonwy on 2024/12/25
//

#pragma once

/**
 * @brief 用以获取某个类型的对象（非实例化）
 * @note 近乎等价于 std::declvalue
 * @example 获取某一个对象类型宏
 * @code{.cpp}
 * std::vector<int> v;
 * decltype(ZSIBOT_DECLVALUE(std::vector<int>).begin()) it = v.begin();
 * @endcode
 */
#define ZSIBOT_DECLVALUE(...) (*((std::remove_reference_t<__VA_ARGS__>*)nullptr))
