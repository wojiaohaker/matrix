#pragma once

#include <iostream>

#include "zsibot/macro/concat.hpp"
#include "zsibot/macro/count.hpp"
#include "zsibot/macro/unique.hpp"


#ifdef NDEBUG
#define ZSIBOT_ASSERT(...)
#else
/**
 * @brief 进行一次断言，并可以设置错误信息（仅调试模式有效）
 */
#define ZSIBOT_ASSERT(...) ZSIBOT_CONCAT(ZSIBOT_DETAILS_ASSERT_, ZSIBOT_COUNT_ARGS_0_1_N(__VA_ARGS__))(__VA_ARGS__)

// ZSIBOT_ASSERT 打印用的辅助函数
#define ZSIBOT_DETAILS_PRINT_ASSERT_FAILED_INFO(_expr_)                                                                                      \
    std::cerr << "assert failed: " << (_expr_) << std::endl                                                                                \
              << "file: " << __FILE__ << std::endl                                                                                         \
              << "line: " << __LINE__ << std::endl,                                                                                        \
        void(0)

// 单个参数的 ZSIBOT_ASSERT 重载
#define ZSIBOT_DETAILS_ASSERT_1(_expr_)                                                                                                      \
    (static_cast<bool>(_expr_) ? void(0) : (ZSIBOT_DETAILS_PRINT_ASSERT_FAILED_INFO(#_expr_), std::terminate()))

// 多个参数的 ZSIBOT_ASSERT 重载
#define ZSIBOT_DETAILS_ASSERT_N(_expr_, ...)                                                                                                 \
    (static_cast<bool>(_expr_) ? void(0) : (ZSIBOT_DETAILS_PRINT_ASSERT_FAILED_INFO(#_expr_), printf(__VA_ARGS__), std::terminate()))
#endif
