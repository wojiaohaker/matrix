//
// Created by kanonwy on 2024/11/8
//

#pragma once

/**
 * @brief 在一个类内，为该类声明默认的拷贝构造与拷贝赋值函数
 */
#define ZSIBOT_DECLARE_DEFAULT_COPY(_class_)                                                                                                 \
    _class_(const _class_& other)            = default;                                                                                    \
    _class_(_class_& other)                  = default;                                                                                    \
    _class_& operator=(const _class_& other) = default

/**
 * @brief 在一个类内，为该类声明默认的移动构造与移动赋值函数
 */
#define ZSIBOT_DECLARE_DEFAULT_MOVE(_class_)                                                                                                 \
    _class_(_class_&& other) noexcept            = default;                                                                                \
    _class_& operator=(_class_&& other) noexcept = default

/**
 * @brief 在一个类内，为该类声明默认的拷贝、移动构造与赋值函数
 */
#define ZSIBOT_DECLARE_DEFAULT_COPY_MOVE(_class_)                                                                                            \
    ZSIBOT_DECLARE_DEFAULT_COPY(_class_);                                                                                                    \
    ZSIBOT_DECLARE_DEFAULT_MOVE(_class_)

/**
 * @brief 在一个类内，为该类禁止拷贝构造函数与拷贝函数
 */
#define ZSIBOT_DECLARE_FORBIDDEN_COPY(_class_)                                                                                               \
    _class_(const _class_& other)            = delete;                                                                                     \
    _class_(_class_& other)                  = delete;                                                                                     \
    _class_& operator=(const _class_& other) = delete

/**
 * @brief 在一个类内，为该类禁止移动构造函数与右值拷贝函数
 */
#define ZSIBOT_DECLARE_FORBIDDEN_MOVE(_class_)                                                                                               \
    _class_(_class_&& other) noexcept            = delete;                                                                                 \
    _class_& operator=(_class_&& other) noexcept = delete

/**
 * @brief 在一个类内，为该类禁止普通拷贝、右值拷贝的构造函数、赋值函数
 */
#define ZSIBOT_DECLARE_FORBIDDEN_COPY_MOVE(_class_)                                                                                          \
    ZSIBOT_DECLARE_FORBIDDEN_COPY(_class_);                                                                                                  \
    ZSIBOT_DECLARE_FORBIDDEN_MOVE(_class_)
