#pragma once

#include <string>

#include "zsibot/param/backend/sys.hpp"
#include "zsibot/param/details/const_name_type_helper.hpp"

namespace zsibot::param::deprecated
{
    /**
     * @brief 读取指定的参数，返回读取是否成功
     */
    template <class T>
    bool read(const std::string& name, T& obj)
    {
        if (backend::ParamInterface* ptr = backend::getSys(); ptr != nullptr)
            return ptr->read(name, details::createView(obj));
        return false;
    }

    /**
     * @brief 读取指定的参数，返回读取结果
     */
    template <class T>
    std::optional<T> read(const std::string& name)
    {
        if (T obj; read(name, obj))
            return obj;
        return {};
    }

    /**
     * @brief 读取指定的静态参数，返回读取是否成功
     */
    template <class T>
    bool readStatic(const std::string& name, T& obj)
    {
        if (backend::ParamInterface* ptr = backend::getSys(); ptr != nullptr)
            return ptr->readStatic(name, details::createView(obj));
        return false;
    }

    /**
     * @brief 读取指定的参数，返回读取结果
     */
    template <class T>
    std::optional<T> readStatic(const std::string& name)
    {
        if (T obj; readStatic(name, obj))
            return obj;
        return {};
    }
}  // namespace zsibot::param::deprecated

/**
 * @brief eon 参数实现细节所在的命名空间
 */
namespace zsibot::param::details
{
    /**
     * @brief 参数结构体泛型
     *
     * @tparam T 需要参数化的结构体
     *
     * @param NAME 参数名称用于唯一指定一个 yaml 文件
     *
     * @details
     *  基于对象类型 T 和 NAME 的不同,可以实例化出不同的结构体与绑定的结构化参数对应
     */
    template <class T, const char* NAME>
    class StaticNameParam
    {
    public:
        /**
         * @brief read a param pass to obj
         * @param obj out param
         * @return
         */
        static bool read(T& obj)
        {
            if (::zsibot::param::backend::ParamInterface* ptr = ::zsibot::param::backend::getSys(); ptr != nullptr)
                return ptr->read(NAME, bind(obj));
            return false;
        }

        /**
         * @brief read a static param value
         * @param obj out param
         */
        static bool readStatic(T& obj)
        {
            if (::zsibot::param::backend::ParamInterface* ptr = ::zsibot::param::backend::getSys(); ptr != nullptr)
                return ptr->readStatic(NAME, bind(obj));
            return false;
        }

        /**
         * @brief read param pass by optional
         * @return
         */
        static std::optional<T> read()
        {
            if (T obj; read(obj))
                return obj;
            return {};
        }

        /**
         * @brief read param pass by option
         */
        static std::optional<T> readStatic()
        {
            if (T obj; readStatic(obj))
                return obj;
            return {};
        }

    private:
        static binding::ObjectView bind(T& obj)
        {
            return module::GlobalUnique<ConstNameTypeHelper<T, NAME>>::ref().bind(obj);
        }
    };

    template <uint32_t>
    class UniqueNameHelper;

}  // namespace zsibot::param::details

/**
 * @example 参数定义与读取简单示例
 * @code{.cpp}
 * // 自定义的参数结构体
 * namespace kanon
 * {
 *     struct Param
 *     {
 *         std::string name;
 *         int64_t number;
 *         std::vector<std::string> vec;
 *     }
 * }
 * // 结构体绑定用于反射
 * ZSIBOT_BINDING_OBJECT(kanon::Param, name, number, vec)
 *
 * // 基于该类型，声明一个拥有静态名称的参数
 * ZSIBOT_PARAM("myparam", kanon::Param, ControlParam)
 * // 读取该参数
 * std::optional<kanon::Param> paramRes = ControlParam::Read();
 * if(paramRes.has_value())
 * {
 *     std::cout << paramRes.value().name << std::endl;
 * }
 * @endcode
 */

/**
 * @brief 声明一份拥有静态名称的参数访问入口
 * @param _static_name_ 参数名称，const char* 类型，与系统中yaml 文件名对应
 * @param _type_ 需要绑定参数的结构体类型
 * @param _instance_ 实例化出的存储参数信息的结构体
 * @note 静态名称的参数不等于静态参数。
 * @note 拥有静态名称的参数将被参数构造器默认构造，并且不可删除。
 */
#define ZSIBOT_PARAM(_static_name_, _type_, _instance_)                                                                                      \
    namespace details::user_param_const_name                                                                                               \
    {                                                                                                                                      \
        constexpr char _instance_##_const_param_name[] = _static_name_;                                                                    \
    }                                                                                                                                      \
    struct _instance_                                                                                                                      \
        : public zsibot::param::details::StaticNameParam<_type_, details::user_param_const_name::_instance_##_const_param_name>              \
    {                                                                                                                                      \
    };                                                                                                                                     \
    template <>                                                                                                                            \
    class zsibot::param::details::UniqueNameHelper<zsibot::string_hash::elf(details::user_param_const_name::_instance_##_const_param_name,     \
        sizeof(details::user_param_const_name::_instance_##_const_param_name))>                                                            \
    {                                                                                                                                      \
    };

/**
 * @brief jszr 默认参数后端实现
 * @note 使用 EON_NOT_OPTIMIZE_OUT_HELPER_DECLARE(init_helper) 避免被编译器优化
 */
namespace zsibot::param::backend
{
    ZSIBOT_NOT_OPTIMIZE_OUT_HELPER_DECLARE(init_helper)
}
