#pragma once

#include "zsibot/string_hash/ap.h"
#include "zsibot/string_hash/bkdr.h"
#include "zsibot/string_hash/bp.h"
#include "zsibot/string_hash/dek.h"
#include "zsibot/string_hash/djb.h"
#include "zsibot/string_hash/elf.h"
#include "zsibot/string_hash/fnv.h"
#include "zsibot/string_hash/js.h"
#include "zsibot/string_hash/pjw.h"
#include "zsibot/string_hash/rs.h"
#include "zsibot/string_hash/sdbm.h"
