#pragma once

#include "zsibot/macro.hpp"
#include "zsibot/unit/time.hpp"

namespace zsibot::unit
{
    template <class T>
    using DefinedUnitClass = ZSIBOT_CONCEPT((zsibot::is<zsibot::unit::TimeClass, T>));

}  // namespace zsibot::unit
