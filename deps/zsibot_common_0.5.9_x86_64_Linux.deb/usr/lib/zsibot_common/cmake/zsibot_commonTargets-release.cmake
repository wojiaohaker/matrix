#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zsibot_common::bluetooth" for configuration "Release"
set_property(TARGET zsibot_common::bluetooth APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::bluetooth PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libbluetooth.so"
  IMPORTED_SONAME_RELEASE "libbluetooth.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::bluetooth )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::bluetooth "${_IMPORT_PREFIX}/lib/libbluetooth.so" )

# Import target "zsibot_common::power_mcu" for configuration "Release"
set_property(TARGET zsibot_common::power_mcu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::power_mcu PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libpower_mcu.so"
  IMPORTED_SONAME_RELEASE "libpower_mcu.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::power_mcu )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::power_mcu "${_IMPORT_PREFIX}/lib/libpower_mcu.so" )

# Import target "zsibot_common::fault" for configuration "Release"
set_property(TARGET zsibot_common::fault APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::fault PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libfault.so"
  IMPORTED_SONAME_RELEASE "libfault.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::fault )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::fault "${_IMPORT_PREFIX}/lib/libfault.so" )

# Import target "zsibot_common::spline_message" for configuration "Release"
set_property(TARGET zsibot_common::spline_message APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::spline_message PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libspline_message.so"
  IMPORTED_SONAME_RELEASE "libspline_message.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::spline_message )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::spline_message "${_IMPORT_PREFIX}/lib/libspline_message.so" )

# Import target "zsibot_common::robot_sdk" for configuration "Release"
set_property(TARGET zsibot_common::robot_sdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::robot_sdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librobot_sdk.so"
  IMPORTED_SONAME_RELEASE "librobot_sdk.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::robot_sdk )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::robot_sdk "${_IMPORT_PREFIX}/lib/librobot_sdk.so" )

# Import target "zsibot_common::zsibot_pb_msg" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_pb_msg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_pb_msg PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_pb_msg.so"
  IMPORTED_SONAME_RELEASE "libzsibot_pb_msg.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_pb_msg )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_pb_msg "${_IMPORT_PREFIX}/lib/libzsibot_pb_msg.so" )

# Import target "zsibot_common::zsibot_rmw_ecal" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_rmw_ecal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_rmw_ecal PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_rmw_ecal.so"
  IMPORTED_SONAME_RELEASE "libzsibot_rmw_ecal.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_rmw_ecal )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_rmw_ecal "${_IMPORT_PREFIX}/lib/libzsibot_rmw_ecal.so" )

# Import target "zsibot_common::zsibot_rmw_interface" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_rmw_interface APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_rmw_interface PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_rmw_interface.so"
  IMPORTED_SONAME_RELEASE "libzsibot_rmw_interface.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_rmw_interface )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_rmw_interface "${_IMPORT_PREFIX}/lib/libzsibot_rmw_interface.so" )

# Import target "zsibot_common::zsibot_thread" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_thread PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_thread.so"
  IMPORTED_SONAME_RELEASE "libzsibot_thread.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_thread )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_thread "${_IMPORT_PREFIX}/lib/libzsibot_thread.so" )

# Import target "zsibot_common::zsibot_thread_lock" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_thread_lock APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_thread_lock PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_thread_lock.so"
  IMPORTED_SONAME_RELEASE "libzsibot_thread_lock.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_thread_lock )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_thread_lock "${_IMPORT_PREFIX}/lib/libzsibot_thread_lock.so" )

# Import target "zsibot_common::zsibot_utils" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_utils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_utils PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_utils.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_utils )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_utils "${_IMPORT_PREFIX}/lib/libzsibot_utils.a" )

# Import target "zsibot_common::zsibot_unit" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_unit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_unit PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_unit.so"
  IMPORTED_SONAME_RELEASE "libzsibot_unit.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_unit )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_unit "${_IMPORT_PREFIX}/lib/libzsibot_unit.so" )

# Import target "zsibot_common::zsibot_chrono" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_chrono APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_chrono PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_chrono.so"
  IMPORTED_SONAME_RELEASE "libzsibot_chrono.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_chrono )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_chrono "${_IMPORT_PREFIX}/lib/libzsibot_chrono.so" )

# Import target "zsibot_common::zsibot_param" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_param APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_param PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_param.so"
  IMPORTED_SONAME_RELEASE "libzsibot_param.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_param )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_param "${_IMPORT_PREFIX}/lib/libzsibot_param.so" )

# Import target "zsibot_common::zsibot_binding_yaml" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_binding_yaml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_binding_yaml PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_binding_yaml.so"
  IMPORTED_SONAME_RELEASE "libzsibot_binding_yaml.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_binding_yaml )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_binding_yaml "${_IMPORT_PREFIX}/lib/libzsibot_binding_yaml.so" )

# Import target "zsibot_common::zsibot_binding" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_binding APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_binding PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_binding.so"
  IMPORTED_SONAME_RELEASE "libzsibot_binding.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_binding )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_binding "${_IMPORT_PREFIX}/lib/libzsibot_binding.so" )

# Import target "zsibot_common::zsibot_yaml" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_yaml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_yaml PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_yaml.so"
  IMPORTED_SONAME_RELEASE "libzsibot_yaml.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_yaml )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_yaml "${_IMPORT_PREFIX}/lib/libzsibot_yaml.so" )

# Import target "zsibot_common::zsibot_log" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_log APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_log PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_log.so"
  IMPORTED_SONAME_RELEASE "libzsibot_log.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_log )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_log "${_IMPORT_PREFIX}/lib/libzsibot_log.so" )

# Import target "zsibot_common::zsibot_modules" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_modules APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_modules PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_modules.so"
  IMPORTED_SONAME_RELEASE "libzsibot_modules.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_modules )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_modules "${_IMPORT_PREFIX}/lib/libzsibot_modules.so" )

# Import target "zsibot_common::zsibot_base" for configuration "Release"
set_property(TARGET zsibot_common::zsibot_base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(zsibot_common::zsibot_base PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzsibot_base.so"
  IMPORTED_SONAME_RELEASE "libzsibot_base.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS zsibot_common::zsibot_base )
list(APPEND _IMPORT_CHECK_FILES_FOR_zsibot_common::zsibot_base "${_IMPORT_PREFIX}/lib/libzsibot_base.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
